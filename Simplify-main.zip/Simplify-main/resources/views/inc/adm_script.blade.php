<script src="{{asset("js/jquery/jquery.min.js")}}"></script>
<script src="{{asset("js/bootstrap/js/bootstrap.bundle.min.js")}}"></script>

<!-- Core plugin JavaScript-->
<script src="{{asset("js/jquery-easing/jquery.easing.min.js")}}"></script>

<!-- Custom scripts for all pages-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" integrity="sha512-RXf+QSDCUQs5uwRKaDoXt55jygZZm2V++WUZduaU/Ui/9EGp3f/2KZVahFZBKGH0s774sd3HmrhUy+SgOFQLVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="{{asset("js/sb-admin-2.min.js")}}"></script>
<script src="{{asset('js/datatables/jquery.dataTables.js')}}"></script>
<script src="{{asset('js/datatables/dataTables.bootstrap4.js')}}"></script>
<script src="{{asset("js/sweetalert.min.js")}}"></script>
<script src="{{asset("js/jquery-autocomplete/jquery.autocomplete.js")}}"></script>

<!-- Page level plugins -->
{{-- <script src="js/chart.js/Chart.min.js"></script> --}}

<!-- Page level custom scripts -->
{{-- <script src="js/demo/chart-area-demo.js"></script>
<script src="js/demo/chart-pie-demo.js"></script> --}}