<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{url('/admin/dashboard')}}">
        <div >
            <img style="background: transparent;
            border-radius: 100%;
            padding: 8px;
            width: 60px;" src="{{asset('images/logo/logo.png')}}" alt="">
        </div>
        
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
        <a class="nav-link" href="{{url('/admin/dashboard')}}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

   <li class="nav-item">
       <a class="nav-link collapsed"  href="#" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
            <i class="fas fa-clipboard-list"></i>
            <span>Chart Of Account</span>
       </a>
       <div id="collapseOne" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Chart Of Account:</h6>
            <a class="collapse-item" href="{{url('/admin/create-COA')}}">Create</a>
            <a class="collapse-item" href="{{url('/admin/COA-list')}}">List</a>
            <a class="collapse-item" href="{{url('/admin/assign-COA')}}">Assign COA</a>
        </div>
    </div>
   </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            <i class="far fa-building"></i>
            <span>Companies</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Companies:</h6>
                <a class="collapse-item" href="{{url('/admin/create-company')}}">Create</a>
                <a class="collapse-item" href="{{url('/admin/company-list')}}">List</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseTwo">
            <i class="fas fa-chart-pie"></i>
            <span>Report</span>
        </a>
        <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Reports:</h6>
                <a class="collapse-item" href="#">Create</a>
                <a class="collapse-item" href="#">List</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
            <i class="far fa-id-badge"></i>
            <span>Profile</span>
        </a>
        <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Profile:</h6>
                {{-- <a class="collapse-item" href="{{url('/admin/vendor')}}">Create</a> --}}
                <a class="collapse-item" href="{{url('/admin/comp-user-list')}}">List</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseFive" aria-expanded="false" aria-controls="collapseFour">
            <i class="fas fa-calculator"></i>
            <span>GST</span>
        </a>
        <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">GST:</h6>
                <a class="collapse-item" href="{{url('/admin/create-gst')}}">Create</a>
                {{-- <a class="collapse-item" href="{{url('/admin/comp-user-list')}}">List</a> --}}
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseSeven" aria-expanded="false" aria-controls="collapseFour">
            <i class="fas fa-calculator"></i>
            <span>Currency</span>
        </a>
        <div id="collapseSeven" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Currency:</h6>
                <a class="collapse-item" href="{{url('/admin/xcurr-list')}}">List</a>
                <a class="collapse-item" href="{{url('/admin/create-xchage-curr')}}">Create</a>
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseSix" aria-expanded="false" aria-controls="collapseFour">
            <i class="fas fa-calculator"></i>
            <span>Fix Assets</span>
        </a>
        <div id="collapseSix" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Fix Assets:</h6>
                <a class="collapse-item" href="{{url('/admin/create-fa-main-cate')}}">Create Category</a>
                <a class="collapse-item" href="{{url('/admin/create-fa-sub-cate')}}">Create SubCategory</a>
                <a class="collapse-item" href="{{url('/admin/create-fa-useful-life')}}">Create Useful life</a>
                
                
                {{-- <a class="collapse-item" href="{{url('/admin/comp-user-list')}}">List</a> --}}
            </div>
        </div>
    </li>
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsegreen" aria-expanded="false" aria-controls="collapseFour">
            <i class="fas fa-calculator"></i>
            <span>Accounts</span>
        </a>
        <div id="collapsegreen" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Accounts Setup:</h6>
                <a class="collapse-item" href="{{url('/admin/company-accounting-setup')}}">Accounting Setup</a>
                <a class="collapse-item" href="{{url('/admin/company-acc-payable-setup')}}">Accounting Payable Setup</a>
                <a class="collapse-item" href="{{url('/admin/account-payable-list')}}">Accounting Payable List</a>
                <a class="collapse-item" href="{{url('/admin/company-acc-rece-setup')}}">Accounting Recieve Setup</a>
                <a class="collapse-item" href="{{url('/admin/account-recieve-list')}}">Accounting Recieve List</a>
                <a class="collapse-item" href="{{url('/admin/create-supplier-cate')}}">Supplier Category</a>
                <a class="collapse-item" href="{{url('/admin/create-customer-cate')}}">Customer Category</a>
                <a class="collapse-item" href="{{url('/admin/create-pay-terms')}}">Create Pay Terms</a>
                {{-- <a class="collapse-item" href="{{url('/admin/comp-user-list')}}">List</a> --}}
            </div>
        </div>
    </li>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapsede" aria-expanded="false" aria-controls="collapseFour">
            <i class="fas fa-calculator"></i>
            <span>Data Entry</span>
        </a>
        <div id="collapsede" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar" style="">
            <div class="bg-white py-2 collapse-inner rounded">
                <h6 class="collapse-header">Data Entry:</h6>
                <a class="collapse-item" href="{{url('/admin/data-entry/supplier')}}">Supplier</a>
                <a class="collapse-item" href="{{url('/admin/data-entry/customer')}}">Customer</a>
                <a class="collapse-item" href="{{url('/admin/data-entry/general-journal')}}">General Journal</a>
                
                {{-- <a class="collapse-item" href="{{url('/admin/comp-user-list')}}">List</a> --}}
            </div>
        </div>
    </li>


    {{-- @if(session()->get("GA-auth") == "SUPERADMIN")
    <li class="nav-item active">
        <a class="nav-link" href="{{url('/admin/removealldata')}}">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Remove All data</span></a>
    </li>
    @endif --}}

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

</ul>