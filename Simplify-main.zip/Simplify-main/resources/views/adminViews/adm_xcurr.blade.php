@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b>Currency Rate</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('/admin/generate-xchange-currency')}}" method="post" accept-charset="utf-8"
                    enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <legend>Currency Information</legend>
                            {{-- <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Currency Name</b></label>
                                    <input class="form-control" type="text" name="cur_name_value" id=""/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Currency Symbol</b></label>
                                    <input class="form-control" type="text" name="cur_sym_value" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <label><b>Currency Xchage value base on Singapur Dollar</b></label>
                                <input class="form-control" type="text" name="cur_xchage_value" id=""/>
                            </div> --}}
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Month</b></label>
                                    <select  name="cur_month_value" class="form-control" id="">
                                        {{-- <option name="" value="" style="display:none;">MM</option> --}}
                                        <option name="January" value="Jan">January</option>
                                        <option name="February" value="Feb">February</option>
                                        <option name="March" value="Mar">March</option>
                                        <option name="April" value="Apr">April</option>
                                        <option name="May" value="May">May</option>
                                        <option name="June" value="Jun">June</option>
                                        <option name="July" value="Jul">July</option>
                                        <option name="August" value="Aug">August</option>
                                        <option name="September" value="Sep">September</option>
                                        <option name="October" value="Oct">October</option>
                                        <option name="November" value="Nov">November</option>
                                        <option name="December" value="Dec">December</option>
                                    </select>
                                    {{-- <input class="form-control" type="text" name="cur_month_value" id=""/> --}}
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Year</b></label>
                                    <input class="form-control" type="text" name="cur_yr_value" id="" placeholder="YYYY"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <label><b>Upload File</b></label>
                                <input class="form-control" type='file' name='file' />
                            </div>
                        </fieldset>
                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Create Currency
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection