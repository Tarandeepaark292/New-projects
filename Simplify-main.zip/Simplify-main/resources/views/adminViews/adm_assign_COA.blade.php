@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Company Users</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('admin/assign-comp-COA')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <legend>Company</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Select Company</b></label>
                                    {{-- <input class="form-control" type="text" name="acc_code" id=""/> --}}
                                    <select class="form-control" name="comp_id" id="comp_id" onchange="update_checked_on_select()">
                                        <option value="-1">Select</option>
                                        @foreach ($companylist as $comp)
                                        <option value="{{$comp['comp_id']}}">{{$comp['comp_name']}}</option>
                                        @endforeach
                                        
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>COAs List</legend>
                            @isset($coaList)
                                @foreach($coaList as $noti)
                                <div class="form-row" style="border-bottom: 1px dashed #1E355C;margin-top: 1rem;">
                                    <div class="form-group col-lg-10">
                                        <b>{{$noti['coa_acc_name']}} ({{$noti['coa_acc_code']}})</b>
                                    </div>
                                    <div class="form-group col-lg-2">
                                        <input class="chk_coas" name="chk_{{$noti['coa_acc_code']}}" id="chk_{{$noti['coa_acc_code']}}" type="checkbox" value="{{$noti['coa_acc_code']}}" style="margin-right: 1rem" onclick="onchkclick();"><span style="height:calc(1.5em + 0.75rem + 2px)"></span>
                                    </div>
                                </div>
                                @endforeach
                            @endisset
                            <input type="hidden" name="coa_vals" id="coa_vals" />
                        </fieldset>
                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Assign COA
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('custom_script')

<script>
    function update_checked_on_select(){
        var comp_id = $('#comp_id').val();
        if(comp_id === '-1'){
            $('#coa_vals').val("");
            chk_coas = $('.chk_coas');
            chk_coas.each((index, value) => {
                $(value).prop('checked', false);
            });
            return;
        }
        $.ajax({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
        type:'POST',
        dataType: "json",
        url:"{{ route('ajaxgetCOAs.post') }}",
        data:{comp_id:comp_id},
        success:function(data){
            //Utils.hideLoading();
            //console.log(data);
            if(data.res == 'SUCCESS'){
                // $('#btn_layer_'+idx).html(data.data);
                //location.reload();
                console.log(data);
                let arr = data.data;
                $('#coa_vals').val(data.datatxt);
                arr.forEach((ele, index, arr)=>{
                    console.log(ele);
                    $('#chk_'+ele).prop('checked',true);
                });

            }else{
                console.log(data);
                alert(data.error);
                $('#coa_vals').val("");
                chk_coas = $('.chk_coas');
                chk_coas.each((index, value) => {
                    $(value).prop('checked',false);
                }
                );
            }
        }
    });
    }

    function onchkclick()
    {
        $('#coa_vals').val('');
        chk_coas = $('.chk_coas');
        chk_coas.each((index, value) => {
                if ($(value).prop('checked') == true) {
                    if ($('#coa_vals').val() === '') {
                        $('#coa_vals').val($(value).val());
                    } else {
                        $('#coa_vals').val($('#coa_vals').val() + ',' + $(value).val());
                    }

                }
            }
        );
        console.log($('#coa_vals').val());

        //other way
        /********************************
         * curr_val = $('#coa_vals').val();
         * arr = curr_val.split(',');
         * chk_coas = $('.chk_coas');
           chk_coas.each((index, value) => {
            if ($(value).prop('checked') == true) {
                 if ($('#coa_vals').val() === '') {
                        $('#coa_vals').val($(value).val());
                    } else {
                        $('#coa_vals').val($('#coa_vals').val() + ',' + $(value).val());
                    }    
            }else{
                const index = arr.indexOf($(value).val());
                if (index > -1) {
                    arr.splice(index, 1);
                }

            }
        });
        $('#coa_vals').val(arr.join(","));
         * 
         * **/
    }
</script>

@endsection
