@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>

<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b>Payment Terms Creation</b> </h6>
                </div>
                <div class="card-body">
                    <fieldset>
                        <legend>Payment Terms List</legend>
                        <div class="table-responsive">
                            <table class="table table-bordered" style="font-size: 14px;" id="notidataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th><b>#</b></th>
                                        <th><b>Payment Term</b></th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>
                                        <th><b>#</b></th>
                                        <th><b>Payment Terms</b></th>
                                    </tr>
                                </tfoot>
                                <tbody>
                                    @isset($pay_terms)
                                    @foreach($pay_terms as $noti)
                                    <tr>
                                        <td>{{$loop->index + 1}}</td>
                                        <td>{{$noti['pt_value']}}</td>
                                    </tr>
                                    @endforeach
                                    @else
                                    skhsvh
                                    @endisset
                                </tbody>
                            </table>
                        </div>
                    </fieldset>


                    <form action="{{url('/admin/generate-pay-terms')}}" method="post" accept-charset="utf-8"
                    enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <legend>Payment Terms Information</legend>
                            @if($errors->any())
                            @error('error_reason')
                            <h5 class="font-weight-bold text-primary ">{{$errors->first()}}</h5>
                            @enderror
                            @endif
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Payment Terms Value</b></label>
                                    <input class="form-control" type="text" name="pt_value" id=""/>
                                </div>
                            </div>
                        </fieldset>
                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Create Payment Terms
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('custom_script')
<script>
    $(document).ready(function () {
        $('#notidataTable').DataTable();
    });
</script>
@endsection