@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Company financial Setup</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('admin/account-setup')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <legend>Company</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Select Company</b></label>
                                    {{-- <input class="form-control" type="text" name="acc_code" id=""/> --}}
                                    <select class="form-control" name="comp_id" id="comp_id">
                                        <option value="-1">Select</option>
                                        @foreach ($companylist as $comp)
                                        <option value="{{$comp['comp_id']}}">{{$comp['comp_name']}}</option>
                                        @endforeach
                                        
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Number of Banks</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Number of Banks</b></label>
                                    {{-- <input class="form-control" type="text" name="acc_code" id=""/> --}}
                                    <select class="form-control" name="company_selctor" id="prodtypeSelect" onchange="onProductTypeSelect()">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                    </select>
                                </div>
                            </div>
                        </fieldset>


                        <fieldset class="banks" id="bank1">
                            <legend>Company Bank Information 1</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank_name" id=""/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_code" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank_branch_name" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_branch_code" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Swift Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_swift_code" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Intermediary Bank</b></label>
                                    <input class="form-control" type="text" name="comp_bank_intermed" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Type</b></label>
                                    <input class="form-control" type="text" name="comp_bank_acc_type" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Number</b></label>
                                    <input class="form-control" type="text" name="comp_bank_acc_number" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label for=""><b>Is Multicurrency Support</b></label><br/>
                                    <input onclick="onchkclick()" name="check_cust" type="checkbox" id="check_cust" value="" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Yes</span>
                                    <input type="hidden" id="acc_chk_asset_vals" name="acc_chk_asset_vals" value=1 />
                                </div>
                            </div>
                        </fieldset>

                        <fieldset class="banks" id="bank2">
                            <legend>Company Bank Information 2</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank2_name" id=""/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank2_code" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank2_branch_name" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank2_branch_code" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Swift Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank2_swift_code" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Intermediary Bank</b></label>
                                    <input class="form-control" type="text" name="comp_bank2_intermed" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Type</b></label>
                                    <input class="form-control" type="text" name="comp_bank2_acc_type" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Number</b></label>
                                    <input class="form-control" type="text" name="comp_bank2_acc_number" id=""/>
                                </div>
                            </div>
                            {{-- <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label for=""><b>Is Multicurrency Support</b></label><br/>
                                    <input onclick="onchkclick()" name="check_cust" type="checkbox" id="check_cust" value="" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Yes</span>
                                    <input type="hidden" id="acc_chk_asset_vals" name="acc_chk_asset_vals" value=1 />
                                </div>
                            </div> --}}
                        </fieldset>

                        <fieldset class="banks" id="bank3">
                            <legend>Company Bank Information 3</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank3_name" id=""/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank3_code" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank3_branch_name" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank3_branch_code" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Swift Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank3_swift_code" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Intermediary Bank</b></label>
                                    <input class="form-control" type="text" name="comp_bank3_intermed" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Type</b></label>
                                    <input class="form-control" type="text" name="comp_bank3_acc_type" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Number</b></label>
                                    <input class="form-control" type="text" name="comp_bank3_acc_number" id=""/>
                                </div>
                            </div>
                            {{-- <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label for=""><b>Is Multicurrency Support</b></label><br/>
                                    <input onclick="onchkclick()" name="check_cust" type="checkbox" id="check_cust" value="" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Yes</span>
                                    <input type="hidden" id="acc_chk_asset_vals" name="acc_chk_asset_vals" value=1 />
                                </div>
                            </div> --}}
                        </fieldset>


                        <fieldset>
                            <legend>Accounting Period</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Start Period</b></label>
                                    <select name="start_period" class="form-control">
                                        <option value="-1">Select Period</option>
                                        <option value="jan">January</option>
                                        <option value="feb">February</option>
                                        <option value="mar">March</option>
                                        <option value="apr">April</option>
                                        <option value="may">May</option>
                                        <option value="jun">June</option>
                                        <option value="jul">July</option>
                                        <option value="aug">August</option>
                                        <option value="sep">September</option>
                                        <option value="oct">October</option>
                                        <option value="nov">November</option>
                                        <option value="dec">December</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>End Period</b></label>
                                    <select name="end_period" class="form-control">
                                        <option value="-1">Select Period</option>
                                        <option value="jan">January</option>
                                        <option value="feb">February</option>
                                        <option value="mar">March</option>
                                        <option value="apr">April</option>
                                        <option value="may">May</option>
                                        <option value="jun">June</option>
                                        <option value="jul">July</option>
                                        <option value="aug">August</option>
                                        <option value="sep">September</option>
                                        <option value="oct">October</option>
                                        <option value="nov">November</option>
                                        <option value="dec">December</option>
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Active Accounting Period</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Active Financial Year</b></label>
                                    <select name="act_fin_yr" class="form-control">
                                        <option value="-1">Select Financial Year</option>
                                        <option>2000</option>
                                        <option>2001</option>
                                        <option>2002</option>
                                        <option>2003</option>
                                        <option>2004</option>
                                        <option>2005</option>
                                        <option>2006</option>
                                        <option>2007</option>
                                        <option>2008</option>
                                        <option>2009</option>
                                        <option>2010</option>
                                        <option>2011</option>
                                        <option>2012</option>
                                        <option>2013</option>
                                        <option>2014</option>
                                        <option>2015</option>
                                        <option>2016</option>
                                        <option>2017</option>
                                        <option>2018</option>
                                        <option>2019</option>
                                        <option>2020</option>
                                        <option>2021</option>
                                        <option>2022</option>
                                        <option>2023</option>
                                        <option>2024</option>
                                        <option>2025</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-8">
                                    <label><b>Active Financial Month</b></label><br/>
                                    {{-- <select name="act_fin_mon" class="form-control">
                                        <option value="All">All</option>
                                    </select> --}}
                                    <input  type="checkbox" name="category1[]" checked="checked" value="January" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">January</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="Feburary" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Feburary</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="March" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">March</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="April" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">April</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="May" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">May</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="June" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">June</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="July" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">July</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="August" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">August</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="September" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">September</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="October" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">October</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="November" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">November</span>
                                    <input  type="checkbox" name="category1[]" checked="checked" value="December" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">December</span>
 
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Company Currency</b></label>
                                    <select name="comp_curr" class="form-control">
                                        <option value="USD">USD</option>
                                        <option value="INR">INR</option>
                                        <option value="AUD">AUD</option>
                                    </select>
                                </div>
                            {{-- </div>
                            <div class="form-row"> --}}
                                <div class="form-group col-lg-8">
                                    <label><b>Select GST Rate</b></label><br/>
                                    {{-- <input  type="checkbox" name="category[]" value="18" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">18%</span>
                                    <input  type="checkbox" name="category[]" value="5" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">5%</span>
                                    <input  type="checkbox" name="category[]" value="20" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">20%</span>
                                    <input  type="checkbox" name="category[]" value="3" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">3%</span>
                                    <input  type="checkbox" name="category[]" value="24" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">24%</span>
                                    <input  type="checkbox" name="category[]" value="12" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">12%</span> --}}
                                    @isset($gsts)
                                    @foreach ($gsts as $gst )


                                    <input  type="checkbox" name="category[]" value="{{$gst['gst_id']}}"  style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)" >{{$gst['gst_val']}}</span>

                                    @endforeach
                                    @endisset
                                    {{-- <select name="gstrate" id="gstrate" multiple="multiple" class="form-control">
                                        <option value="18%">18%</option>
                                        <option value="6%">6%</option>
                                        <option value="12%">12%</option>
                                        <option value="24%">24%</option>
                                        <option value="18%">18%</option>
                                        <option value="6%">6%</option>
                                        <option value="12%">12%</option>
                                        <option value="24%">24%</option>
                                    </select> --}}
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Select Date Format</b></label>
                                    <select name="comp_dateformat" class="form-control">
                                        <option value="dd/mm/yy">dd/mm/yy </option>
                                        <option value="mm/dd/yy">mm/dd/yy</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-8">
                                    <label><b>Document Format</b></label>
                                    <div style="display:flex">
                                        <ul>
                                            <li>Customer Invoice 	CI</li>
                                            <li>Receive Customer Payment	CP</li>
                                            <li>Supplier Invoice	SI</li>
                                            <li>Invoice Payment	SP</li>
                                        </ul>
                                        <ul>
                                            <li>Depreciation	DP</li>
                                            <li>Journal Entries	DP</li>
                                            <li>Opening Balance	OB</li>
                                        </ul>
                                    </div>
                                    
                                </div>
                            </div>
                        </fieldset>

                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Setup
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('custom_script')
<script type="text/javascript">
$(document).ready(function() {
    onProductTypeSelect();
});
</script>
<script>
    function onchkclick(){
            $('#acc_chk_asset_vals').val('');
            chkeles = $('#check_cust');
            if($(chkeles).prop('checked') == true){
                console.log("checked");
                $('#acc_chk_asset_vals').val(1);
            }else{
                console.log("not checked");
                $('#acc_chk_asset_vals').val(0);
            }


            // chkeles.each((index,value)=>{
            //     if($(value).prop('checked') == true){
            //         if($('#cates').val() === ''){
            //             $('#cates').val( $(value).val());
            //         }else{
            //             $('#cates').val( $('#cates').val() + ',' + $(value).val());
            //         }
                    
            //     }
            // });
            // console.log($('#cates').val());
        }
        function onProductTypeSelect(){
            // flavorSelec_box  optionSelec_box
            var prodtype = $('#prodtypeSelect').val();
            if(prodtype === '1'){
                $('.banks').hide();
                $('#bank1').show();
                //$('.notsingles').hide();
            }else if(prodtype === '2'){
                // $('.box').show();
                // $('.notsingle').show();
                // $('.notsingles').hide();
                $('.banks').hide();
                $('#bank1').show();
                $('#bank2').show();
            }else if(prodtype === '3'){
                $('.banks').hide();
                $('#bank1').show();
                $('#bank2').show();
                $('#bank3').show();
            }else{
                $('.banks').hide();

            }
        }
</script>
@endsection