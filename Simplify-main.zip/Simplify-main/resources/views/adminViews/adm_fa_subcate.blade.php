@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Fix Assets SubCategory</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('/admin/generate-fa-sub-cate')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <legend>Fix Asset Main Category</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Select Fixed Assets Main Category</b></label>
                                    <select class="form-control" name="fa_cate_id" id="fa_cate_id" onchange="checked_data()">
                                        <option value="-1">Select</option>
                                        @foreach ($FA_list as $noti)
                                        <option value="{{$noti['cate_id']}}">{{$noti['cate_name']}}</option>
                                        @endforeach
                                        
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                                                    <!--         Sub Category Part          -->

                        <fieldset>
                            <legend>Sub-Category List</legend>

                            <div class="tableviewclss">

                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Fix Asset Sub Category</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Fix assets Sub Category Value</b></label>
                                    <input class="form-control" type="text" name="fac_sub_cate_value" id=""/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Fix assets Code</b></label>
                                    <input class="form-control" type="text" name="fac_sub_asset_code" id=""/>
                                </div>
                            </div>
                        </fieldset>
                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Create Fix Asset Sub Category
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('custom_script')
<script>
    function checked_data() {
        var fa_cate_id = $('#fa_cate_id').val();
        console.log(fa_cate_id);

        $.ajax({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            type: 'POST',
            dataType: "json",
            url: "{{ route('ajaxgetSubCat.get') }}",
            data: {
                fa_cate_id: fa_cate_id
            },
            success: function (data) {
                // console.log(data);
                if (data.res === "SUCCESS") {
                    let arr = data.data;
                    $('#fac_sub_cate_value').val(data);
                    var tarea = '';

                    // tarea+='<fieldset>';

                    tarea += '<div class="table-responsive">';
                    tarea += '<table class="table table-bordered" style="font-size: 14px;" id="notidataTable" width="100%" cellspacing="0">';


                    tarea += '<thead>';
                    tarea += '<tr>';
                    // tarea+='<th><b>#</b</th>';
                    tarea += '<td><b>Sub Category Name</b></td>';
                    tarea += '<td><b>Unique Code</b></td>';
                    tarea += '</tr>';
                    tarea += '</thead>';
                    tarea += '<tfoot>';
                    tarea += '<tr>';
                    tarea += '</tr>';
                    tarea += '</tfoot>';


                    tarea += '<tbody>';
                    arr.forEach((ele, index, arr) => {
                        tarea += '<tr>';

                        // console.log(ele);
                        console.log(index);
                        console.log(arr);
                        // $('#chk_'+ele).prop('checked',true);


                        tarea += '<td>' + ele.fa_sub_cate_name + '</td>';
                        tarea += '<td>' + ele.fa_unique_code + '</td>';
                        // tarea+='<td>'+data[0].price+'</td>';
                        tarea += '</tr>';
                    });
                    tarea += '</tbody>';
                    tarea += '</table>';
                    tarea += '</div>';
                    // tarea+='</fieldset>';

                    $('.tableviewclss').html("");

                    $('.tableviewclss').html(tarea);
                    $('#notidataTable').DataTable();
                } else {
                    $('.tableviewclss').html("");
                }


            }

        });

    }
</script>



@endsection