@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Update Company</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('admin/update-company')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <input type="hidden" value="{{$comp['comp_id']}}" name="comp_id" />
                            <legend>General Information</legend>
                            @if($errors->any())
                                @error('error_reason')
                                <h5 class="font-weight-bold text-primary ">{{$errors->first()}}</h5>
                                @enderror
                            @endif
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Entity Name</b></label>
                                    <input class="form-control" type="text" value="{{$comp['comp_name']??''}}" name="comp_name" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Business Register Number</b></label>
                                    <input class="form-control" type="text" name="comp_reg_number" id="" value="{{$comp['comp_reg_number']??''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>GST/VAT Register Number</b></label>
                                    <input class="form-control" type="text" name="comp_gst_number" id="" value="{{$comp['comp_gst_number']??''}}"/>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Incorporate Date</b></label>
                                    <input class="form-control" type="date" name="comp_incorp_date" id="" value="{{$comp['comp_incorp_date']??''}}"/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Entity Formation</b></label>
                                    <select class="form-control" name="comp_entity_type" id="">
                                        <option value="Sole Proprietorship" {{ ( $comp['comp_entity_type'] == "Sole Proprietorship") ? 'selected' : '' }}>Sole Proprietorship</option>
                                        <option value="Partnership" {{ ( $comp['comp_entity_type'] == "Partnership") ? 'selected' : '' }}>Partnership</option>
                                        <option value="LLP Partnership" {{ ( $comp['comp_entity_type'] == "LLP Partnership") ? 'selected' : '' }}>LLP Partnership</option>
                                        <option value="Private Limited" {{ ( $comp['comp_entity_type'] == "Private Limited") ? 'selected' : '' }}>Private Limited</option>
                                    </select>
                                </div>
                            </div>
                        </fieldset>

                        <fieldset>
                            <legend>Contact Information</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-3">
                                    <label><b>Phone 1</b></label>
                                    <input class="form-control" type="text" name="comp_phone_1" id="" value="{{$comp['comp_phone_1']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Phone 2</b></label>
                                    <input class="form-control" type="text" name="comp_phone_2" id="" value="{{$comp['comp_phone_2']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Mobile 1</b></label>
                                    <input class="form-control" type="text" name="comp_mobile_1" id="" value="{{$comp['comp_mobile_1']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Mobile 2</b></label>
                                    <input class="form-control" type="text" name="comp_mobile_2" id="" value="{{$comp['comp_mobile_2']??''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Fax</b></label>
                                    <input class="form-control" type="text" name="comp_fax" id="" value="{{$comp['comp_fax']??''}}"/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Email</b></label>
                                    <input class="form-control" type="text" name="comp_email" id="" value="{{$comp['comp_email']??''}}"/>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Legal Registered Address</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Address Line 1</b></label>
                                    <input class="form-control" type="text" name="leg_addr_line_1" id="" value="{{$comp['comp_legal_addr']['line_1']??''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Address Line 2</b></label>
                                    <input class="form-control" type="text" name="leg_addr_line_2" id="" value="{{$comp['comp_legal_addr']['line_2']??''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>State</b></label>
                                    <input class="form-control" type="text" name="leg_addr_state" id="" value="{{$comp['comp_legal_addr']['state']??''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>City</b></label>
                                    <input class="form-control" type="text" name="leg_addr_city" id="" value="{{$comp['comp_legal_addr']['city']??''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Postal Code</b></label>
                                    <input class="form-control" type="text" name="leg_addr_postal" id="" value="{{$comp['comp_legal_addr']['postal']??''}}"/>
                                </div>
                                
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Country</b></label>
                                    {{-- <input class="form-control" type="text" name="leg_addr_country" id=""/> --}}
                                    <select name="leg_addr_country" class="form-control">
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "Afganistan") ? 'selected' : '' }} value="Afganistan">Afghanistan</option>
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "Albania") ? 'selected' : '' }} value="Albania">Albania</option>
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "Algeria") ? 'selected' : '' }} value="Algeria">Algeria</option>
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "American Samoa") ? 'selected' : '' }} value="American Samoa">American Samoa</option>
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "Andorra") ? 'selected' : '' }} value="Andorra">Andorra</option>
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "Angola") ? 'selected' : '' }} value="Angola">Angola</option>
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "Anguilla") ? 'selected' : '' }} value="Anguilla">Anguilla</option>
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "Antigua & Barbuda") ? 'selected' : '' }} value="Antigua & Barbuda">Antigua & Barbuda</option>
                                        <option {{ ( $comp['comp_legal_addr']['country'] == "Argentina") ? 'selected' : '' }} value="Argentina">Argentina</option>
                                        <option value="Armenia" {{ ( $comp['comp_legal_addr']['country'] == "Armenia") ? 'selected' : '' }} >Armenia</option>
                                        <option value="Aruba">Aruba</option>
                                        <option value="Australia" {{ ( $comp['comp_legal_addr']['country'] == "Australia") ? 'selected' : '' }} >Australia</option>
                                        <option value="Austria" {{ ( $comp['comp_legal_addr']['country'] == "Austria") ? 'selected' : '' }}>Austria</option>
                                        <option value="Azerbaijan" {{ ( $comp['comp_legal_addr']['country'] == "Azerbaijan") ? 'selected' : '' }}>Azerbaijan</option>
                                        <option value="Bahamas" {{ ( $comp['comp_legal_addr']['country'] == "Bahamas") ? 'selected' : '' }}>Bahamas</option>
                                        <option value="Bahrain" {{ ( $comp['comp_legal_addr']['country'] == "Bahrain") ? 'selected' : '' }}>Bahrain</option>
                                        <option value="Bangladesh" {{ ( $comp['comp_legal_addr']['country'] == "Bangladesh") ? 'selected' : '' }}>Bangladesh</option>
                                        <option value="Barbados" {{ ( $comp['comp_legal_addr']['country'] == "Barbados") ? 'selected' : '' }}>Barbados</option>
                                        <option value="Belarus" {{ ( $comp['comp_legal_addr']['country'] == "Belarus") ? 'selected' : '' }}>Belarus</option>
                                        <option value="Belgium" {{ ( $comp['comp_legal_addr']['country'] == "Belgium") ? 'selected' : '' }}>Belgium</option>
                                        <option value="Belize" {{ ( $comp['comp_legal_addr']['country'] == "Belize") ? 'selected' : '' }}>Belize</option>
                                        <option value="Benin" {{ ( $comp['comp_legal_addr']['country'] == "Benin") ? 'selected' : '' }}>Benin</option>
                                        <option value="Bermuda" {{ ( $comp['comp_legal_addr']['country'] == "Bermuda") ? 'selected' : '' }}>Bermuda</option>
                                        <option value="Bhutan" {{ ( $comp['comp_legal_addr']['country'] == "Bhutan") ? 'selected' : '' }}>Bhutan</option>
                                        <option value="Bolivia" {{ ( $comp['comp_legal_addr']['country'] == "Bolivia") ? 'selected' : '' }}>Bolivia</option>
                                        <option value="Bonaire" {{ ( $comp['comp_legal_addr']['country'] == "Bonaire") ? 'selected' : '' }}>Bonaire</option>
                                        <option value="Bosnia & Herzegovina" {{ ( $comp['comp_legal_addr']['country'] == "Bosnia & Herzegovina") ? 'selected' : '' }}>Bosnia & Herzegovina</option>
                                        <option value="Botswana" {{ ( $comp['comp_legal_addr']['country'] == "Botswana") ? 'selected' : '' }}>Botswana</option>
                                        <option value="Brazil" {{ ( $comp['comp_legal_addr']['country'] == "Brazil") ? 'selected' : '' }}>Brazil</option>
                                        <option value="British Indian Ocean Ter" {{ ( $comp['comp_legal_addr']['country'] == "British Indian Ocean Ter") ? 'selected' : '' }}>British Indian Ocean Ter</option>
                                        <option value="Brunei" {{ ( $comp['comp_legal_addr']['country'] == "Brunei") ? 'selected' : '' }}>Brunei</option>
                                        <option value="Bulgaria" {{ ( $comp['comp_legal_addr']['country'] == "Bulgaria") ? 'selected' : '' }}>Bulgaria</option>
                                        <option value="Burkina Faso" {{ ( $comp['comp_legal_addr']['country'] == "Burkina Faso") ? 'selected' : '' }}>Burkina Faso</option>
                                        <option value="Burundi" {{ ( $comp['comp_legal_addr']['country'] == "Burundi") ? 'selected' : '' }}>Burundi</option>
                                        <option value="Cambodia" {{ ( $comp['comp_legal_addr']['country'] == "Cambodia") ? 'selected' : '' }}>Cambodia</option>
                                        <option value="Cameroon" {{ ( $comp['comp_legal_addr']['country'] == "Cameroon") ? 'selected' : '' }}>Cameroon</option>
                                        <option value="Canada" {{ ( $comp['comp_legal_addr']['country'] == "Canada") ? 'selected' : '' }}>Canada</option>
                                        <option value="Canary Islands" {{ ( $comp['comp_legal_addr']['country'] == "Canary Islands") ? 'selected' : '' }}>Canary Islands</option>
                                        <option value="Cape Verde" {{ ( $comp['comp_legal_addr']['country'] == "Cape Verde") ? 'selected' : '' }}>Cape Verde</option>
                                        <option value="Cayman Islands" {{ ( $comp['comp_legal_addr']['country'] == "Cayman Islands") ? 'selected' : '' }}>Cayman Islands</option>
                                        <option value="Central African Republic" {{ ( $comp['comp_legal_addr']['country'] == "Central African Republic") ? 'selected' : '' }}>Central African Republic</option>
                                        <option value="Chad" {{ ( $comp['comp_legal_addr']['country'] == "Chad") ? 'selected' : '' }}>Chad</option>
                                        <option value="Channel Islands" {{ ( $comp['comp_legal_addr']['country'] == "Channel Islands") ? 'selected' : '' }}>Channel Islands</option>
                                        <option value="Chile" {{ ( $comp['comp_legal_addr']['country'] == "Chile") ? 'selected' : '' }}>Chile</option>
                                        <option value="China" {{ ( $comp['comp_legal_addr']['country'] == "China") ? 'selected' : '' }}>China</option>
                                        <option value="Christmas Island" {{ ( $comp['comp_legal_addr']['country'] == "Christmas Island") ? 'selected' : '' }}>Christmas Island</option>
                                        <option value="Cocos Island" {{ ( $comp['comp_legal_addr']['country'] == "Cocos Island") ? 'selected' : '' }}>Cocos Island</option>
                                        <option value="Colombia" {{ ( $comp['comp_legal_addr']['country'] == "Colombia") ? 'selected' : '' }}>Colombia</option>
                                        <option value="Comoros" {{ ( $comp['comp_legal_addr']['country'] == "Comoros") ? 'selected' : '' }}>Comoros</option>
                                        <option value="Congo" {{ ( $comp['comp_legal_addr']['country'] == "Congo") ? 'selected' : '' }}>Congo</option>
                                        <option value="Cook Islands" {{ ( $comp['comp_legal_addr']['country'] == "Cook Islands") ? 'selected' : '' }}>Cook Islands</option>
                                        <option value="Costa Rica" {{ ( $comp['comp_legal_addr']['country'] == "Costa Rica") ? 'selected' : '' }}>Costa Rica</option>
                                        <option value="Cote DIvoire" {{ ( $comp['comp_legal_addr']['country'] == "Cote DIvoire") ? 'selected' : '' }}>Cote DIvoire</option>
                                        <option value="Croatia" {{ ( $comp['comp_legal_addr']['country'] == "Croatia") ? 'selected' : '' }}>Croatia</option>
                                        <option value="Cuba" {{ ( $comp['comp_legal_addr']['country'] == "Cuba") ? 'selected' : '' }}>Cuba</option>
                                        <option value="Curaco" {{ ( $comp['comp_legal_addr']['country'] == "Curacao") ? 'selected' : '' }}>Curacao</option>
                                        <option value="Cyprus" {{ ( $comp['comp_legal_addr']['country'] == "Cyprus") ? 'selected' : '' }}>Cyprus</option>
                                        <option value="Czech Republic" {{ ( $comp['comp_legal_addr']['country'] == "Czech Republic") ? 'selected' : '' }}>Czech Republic</option>
                                        <option value="Denmark" {{ ( $comp['comp_legal_addr']['country'] == "Denmark") ? 'selected' : '' }}>Denmark</option>
                                        <option value="Djibouti" {{ ( $comp['comp_legal_addr']['country'] == "Djibouti") ? 'selected' : '' }}>Djibouti</option>
                                        <option value="Dominica" {{ ( $comp['comp_legal_addr']['country'] == "Dominica") ? 'selected' : '' }}>Dominica</option>
                                        <option value="Dominican Republic" {{ ( $comp['comp_legal_addr']['country'] == "Dominican Republic") ? 'selected' : '' }}>Dominican Republic</option>
                                        <option value="East Timor" {{ ( $comp['comp_legal_addr']['country'] == "East Timor") ? 'selected' : '' }}>East Timor</option>
                                        <option value="Ecuador" {{ ( $comp['comp_legal_addr']['country'] == "Ecuador") ? 'selected' : '' }}>Ecuador</option>
                                        <option value="Egypt" {{ ( $comp['comp_legal_addr']['country'] == "Egypt") ? 'selected' : '' }}>Egypt</option>
                                        <option value="El Salvador" {{ ( $comp['comp_legal_addr']['country'] == "El Salvador") ? 'selected' : '' }}>El Salvador</option>
                                        <option value="Equatorial Guinea" {{ ( $comp['comp_legal_addr']['country'] == "Equatorial Guinea") ? 'selected' : '' }}>Equatorial Guinea</option>
                                        <option value="Eritrea" {{ ( $comp['comp_legal_addr']['country'] == "Eritrea") ? 'selected' : '' }}>Eritrea</option>
                                        <option value="Estonia" {{ ( $comp['comp_legal_addr']['country'] == "Estonia") ? 'selected' : '' }}>Estonia</option>
                                        <option value="Ethiopia" {{ ( $comp['comp_legal_addr']['country'] == "Ethiopia") ? 'selected' : '' }}>Ethiopia</option>
                                        <option value="Falkland Islands" {{ ( $comp['comp_legal_addr']['country'] == "Falkland Islands") ? 'selected' : '' }}>Falkland Islands</option>
                                        <option value="Faroe Islands" {{ ( $comp['comp_legal_addr']['country'] == "Faroe Islands") ? 'selected' : '' }}>Faroe Islands</option>
                                        <option value="Fiji" {{ ( $comp['comp_legal_addr']['country'] == "Fiji") ? 'selected' : '' }}>Fiji</option>
                                        <option value="Finland" {{ ( $comp['comp_legal_addr']['country'] == "Finland") ? 'selected' : '' }}>Finland</option>
                                        <option value="France" {{ ( $comp['comp_legal_addr']['country'] == "France") ? 'selected' : '' }}>France</option>
                                        <option value="French Guiana" {{ ( $comp['comp_legal_addr']['country'] == "French Guiana") ? 'selected' : '' }}>French Guiana</option>
                                        <option value="French Polynesia" {{ ( $comp['comp_legal_addr']['country'] == "French Polynesia") ? 'selected' : '' }}>French Polynesia</option>
                                        <option value="French Southern Ter" {{ ( $comp['comp_legal_addr']['country'] == "French Southern Ter") ? 'selected' : '' }}>French Southern Ter</option>
                                        <option value="Gabon" {{ ( $comp['comp_legal_addr']['country'] == "Gabon") ? 'selected' : '' }}>Gabon</option>
                                        <option value="Gambia" {{ ( $comp['comp_legal_addr']['country'] == "Gambia") ? 'selected' : '' }}>Gambia</option>
                                        <option value="Georgia" {{ ( $comp['comp_legal_addr']['country'] == "Georgia") ? 'selected' : '' }}>Georgia</option>
                                        <option value="Germany" {{ ( $comp['comp_legal_addr']['country'] == "Germany") ? 'selected' : '' }}>Germany</option>
                                        <option value="Ghana {{ ( $comp['comp_legal_addr']['country'] == "Ghana") ? 'selected' : '' }}">Ghana</option>
                                        <option value="Gibraltar" {{ ( $comp['comp_legal_addr']['country'] == "Gibraltar") ? 'selected' : '' }}>Gibraltar</option>
                                        <option value="Great Britain" {{ ( $comp['comp_legal_addr']['country'] == "Great Britain") ? 'selected' : '' }}>Great Britain</option>
                                        <option value="Greece" {{ ( $comp['comp_legal_addr']['country'] == "Greece") ? 'selected' : '' }}>Greece</option>
                                        <option value="Greenland" {{ ( $comp['comp_legal_addr']['country'] == "Greenland") ? 'selected' : '' }}>Greenland</option>
                                        <option value="Grenada" {{ ( $comp['comp_legal_addr']['country'] == "Grenada") ? 'selected' : '' }}>Grenada</option>
                                        <option value="Guadeloupe" {{ ( $comp['comp_legal_addr']['country'] == "Guadeloupe") ? 'selected' : '' }}>Guadeloupe</option>
                                        <option value="Guam" {{ ( $comp['comp_legal_addr']['country'] == "Guam") ? 'selected' : '' }}>Guam</option>
                                        <option value="Guatemala" {{ ( $comp['comp_legal_addr']['country'] == "Guatemala") ? 'selected' : '' }}>Guatemala</option>
                                        <option value="Guinea" {{ ( $comp['comp_legal_addr']['country'] == "Guinea") ? 'selected' : '' }}>Guinea</option>
                                        <option value="Guyana" {{ ( $comp['comp_legal_addr']['country'] == "Guyana") ? 'selected' : '' }}>Guyana</option>
                                        <option value="Haiti" {{ ( $comp['comp_legal_addr']['country'] == "Haiti") ? 'selected' : '' }}>Haiti</option>
                                        <option value="Hawaii" {{ ( $comp['comp_legal_addr']['country'] == "Hawaii") ? 'selected' : '' }}>Hawaii</option>
                                        <option value="Honduras" {{ ( $comp['comp_legal_addr']['country'] == "Honduras") ? 'selected' : '' }}>Honduras</option>
                                        <option value="Hong Kong" {{ ( $comp['comp_legal_addr']['country'] == "Hong Kong") ? 'selected' : '' }}>Hong Kong</option>
                                        <option value="Hungary" {{ ( $comp['comp_legal_addr']['country'] == "Hungary") ? 'selected' : '' }}>Hungary</option>
                                        <option value="Iceland" {{ ( $comp['comp_legal_addr']['country'] == "Iceland") ? 'selected' : '' }}>Iceland</option>
                                        <option value="Indonesia" {{ ( $comp['comp_legal_addr']['country'] == "Indonesia") ? 'selected' : '' }}>Indonesia</option>
                                        <option value="India" {{ ( $comp['comp_legal_addr']['country'] == "India") ? 'selected' : '' }}>India</option>
                                        <option value="Iran" {{ ( $comp['comp_legal_addr']['country'] == "Iran") ? 'selected' : '' }}>Iran</option>
                                        <option value="Iraq" {{ ( $comp['comp_legal_addr']['country'] == "Iraq") ? 'selected' : '' }}>Iraq</option>
                                        <option value="Ireland" {{ ( $comp['comp_legal_addr']['country'] == "Ireland") ? 'selected' : '' }}>Ireland</option>
                                        <option value="Isle of Man" {{ ( $comp['comp_legal_addr']['country'] == "Isle of Man") ? 'selected' : '' }}>Isle of Man</option>
                                        <option value="Israel" {{ ( $comp['comp_legal_addr']['country'] == "Israel") ? 'selected' : '' }}>Israel</option>
                                        <option value="Italy" {{ ( $comp['comp_legal_addr']['country'] == "Italy") ? 'selected' : '' }}>Italy</option>
                                        <option value="Jamaica" {{ ( $comp['comp_legal_addr']['country'] == "Jamaica") ? 'selected' : '' }}>Jamaica</option>
                                        <option value="Japan" {{ ( $comp['comp_legal_addr']['country'] == "Japan") ? 'selected' : '' }}>Japan</option>
                                        <option value="Jordan" {{ ( $comp['comp_legal_addr']['country'] == "Jordan") ? 'selected' : '' }}>Jordan</option>
                                        <option value="Kazakhstan" {{ ( $comp['comp_legal_addr']['country'] == "Kazakhstan") ? 'selected' : '' }}>Kazakhstan</option>
                                        <option value="Kenya" {{ ( $comp['comp_legal_addr']['country'] == "Kenya") ? 'selected' : '' }}>Kenya</option>
                                        <option value="Kiribati" {{ ( $comp['comp_legal_addr']['country'] == "Kiribati") ? 'selected' : '' }}>Kiribati</option>
                                        <option value="Korea North" {{ ( $comp['comp_legal_addr']['country'] == "Korea North") ? 'selected' : '' }}>Korea North</option>
                                        <option value="Korea Sout" {{ ( $comp['comp_legal_addr']['country'] == "Korea South") ? 'selected' : '' }}>Korea South</option>
                                        <option value="Kuwait" {{ ( $comp['comp_legal_addr']['country'] == "Kuwait") ? 'selected' : '' }}>Kuwait</option>
                                        <option value="Kyrgyzstan" {{ ( $comp['comp_legal_addr']['country'] == "Kyrgyzstan") ? 'selected' : '' }}>Kyrgyzstan</option>
                                        <option value="Laos" {{ ( $comp['comp_legal_addr']['country'] == "Laos") ? 'selected' : '' }}>Laos</option>
                                        <option value="Latvia" {{ ( $comp['comp_legal_addr']['country'] == "Latvia") ? 'selected' : '' }}>Latvia</option>
                                        <option value="Lebanon" {{ ( $comp['comp_legal_addr']['country'] == "Lebanon") ? 'selected' : '' }}>Lebanon</option>
                                        <option value="Lesotho" {{ ( $comp['comp_legal_addr']['country'] == "Lesotho") ? 'selected' : '' }}>Lesotho</option>
                                        <option value="Liberia" {{ ( $comp['comp_legal_addr']['country'] == "Liberia") ? 'selected' : '' }}>Liberia</option>
                                        <option value="Libya" {{ ( $comp['comp_legal_addr']['country'] == "Libya") ? 'selected' : '' }}>Libya</option>
                                        <option value="Liechtenstein" {{ ( $comp['comp_legal_addr']['country'] == "Liechtenstein") ? 'selected' : '' }}>Liechtenstein</option>
                                        <option value="Lithuania" {{ ( $comp['comp_legal_addr']['country'] == "Lithuania") ? 'selected' : '' }}>Lithuania</option>
                                        <option value="Luxembourg" {{ ( $comp['comp_legal_addr']['country'] == "Luxembourg") ? 'selected' : '' }}>Luxembourg</option>
                                        <option value="Macau" {{ ( $comp['comp_legal_addr']['country'] == "Macau") ? 'selected' : '' }}>Macau</option>
                                        <option value="Macedonia" {{ ( $comp['comp_legal_addr']['country'] == "Macedonia") ? 'selected' : '' }}>Macedonia</option>
                                        <option value="Madagascar" {{ ( $comp['comp_legal_addr']['country'] == "Madagascar") ? 'selected' : '' }}>Madagascar</option>
                                        <option value="Malaysia" {{ ( $comp['comp_legal_addr']['country'] == "Malaysia") ? 'selected' : '' }}>Malaysia</option>
                                        <option value="Malawi" {{ ( $comp['comp_legal_addr']['country'] == "Malawi") ? 'selected' : '' }}>Malawi</option>
                                        <option value="Maldives" {{ ( $comp['comp_legal_addr']['country'] == "Maldives") ? 'selected' : '' }}>Maldives</option>
                                        <option value="Mali" {{ ( $comp['comp_legal_addr']['country'] == "Mali") ? 'selected' : '' }}>Mali</option>
                                        <option value="Malta" {{ ( $comp['comp_legal_addr']['country'] == "Malta") ? 'selected' : '' }}>Malta</option>
                                        <option value="Marshall Islands" {{ ( $comp['comp_legal_addr']['country'] == "Marshall Islands") ? 'selected' : '' }}>Marshall Islands</option>
                                        <option value="Martinique" {{ ( $comp['comp_legal_addr']['country'] == "Martinique") ? 'selected' : '' }}>Martinique</option>
                                        <option value="Mauritania" {{ ( $comp['comp_legal_addr']['country'] == "Mauritania") ? 'selected' : '' }}>Mauritania</option>
                                        <option value="Mauritius" {{ ( $comp['comp_legal_addr']['country'] == "Mauritius") ? 'selected' : '' }}>Mauritius</option>
                                        <option value="Mayotte" {{ ( $comp['comp_legal_addr']['country'] == "Mayotte") ? 'selected' : '' }}>Mayotte</option>
                                        <option value="Mexico" {{ ( $comp['comp_legal_addr']['country'] == "Mexico") ? 'selected' : '' }}>Mexico</option>
                                        <option value="Midway Islands" {{ ( $comp['comp_legal_addr']['country'] == "Midway Islands") ? 'selected' : '' }}>Midway Islands</option>
                                        <option value="Moldova" {{ ( $comp['comp_legal_addr']['country'] == "Moldova") ? 'selected' : '' }}>Moldova</option>
                                        <option value="Monaco" {{ ( $comp['comp_legal_addr']['country'] == "Monaco") ? 'selected' : '' }}>Monaco</option>
                                        <option value="Mongolia" {{ ( $comp['comp_legal_addr']['country'] == "Mongolia") ? 'selected' : '' }}>Mongolia</option>
                                        <option value="Montserrat" {{ ( $comp['comp_legal_addr']['country'] == "Montserrat") ? 'selected' : '' }}>Montserrat</option>
                                        <option value="Morocco" {{ ( $comp['comp_legal_addr']['country'] == "Morocco") ? 'selected' : '' }}>Morocco</option>
                                        <option value="Mozambique" {{ ( $comp['comp_legal_addr']['country'] == "Mozambique") ? 'selected' : '' }}>Mozambique</option>
                                        <option value="Myanmar" {{ ( $comp['comp_legal_addr']['country'] == "Myanmar") ? 'selected' : '' }}>Myanmar</option>
                                        <option value="Nambia" {{ ( $comp['comp_legal_addr']['country'] == "Nambia") ? 'selected' : '' }}>Nambia</option>
                                        <option value="Nauru" {{ ( $comp['comp_legal_addr']['country'] == "Nauru") ? 'selected' : '' }}>Nauru</option>
                                        <option value="Nepal" {{ ( $comp['comp_legal_addr']['country'] == "Nepal") ? 'selected' : '' }}>Nepal</option>
                                        <option value="Netherland Antilles" {{ ( $comp['comp_legal_addr']['country'] == "Netherland Antilles") ? 'selected' : '' }}>Netherland Antilles</option>
                                        <option value="Netherlands" {{ ( $comp['comp_legal_addr']['country'] == "Netherlands (Holland, Europe)") ? 'selected' : '' }}>Netherlands (Holland, Europe)</option>
                                        <option value="Nevis" {{ ( $comp['comp_legal_addr']['country'] == "Nevis") ? 'selected' : '' }}>Nevis</option>
                                        <option value="New Caledonia" {{ ( $comp['comp_legal_addr']['country'] == "New Caledonia") ? 'selected' : '' }}>New Caledonia</option>
                                        <option value="New Zealand" {{ ( $comp['comp_legal_addr']['country'] == "New Zealand") ? 'selected' : '' }}>New Zealand</option>
                                        <option value="Nicaragua" {{ ( $comp['comp_legal_addr']['country'] == "Nicaragua") ? 'selected' : '' }}>Nicaragua</option>
                                        <option value="Niger" {{ ( $comp['comp_legal_addr']['country'] == "Niger") ? 'selected' : '' }}>Niger</option>
                                        <option value="Nigeria" {{ ( $comp['comp_legal_addr']['country'] == "Nigeria") ? 'selected' : '' }}>Nigeria</option>
                                        <option value="Niue" {{ ( $comp['comp_legal_addr']['country'] == "Niue") ? 'selected' : '' }}>Niue</option>
                                        <option value="Norfolk Island" {{ ( $comp['comp_legal_addr']['country'] == "Norfolk Island") ? 'selected' : '' }}>Norfolk Island</option>
                                        <option value="Norway" {{ ( $comp['comp_legal_addr']['country'] == "Norway") ? 'selected' : '' }}>Norway</option>
                                        <option value="Oman" {{ ( $comp['comp_legal_addr']['country'] == "Oman") ? 'selected' : '' }}>Oman</option>
                                        <option value="Pakistan" {{ ( $comp['comp_legal_addr']['country'] == "Pakistan") ? 'selected' : '' }}>Pakistan</option>
                                        <option value="Palau Island" {{ ( $comp['comp_legal_addr']['country'] == "Palau Island") ? 'selected' : '' }}>Palau Island</option>
                                        <option value="Palestine" {{ ( $comp['comp_legal_addr']['country'] == "Palestine") ? 'selected' : '' }}>Palestine</option>
                                        <option value="Panama" {{ ( $comp['comp_legal_addr']['country'] == "Panama") ? 'selected' : '' }}>Panama</option>
                                        <option value="Papua New Guinea" {{ ( $comp['comp_legal_addr']['country'] == "Papua New Guinea") ? 'selected' : '' }}>Papua New Guinea</option>
                                        <option value="Paraguay" {{ ( $comp['comp_legal_addr']['country'] == "Paraguay") ? 'selected' : '' }}>Paraguay</option>
                                        <option value="Peru" {{ ( $comp['comp_legal_addr']['country'] == "Peru") ? 'selected' : '' }}>Peru</option>
                                        <option value="Phillipines" {{ ( $comp['comp_legal_addr']['country'] == "Philippines") ? 'selected' : '' }}>Philippines</option>
                                        <option value="Pitcairn Island" {{ ( $comp['comp_legal_addr']['country'] == "Pitcairn Island") ? 'selected' : '' }}>Pitcairn Island</option>
                                        <option value="Poland" {{ ( $comp['comp_legal_addr']['country'] == "Poland") ? 'selected' : '' }}>Poland</option>
                                        <option value="Portugal" {{ ( $comp['comp_legal_addr']['country'] == "Portugal") ? 'selected' : '' }}>Portugal</option>
                                        <option value="Puerto Rico" {{ ( $comp['comp_legal_addr']['country'] == "Puerto Rico") ? 'selected' : '' }}>Puerto Rico</option>
                                        <option value="Qatar" {{ ( $comp['comp_legal_addr']['country'] == "Qatar") ? 'selected' : '' }}>Qatar</option>
                                        <option value="Republic of Montenegro" {{ ( $comp['comp_legal_addr']['country'] == "Republic of Montenegro") ? 'selected' : '' }}>Republic of Montenegro</option>
                                        <option value="Republic of Serbia" {{ ( $comp['comp_legal_addr']['country'] == "Republic of Serbia") ? 'selected' : '' }}>Republic of Serbia</option>
                                        <option value="Reunion" {{ ( $comp['comp_legal_addr']['country'] == "Reunion") ? 'selected' : '' }}>Reunion</option>
                                        <option value="Romania" {{ ( $comp['comp_legal_addr']['country'] == "Romania") ? 'selected' : '' }}>Romania</option>
                                        <option value="Russia" {{ ( $comp['comp_legal_addr']['country'] == "Russia") ? 'selected' : '' }}>Russia</option>
                                        <option value="Rwanda" {{ ( $comp['comp_legal_addr']['country'] == "Rwanda") ? 'selected' : '' }}>Rwanda</option>
                                        <option value="St Barthelemy" {{ ( $comp['comp_legal_addr']['country'] == "St Barthelemy") ? 'selected' : '' }}>St Barthelemy</option>
                                        <option value="St Eustatius" {{ ( $comp['comp_legal_addr']['country'] == "St Eustatius") ? 'selected' : '' }}>St Eustatius</option>
                                        <option value="St Helena" {{ ( $comp['comp_legal_addr']['country'] == "St Helena") ? 'selected' : '' }}>St Helena</option>
                                        <option value="St Kitts-Nevis" {{ ( $comp['comp_legal_addr']['country'] == "St Kitts-Nevis") ? 'selected' : '' }}>St Kitts-Nevis</option>
                                        <option value="St Lucia" {{ ( $comp['comp_legal_addr']['country'] == "St Lucia") ? 'selected' : '' }}>St Lucia</option>
                                        <option value="St Maarten" {{ ( $comp['comp_legal_addr']['country'] == "St Maarten") ? 'selected' : '' }}>St Maarten</option>
                                        <option value="St Pierre & Miquelon" {{ ( $comp['comp_legal_addr']['country'] == "St Pierre & Miquelon") ? 'selected' : '' }}>St Pierre & Miquelon</option>
                                        <option value="St Vincent & Grenadines" {{ ( $comp['comp_legal_addr']['country'] == "St Vincent & Grenadines") ? 'selected' : '' }}>St Vincent & Grenadines</option>
                                        <option value="Saipan" {{ ( $comp['comp_legal_addr']['country'] == "Saipan") ? 'selected' : '' }}>Saipan</option>
                                        <option value="Samoa" {{ ( $comp['comp_legal_addr']['country'] == "Samoa") ? 'selected' : '' }}>Samoa</option>
                                        <option value="Samoa American" {{ ( $comp['comp_legal_addr']['country'] == "Samoa American") ? 'selected' : '' }}>Samoa American</option>
                                        <option value="San Marino" {{ ( $comp['comp_legal_addr']['country'] == "San Marino") ? 'selected' : '' }}>San Marino</option>
                                        <option value="Sao Tome & Principe" {{ ( $comp['comp_legal_addr']['country'] == "Sao Tome & Principe") ? 'selected' : '' }}>Sao Tome & Principe</option>
                                        <option value="Saudi Arabia" {{ ( $comp['comp_legal_addr']['country'] == "Saudi Arabia") ? 'selected' : '' }}>Saudi Arabia</option>
                                        <option value="Senegal" {{ ( $comp['comp_legal_addr']['country'] == "Senegal") ? 'selected' : '' }}>Senegal</option>
                                        <option value="Seychelles" {{ ( $comp['comp_legal_addr']['country'] == "Seychelles") ? 'selected' : '' }}>Seychelles</option>
                                        <option value="Sierra Leone" {{ ( $comp['comp_legal_addr']['country'] == "Sierra Leone") ? 'selected' : '' }}>Sierra Leone</option>
                                        <option value="Singapore" {{ ( $comp['comp_legal_addr']['country'] == "Singapore") ? 'selected' : '' }}>Singapore</option>
                                        <option value="Slovakia" {{ ( $comp['comp_legal_addr']['country'] == "Slovakia") ? 'selected' : '' }}>Slovakia</option>
                                        <option value="Slovenia" {{ ( $comp['comp_legal_addr']['country'] == "Slovenia") ? 'selected' : '' }}>Slovenia</option>
                                        <option value="Solomon Islands" {{ ( $comp['comp_legal_addr']['country'] == "Solomon Islands") ? 'selected' : '' }}>Solomon Islands</option>
                                        <option value="Somalia" {{ ( $comp['comp_legal_addr']['country'] == "Somalia") ? 'selected' : '' }}>Somalia</option>
                                        <option value="South Africa" {{ ( $comp['comp_legal_addr']['country'] == "South Africa") ? 'selected' : '' }}>South Africa</option>
                                        <option value="Spain" {{ ( $comp['comp_legal_addr']['country'] == "Spain") ? 'selected' : '' }}>Spain</option>
                                        <option value="Sri Lanka" {{ ( $comp['comp_legal_addr']['country'] == "Sri Lanka") ? 'selected' : '' }}>Sri Lanka</option>
                                        <option value="Sudan" {{ ( $comp['comp_legal_addr']['country'] == "Sudan") ? 'selected' : '' }}>Sudan</option>
                                        <option value="Suriname" {{ ( $comp['comp_legal_addr']['country'] == "Suriname") ? 'selected' : '' }}>Suriname</option>
                                        <option value="Swaziland" {{ ( $comp['comp_legal_addr']['country'] == "Swaziland") ? 'selected' : '' }}>Swaziland</option>
                                        <option value="Sweden" {{ ( $comp['comp_legal_addr']['country'] == "Sweden") ? 'selected' : '' }}>Sweden</option>
                                        <option value="Switzerland" {{ ( $comp['comp_legal_addr']['country'] == "Switzerland") ? 'selected' : '' }}>Switzerland</option>
                                        <option value="Syria" {{ ( $comp['comp_legal_addr']['country'] == "Syria") ? 'selected' : '' }}>Syria</option>
                                        <option value="Tahiti" {{ ( $comp['comp_legal_addr']['country'] == "Tahiti") ? 'selected' : '' }}>Tahiti</option>
                                        <option value="Taiwan" {{ ( $comp['comp_legal_addr']['country'] == "Taiwan") ? 'selected' : '' }}>Taiwan</option>
                                        <option value="Tajikistan" {{ ( $comp['comp_legal_addr']['country'] == "Tajikistan") ? 'selected' : '' }}>Tajikistan</option>
                                        <option value="Tanzania" {{ ( $comp['comp_legal_addr']['country'] == "Tanzania") ? 'selected' : '' }}>Tanzania</option>
                                        <option value="Thailand" {{ ( $comp['comp_legal_addr']['country'] == "Thailand") ? 'selected' : '' }}>Thailand</option>
                                        <option value="Togo" {{ ( $comp['comp_legal_addr']['country'] == "Togo") ? 'selected' : '' }}>Togo</option>
                                        <option value="Tokelau" {{ ( $comp['comp_legal_addr']['country'] == "Tokelau") ? 'selected' : '' }}>Tokelau</option>
                                        <option value="Tonga" {{ ( $comp['comp_legal_addr']['country'] == "Tonga") ? 'selected' : '' }}>Tonga</option>
                                        <option value="Trinidad & Tobago" {{ ( $comp['comp_legal_addr']['country'] == "Trinidad & Tobago") ? 'selected' : '' }}>Trinidad & Tobago</option>
                                        <option value="Tunisia" {{ ( $comp['comp_legal_addr']['country'] == "Tunisia") ? 'selected' : '' }}>Tunisia</option>
                                        <option value="Turkey" {{ ( $comp['comp_legal_addr']['country'] == "Turkey") ? 'selected' : '' }}>Turkey</option>
                                        <option value="Turkmenistan" {{ ( $comp['comp_legal_addr']['country'] == "Turkmenistan") ? 'selected' : '' }}>Turkmenistan</option>
                                        <option value="Turks & Caicos Is" {{ ( $comp['comp_legal_addr']['country'] == "Turks & Caicos Is") ? 'selected' : '' }}>Turks & Caicos Is</option>
                                        <option value="Tuvalu" {{ ( $comp['comp_legal_addr']['country'] == "Tuvalu") ? 'selected' : '' }}>Tuvalu</option>
                                        <option value="Uganda" {{ ( $comp['comp_legal_addr']['country'] == "Uganda") ? 'selected' : '' }}>Uganda</option>
                                        <option value="United Kingdom" {{ ( $comp['comp_legal_addr']['country'] == "United Kingdom") ? 'selected' : '' }}>United Kingdom</option>
                                        <option value="Ukraine" {{ ( $comp['comp_legal_addr']['country'] == "Ukraine") ? 'selected' : '' }}>Ukraine</option>
                                        <option value="United Arab Erimates" {{ ( $comp['comp_legal_addr']['country'] == "United Arab Emirates") ? 'selected' : '' }}>United Arab Emirates</option>
                                        <option value="United States of America" {{ ( $comp['comp_legal_addr']['country'] == "United States of America") ? 'selected' : '' }}>United States of America</option>
                                        <option value="Uraguay" {{ ( $comp['comp_legal_addr']['country'] == "Uruguay") ? 'selected' : '' }}>Uruguay</option>
                                        <option value="Uzbekistan" {{ ( $comp['comp_legal_addr']['country'] == "Uzbekistan") ? 'selected' : '' }}>Uzbekistan</option>
                                        <option value="Vanuatu" {{ ( $comp['comp_legal_addr']['country'] == "Vanuatu") ? 'selected' : '' }}>Vanuatu</option>
                                        <option value="Vatican City State" {{ ( $comp['comp_legal_addr']['country'] == "Vatican City State") ? 'selected' : '' }}>Vatican City State</option>
                                        <option value="Venezuela" {{ ( $comp['comp_legal_addr']['country'] == "Venezuela") ? 'selected' : '' }}>Venezuela</option>
                                        <option value="Vietnam" {{ ( $comp['comp_legal_addr']['country'] == "Vietnam") ? 'selected' : '' }}>Vietnam</option>
                                        <option value="Virgin Islands (Brit)" {{ ( $comp['comp_legal_addr']['country'] == "Virgin Islands (Brit)") ? 'selected' : '' }}>Virgin Islands (Brit)</option>
                                        <option value="Virgin Islands (USA)" {{ ( $comp['comp_legal_addr']['country'] == "Virgin Islands (USA)") ? 'selected' : '' }}>Virgin Islands (USA)</option>
                                        <option value="Wake Island" {{ ( $comp['comp_legal_addr']['country'] == "Wake Island") ? 'selected' : '' }}>Wake Island</option>
                                        <option value="Wallis & Futana Is" {{ ( $comp['comp_legal_addr']['country'] == "Wallis & Futana Is") ? 'selected' : '' }}>Wallis & Futana Is</option>
                                        <option value="Yemen" {{ ( $comp['comp_legal_addr']['country'] == "Yemen") ? 'selected' : '' }}>Yemen</option>
                                        <option value="Zaire" {{ ( $comp['comp_legal_addr']['country'] == "Zaire") ? 'selected' : '' }}>Zaire</option>
                                        <option value="Zambia" {{ ( $comp['comp_legal_addr']['country'] == "Zambia") ? 'selected' : '' }}>Zambia</option>
                                        <option value="Zimbabwe" {{ ( $comp['comp_legal_addr']['country'] == "Zimbabwe") ? 'selected' : '' }}>Zimbabwe</option>
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Alternate Business Address</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Address Line 1</b></label>
                                    <input class="form-control" type="text" name="alt_addr_line_1" id="" value="{{$comp['comp_alt_addr']['line_1']??''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Address Line 2</b></label>
                                    <input class="form-control" type="text" name="alt_addr_line_2" id=""  value="{{$comp['comp_alt_addr']['line_2']??''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>State</b></label>
                                    <input class="form-control" type="text" name="alt_addr_state" id=""   value="{{$comp['comp_alt_addr']['state']??''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>City</b></label>
                                    <input class="form-control" type="text" name="alt_addr_city" id=""  value="{{$comp['comp_alt_addr']['city']??''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Postal Code</b></label>
                                    <input class="form-control" type="text" name="alt_addr_postal" id="" value="{{$comp['comp_alt_addr']['postal']??''}}"/>
                                </div>
                                
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Country</b></label>
                                    {{-- <input class="form-control" type="text" name="alt_addr_country" id=""/> --}}
                                    <select name="alt_addr_country" class="form-control">
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "Afganistan") ? 'selected' : '' }} value="Afganistan">Afghanistan</option>
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "Albania") ? 'selected' : '' }} value="Albania">Albania</option>
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "Algeria") ? 'selected' : '' }} value="Algeria">Algeria</option>
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "American Samoa") ? 'selected' : '' }} value="American Samoa">American Samoa</option>
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "Andorra") ? 'selected' : '' }} value="Andorra">Andorra</option>
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "Angola") ? 'selected' : '' }} value="Angola">Angola</option>
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "Anguilla") ? 'selected' : '' }} value="Anguilla">Anguilla</option>
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "Antigua & Barbuda") ? 'selected' : '' }} value="Antigua & Barbuda">Antigua & Barbuda</option>
                                        <option {{ ( $comp['comp_alt_addr']['country'] == "Argentina") ? 'selected' : '' }} value="Argentina">Argentina</option>
                                        <option value="Armenia" {{ ( $comp['comp_alt_addr']['country'] == "Armenia") ? 'selected' : '' }} >Armenia</option>
                                        <option value="Aruba">Aruba</option>
                                        <option value="Australia" {{ ( $comp['comp_alt_addr']['country'] == "Australia") ? 'selected' : '' }} >Australia</option>
                                        <option value="Austria" {{ ( $comp['comp_alt_addr']['country'] == "Austria") ? 'selected' : '' }}>Austria</option>
                                        <option value="Azerbaijan" {{ ( $comp['comp_alt_addr']['country'] == "Azerbaijan") ? 'selected' : '' }}>Azerbaijan</option>
                                        <option value="Bahamas" {{ ( $comp['comp_alt_addr']['country'] == "Bahamas") ? 'selected' : '' }}>Bahamas</option>
                                        <option value="Bahrain" {{ ( $comp['comp_alt_addr']['country'] == "Bahrain") ? 'selected' : '' }}>Bahrain</option>
                                        <option value="Bangladesh" {{ ( $comp['comp_alt_addr']['country'] == "Bangladesh") ? 'selected' : '' }}>Bangladesh</option>
                                        <option value="Barbados" {{ ( $comp['comp_alt_addr']['country'] == "Barbados") ? 'selected' : '' }}>Barbados</option>
                                        <option value="Belarus" {{ ( $comp['comp_alt_addr']['country'] == "Belarus") ? 'selected' : '' }}>Belarus</option>
                                        <option value="Belgium" {{ ( $comp['comp_alt_addr']['country'] == "Belgium") ? 'selected' : '' }}>Belgium</option>
                                        <option value="Belize" {{ ( $comp['comp_alt_addr']['country'] == "Belize") ? 'selected' : '' }}>Belize</option>
                                        <option value="Benin" {{ ( $comp['comp_alt_addr']['country'] == "Benin") ? 'selected' : '' }}>Benin</option>
                                        <option value="Bermuda" {{ ( $comp['comp_alt_addr']['country'] == "Bermuda") ? 'selected' : '' }}>Bermuda</option>
                                        <option value="Bhutan" {{ ( $comp['comp_alt_addr']['country'] == "Bhutan") ? 'selected' : '' }}>Bhutan</option>
                                        <option value="Bolivia" {{ ( $comp['comp_alt_addr']['country'] == "Bolivia") ? 'selected' : '' }}>Bolivia</option>
                                        <option value="Bonaire" {{ ( $comp['comp_alt_addr']['country'] == "Bonaire") ? 'selected' : '' }}>Bonaire</option>
                                        <option value="Bosnia & Herzegovina" {{ ( $comp['comp_alt_addr']['country'] == "Bosnia & Herzegovina") ? 'selected' : '' }}>Bosnia & Herzegovina</option>
                                        <option value="Botswana" {{ ( $comp['comp_alt_addr']['country'] == "Botswana") ? 'selected' : '' }}>Botswana</option>
                                        <option value="Brazil" {{ ( $comp['comp_alt_addr']['country'] == "Brazil") ? 'selected' : '' }}>Brazil</option>
                                        <option value="British Indian Ocean Ter" {{ ( $comp['comp_alt_addr']['country'] == "British Indian Ocean Ter") ? 'selected' : '' }}>British Indian Ocean Ter</option>
                                        <option value="Brunei" {{ ( $comp['comp_alt_addr']['country'] == "Brunei") ? 'selected' : '' }}>Brunei</option>
                                        <option value="Bulgaria" {{ ( $comp['comp_alt_addr']['country'] == "Bulgaria") ? 'selected' : '' }}>Bulgaria</option>
                                        <option value="Burkina Faso" {{ ( $comp['comp_alt_addr']['country'] == "Burkina Faso") ? 'selected' : '' }}>Burkina Faso</option>
                                        <option value="Burundi" {{ ( $comp['comp_alt_addr']['country'] == "Burundi") ? 'selected' : '' }}>Burundi</option>
                                        <option value="Cambodia" {{ ( $comp['comp_alt_addr']['country'] == "Cambodia") ? 'selected' : '' }}>Cambodia</option>
                                        <option value="Cameroon" {{ ( $comp['comp_alt_addr']['country'] == "Cameroon") ? 'selected' : '' }}>Cameroon</option>
                                        <option value="Canada" {{ ( $comp['comp_alt_addr']['country'] == "Canada") ? 'selected' : '' }}>Canada</option>
                                        <option value="Canary Islands" {{ ( $comp['comp_alt_addr']['country'] == "Canary Islands") ? 'selected' : '' }}>Canary Islands</option>
                                        <option value="Cape Verde" {{ ( $comp['comp_alt_addr']['country'] == "Cape Verde") ? 'selected' : '' }}>Cape Verde</option>
                                        <option value="Cayman Islands" {{ ( $comp['comp_alt_addr']['country'] == "Cayman Islands") ? 'selected' : '' }}>Cayman Islands</option>
                                        <option value="Central African Republic" {{ ( $comp['comp_alt_addr']['country'] == "Central African Republic") ? 'selected' : '' }}>Central African Republic</option>
                                        <option value="Chad" {{ ( $comp['comp_alt_addr']['country'] == "Chad") ? 'selected' : '' }}>Chad</option>
                                        <option value="Channel Islands" {{ ( $comp['comp_alt_addr']['country'] == "Channel Islands") ? 'selected' : '' }}>Channel Islands</option>
                                        <option value="Chile" {{ ( $comp['comp_alt_addr']['country'] == "Chile") ? 'selected' : '' }}>Chile</option>
                                        <option value="China" {{ ( $comp['comp_alt_addr']['country'] == "China") ? 'selected' : '' }}>China</option>
                                        <option value="Christmas Island" {{ ( $comp['comp_alt_addr']['country'] == "Christmas Island") ? 'selected' : '' }}>Christmas Island</option>
                                        <option value="Cocos Island" {{ ( $comp['comp_alt_addr']['country'] == "Cocos Island") ? 'selected' : '' }}>Cocos Island</option>
                                        <option value="Colombia" {{ ( $comp['comp_alt_addr']['country'] == "Colombia") ? 'selected' : '' }}>Colombia</option>
                                        <option value="Comoros" {{ ( $comp['comp_alt_addr']['country'] == "Comoros") ? 'selected' : '' }}>Comoros</option>
                                        <option value="Congo" {{ ( $comp['comp_alt_addr']['country'] == "Congo") ? 'selected' : '' }}>Congo</option>
                                        <option value="Cook Islands" {{ ( $comp['comp_alt_addr']['country'] == "Cook Islands") ? 'selected' : '' }}>Cook Islands</option>
                                        <option value="Costa Rica" {{ ( $comp['comp_alt_addr']['country'] == "Costa Rica") ? 'selected' : '' }}>Costa Rica</option>
                                        <option value="Cote DIvoire" {{ ( $comp['comp_alt_addr']['country'] == "Cote DIvoire") ? 'selected' : '' }}>Cote DIvoire</option>
                                        <option value="Croatia" {{ ( $comp['comp_alt_addr']['country'] == "Croatia") ? 'selected' : '' }}>Croatia</option>
                                        <option value="Cuba" {{ ( $comp['comp_alt_addr']['country'] == "Cuba") ? 'selected' : '' }}>Cuba</option>
                                        <option value="Curaco" {{ ( $comp['comp_alt_addr']['country'] == "Curacao") ? 'selected' : '' }}>Curacao</option>
                                        <option value="Cyprus" {{ ( $comp['comp_alt_addr']['country'] == "Cyprus") ? 'selected' : '' }}>Cyprus</option>
                                        <option value="Czech Republic" {{ ( $comp['comp_alt_addr']['country'] == "Czech Republic") ? 'selected' : '' }}>Czech Republic</option>
                                        <option value="Denmark" {{ ( $comp['comp_alt_addr']['country'] == "Denmark") ? 'selected' : '' }}>Denmark</option>
                                        <option value="Djibouti" {{ ( $comp['comp_alt_addr']['country'] == "Djibouti") ? 'selected' : '' }}>Djibouti</option>
                                        <option value="Dominica" {{ ( $comp['comp_alt_addr']['country'] == "Dominica") ? 'selected' : '' }}>Dominica</option>
                                        <option value="Dominican Republic" {{ ( $comp['comp_alt_addr']['country'] == "Dominican Republic") ? 'selected' : '' }}>Dominican Republic</option>
                                        <option value="East Timor" {{ ( $comp['comp_alt_addr']['country'] == "East Timor") ? 'selected' : '' }}>East Timor</option>
                                        <option value="Ecuador" {{ ( $comp['comp_alt_addr']['country'] == "Ecuador") ? 'selected' : '' }}>Ecuador</option>
                                        <option value="Egypt" {{ ( $comp['comp_alt_addr']['country'] == "Egypt") ? 'selected' : '' }}>Egypt</option>
                                        <option value="El Salvador" {{ ( $comp['comp_alt_addr']['country'] == "El Salvador") ? 'selected' : '' }}>El Salvador</option>
                                        <option value="Equatorial Guinea" {{ ( $comp['comp_alt_addr']['country'] == "Equatorial Guinea") ? 'selected' : '' }}>Equatorial Guinea</option>
                                        <option value="Eritrea" {{ ( $comp['comp_alt_addr']['country'] == "Eritrea") ? 'selected' : '' }}>Eritrea</option>
                                        <option value="Estonia" {{ ( $comp['comp_alt_addr']['country'] == "Estonia") ? 'selected' : '' }}>Estonia</option>
                                        <option value="Ethiopia" {{ ( $comp['comp_alt_addr']['country'] == "Ethiopia") ? 'selected' : '' }}>Ethiopia</option>
                                        <option value="Falkland Islands" {{ ( $comp['comp_alt_addr']['country'] == "Falkland Islands") ? 'selected' : '' }}>Falkland Islands</option>
                                        <option value="Faroe Islands" {{ ( $comp['comp_alt_addr']['country'] == "Faroe Islands") ? 'selected' : '' }}>Faroe Islands</option>
                                        <option value="Fiji" {{ ( $comp['comp_alt_addr']['country'] == "Fiji") ? 'selected' : '' }}>Fiji</option>
                                        <option value="Finland" {{ ( $comp['comp_alt_addr']['country'] == "Finland") ? 'selected' : '' }}>Finland</option>
                                        <option value="France" {{ ( $comp['comp_alt_addr']['country'] == "France") ? 'selected' : '' }}>France</option>
                                        <option value="French Guiana" {{ ( $comp['comp_alt_addr']['country'] == "French Guiana") ? 'selected' : '' }}>French Guiana</option>
                                        <option value="French Polynesia" {{ ( $comp['comp_alt_addr']['country'] == "French Polynesia") ? 'selected' : '' }}>French Polynesia</option>
                                        <option value="French Southern Ter" {{ ( $comp['comp_alt_addr']['country'] == "French Southern Ter") ? 'selected' : '' }}>French Southern Ter</option>
                                        <option value="Gabon" {{ ( $comp['comp_alt_addr']['country'] == "Gabon") ? 'selected' : '' }}>Gabon</option>
                                        <option value="Gambia" {{ ( $comp['comp_alt_addr']['country'] == "Gambia") ? 'selected' : '' }}>Gambia</option>
                                        <option value="Georgia" {{ ( $comp['comp_alt_addr']['country'] == "Georgia") ? 'selected' : '' }}>Georgia</option>
                                        <option value="Germany" {{ ( $comp['comp_alt_addr']['country'] == "Germany") ? 'selected' : '' }}>Germany</option>
                                        <option value="Ghana {{ ( $comp['comp_alt_addr']['country'] == "Ghana") ? 'selected' : '' }}">Ghana</option>
                                        <option value="Gibraltar" {{ ( $comp['comp_alt_addr']['country'] == "Gibraltar") ? 'selected' : '' }}>Gibraltar</option>
                                        <option value="Great Britain" {{ ( $comp['comp_alt_addr']['country'] == "Great Britain") ? 'selected' : '' }}>Great Britain</option>
                                        <option value="Greece" {{ ( $comp['comp_alt_addr']['country'] == "Greece") ? 'selected' : '' }}>Greece</option>
                                        <option value="Greenland" {{ ( $comp['comp_alt_addr']['country'] == "Greenland") ? 'selected' : '' }}>Greenland</option>
                                        <option value="Grenada" {{ ( $comp['comp_alt_addr']['country'] == "Grenada") ? 'selected' : '' }}>Grenada</option>
                                        <option value="Guadeloupe" {{ ( $comp['comp_alt_addr']['country'] == "Guadeloupe") ? 'selected' : '' }}>Guadeloupe</option>
                                        <option value="Guam" {{ ( $comp['comp_alt_addr']['country'] == "Guam") ? 'selected' : '' }}>Guam</option>
                                        <option value="Guatemala" {{ ( $comp['comp_alt_addr']['country'] == "Guatemala") ? 'selected' : '' }}>Guatemala</option>
                                        <option value="Guinea" {{ ( $comp['comp_alt_addr']['country'] == "Guinea") ? 'selected' : '' }}>Guinea</option>
                                        <option value="Guyana" {{ ( $comp['comp_alt_addr']['country'] == "Guyana") ? 'selected' : '' }}>Guyana</option>
                                        <option value="Haiti" {{ ( $comp['comp_alt_addr']['country'] == "Haiti") ? 'selected' : '' }}>Haiti</option>
                                        <option value="Hawaii" {{ ( $comp['comp_alt_addr']['country'] == "Hawaii") ? 'selected' : '' }}>Hawaii</option>
                                        <option value="Honduras" {{ ( $comp['comp_alt_addr']['country'] == "Honduras") ? 'selected' : '' }}>Honduras</option>
                                        <option value="Hong Kong" {{ ( $comp['comp_alt_addr']['country'] == "Hong Kong") ? 'selected' : '' }}>Hong Kong</option>
                                        <option value="Hungary" {{ ( $comp['comp_alt_addr']['country'] == "Hungary") ? 'selected' : '' }}>Hungary</option>
                                        <option value="Iceland" {{ ( $comp['comp_alt_addr']['country'] == "Iceland") ? 'selected' : '' }}>Iceland</option>
                                        <option value="Indonesia" {{ ( $comp['comp_alt_addr']['country'] == "Indonesia") ? 'selected' : '' }}>Indonesia</option>
                                        <option value="India" {{ ( $comp['comp_alt_addr']['country'] == "India") ? 'selected' : '' }}>India</option>
                                        <option value="Iran" {{ ( $comp['comp_alt_addr']['country'] == "Iran") ? 'selected' : '' }}>Iran</option>
                                        <option value="Iraq" {{ ( $comp['comp_alt_addr']['country'] == "Iraq") ? 'selected' : '' }}>Iraq</option>
                                        <option value="Ireland" {{ ( $comp['comp_alt_addr']['country'] == "Ireland") ? 'selected' : '' }}>Ireland</option>
                                        <option value="Isle of Man" {{ ( $comp['comp_alt_addr']['country'] == "Isle of Man") ? 'selected' : '' }}>Isle of Man</option>
                                        <option value="Israel" {{ ( $comp['comp_alt_addr']['country'] == "Israel") ? 'selected' : '' }}>Israel</option>
                                        <option value="Italy" {{ ( $comp['comp_alt_addr']['country'] == "Italy") ? 'selected' : '' }}>Italy</option>
                                        <option value="Jamaica" {{ ( $comp['comp_alt_addr']['country'] == "Jamaica") ? 'selected' : '' }}>Jamaica</option>
                                        <option value="Japan" {{ ( $comp['comp_alt_addr']['country'] == "Japan") ? 'selected' : '' }}>Japan</option>
                                        <option value="Jordan" {{ ( $comp['comp_alt_addr']['country'] == "Jordan") ? 'selected' : '' }}>Jordan</option>
                                        <option value="Kazakhstan" {{ ( $comp['comp_alt_addr']['country'] == "Kazakhstan") ? 'selected' : '' }}>Kazakhstan</option>
                                        <option value="Kenya" {{ ( $comp['comp_alt_addr']['country'] == "Kenya") ? 'selected' : '' }}>Kenya</option>
                                        <option value="Kiribati" {{ ( $comp['comp_alt_addr']['country'] == "Kiribati") ? 'selected' : '' }}>Kiribati</option>
                                        <option value="Korea North" {{ ( $comp['comp_alt_addr']['country'] == "Korea North") ? 'selected' : '' }}>Korea North</option>
                                        <option value="Korea Sout" {{ ( $comp['comp_alt_addr']['country'] == "Korea South") ? 'selected' : '' }}>Korea South</option>
                                        <option value="Kuwait" {{ ( $comp['comp_alt_addr']['country'] == "Kuwait") ? 'selected' : '' }}>Kuwait</option>
                                        <option value="Kyrgyzstan" {{ ( $comp['comp_alt_addr']['country'] == "Kyrgyzstan") ? 'selected' : '' }}>Kyrgyzstan</option>
                                        <option value="Laos" {{ ( $comp['comp_alt_addr']['country'] == "Laos") ? 'selected' : '' }}>Laos</option>
                                        <option value="Latvia" {{ ( $comp['comp_alt_addr']['country'] == "Latvia") ? 'selected' : '' }}>Latvia</option>
                                        <option value="Lebanon" {{ ( $comp['comp_alt_addr']['country'] == "Lebanon") ? 'selected' : '' }}>Lebanon</option>
                                        <option value="Lesotho" {{ ( $comp['comp_alt_addr']['country'] == "Lesotho") ? 'selected' : '' }}>Lesotho</option>
                                        <option value="Liberia" {{ ( $comp['comp_alt_addr']['country'] == "Liberia") ? 'selected' : '' }}>Liberia</option>
                                        <option value="Libya" {{ ( $comp['comp_alt_addr']['country'] == "Libya") ? 'selected' : '' }}>Libya</option>
                                        <option value="Liechtenstein" {{ ( $comp['comp_alt_addr']['country'] == "Liechtenstein") ? 'selected' : '' }}>Liechtenstein</option>
                                        <option value="Lithuania" {{ ( $comp['comp_alt_addr']['country'] == "Lithuania") ? 'selected' : '' }}>Lithuania</option>
                                        <option value="Luxembourg" {{ ( $comp['comp_alt_addr']['country'] == "Luxembourg") ? 'selected' : '' }}>Luxembourg</option>
                                        <option value="Macau" {{ ( $comp['comp_alt_addr']['country'] == "Macau") ? 'selected' : '' }}>Macau</option>
                                        <option value="Macedonia" {{ ( $comp['comp_alt_addr']['country'] == "Macedonia") ? 'selected' : '' }}>Macedonia</option>
                                        <option value="Madagascar" {{ ( $comp['comp_alt_addr']['country'] == "Madagascar") ? 'selected' : '' }}>Madagascar</option>
                                        <option value="Malaysia" {{ ( $comp['comp_alt_addr']['country'] == "Malaysia") ? 'selected' : '' }}>Malaysia</option>
                                        <option value="Malawi" {{ ( $comp['comp_alt_addr']['country'] == "Malawi") ? 'selected' : '' }}>Malawi</option>
                                        <option value="Maldives" {{ ( $comp['comp_alt_addr']['country'] == "Maldives") ? 'selected' : '' }}>Maldives</option>
                                        <option value="Mali" {{ ( $comp['comp_alt_addr']['country'] == "Mali") ? 'selected' : '' }}>Mali</option>
                                        <option value="Malta" {{ ( $comp['comp_alt_addr']['country'] == "Malta") ? 'selected' : '' }}>Malta</option>
                                        <option value="Marshall Islands" {{ ( $comp['comp_alt_addr']['country'] == "Marshall Islands") ? 'selected' : '' }}>Marshall Islands</option>
                                        <option value="Martinique" {{ ( $comp['comp_alt_addr']['country'] == "Martinique") ? 'selected' : '' }}>Martinique</option>
                                        <option value="Mauritania" {{ ( $comp['comp_alt_addr']['country'] == "Mauritania") ? 'selected' : '' }}>Mauritania</option>
                                        <option value="Mauritius" {{ ( $comp['comp_alt_addr']['country'] == "Mauritius") ? 'selected' : '' }}>Mauritius</option>
                                        <option value="Mayotte" {{ ( $comp['comp_alt_addr']['country'] == "Mayotte") ? 'selected' : '' }}>Mayotte</option>
                                        <option value="Mexico" {{ ( $comp['comp_alt_addr']['country'] == "Mexico") ? 'selected' : '' }}>Mexico</option>
                                        <option value="Midway Islands" {{ ( $comp['comp_alt_addr']['country'] == "Midway Islands") ? 'selected' : '' }}>Midway Islands</option>
                                        <option value="Moldova" {{ ( $comp['comp_alt_addr']['country'] == "Moldova") ? 'selected' : '' }}>Moldova</option>
                                        <option value="Monaco" {{ ( $comp['comp_alt_addr']['country'] == "Monaco") ? 'selected' : '' }}>Monaco</option>
                                        <option value="Mongolia" {{ ( $comp['comp_alt_addr']['country'] == "Mongolia") ? 'selected' : '' }}>Mongolia</option>
                                        <option value="Montserrat" {{ ( $comp['comp_alt_addr']['country'] == "Montserrat") ? 'selected' : '' }}>Montserrat</option>
                                        <option value="Morocco" {{ ( $comp['comp_alt_addr']['country'] == "Morocco") ? 'selected' : '' }}>Morocco</option>
                                        <option value="Mozambique" {{ ( $comp['comp_alt_addr']['country'] == "Mozambique") ? 'selected' : '' }}>Mozambique</option>
                                        <option value="Myanmar" {{ ( $comp['comp_alt_addr']['country'] == "Myanmar") ? 'selected' : '' }}>Myanmar</option>
                                        <option value="Nambia" {{ ( $comp['comp_alt_addr']['country'] == "Nambia") ? 'selected' : '' }}>Nambia</option>
                                        <option value="Nauru" {{ ( $comp['comp_alt_addr']['country'] == "Nauru") ? 'selected' : '' }}>Nauru</option>
                                        <option value="Nepal" {{ ( $comp['comp_alt_addr']['country'] == "Nepal") ? 'selected' : '' }}>Nepal</option>
                                        <option value="Netherland Antilles" {{ ( $comp['comp_alt_addr']['country'] == "Netherland Antilles") ? 'selected' : '' }}>Netherland Antilles</option>
                                        <option value="Netherlands" {{ ( $comp['comp_alt_addr']['country'] == "Netherlands (Holland, Europe)") ? 'selected' : '' }}>Netherlands (Holland, Europe)</option>
                                        <option value="Nevis" {{ ( $comp['comp_alt_addr']['country'] == "Nevis") ? 'selected' : '' }}>Nevis</option>
                                        <option value="New Caledonia" {{ ( $comp['comp_alt_addr']['country'] == "New Caledonia") ? 'selected' : '' }}>New Caledonia</option>
                                        <option value="New Zealand" {{ ( $comp['comp_alt_addr']['country'] == "New Zealand") ? 'selected' : '' }}>New Zealand</option>
                                        <option value="Nicaragua" {{ ( $comp['comp_alt_addr']['country'] == "Nicaragua") ? 'selected' : '' }}>Nicaragua</option>
                                        <option value="Niger" {{ ( $comp['comp_alt_addr']['country'] == "Niger") ? 'selected' : '' }}>Niger</option>
                                        <option value="Nigeria" {{ ( $comp['comp_alt_addr']['country'] == "Nigeria") ? 'selected' : '' }}>Nigeria</option>
                                        <option value="Niue" {{ ( $comp['comp_alt_addr']['country'] == "Niue") ? 'selected' : '' }}>Niue</option>
                                        <option value="Norfolk Island" {{ ( $comp['comp_alt_addr']['country'] == "Norfolk Island") ? 'selected' : '' }}>Norfolk Island</option>
                                        <option value="Norway" {{ ( $comp['comp_alt_addr']['country'] == "Norway") ? 'selected' : '' }}>Norway</option>
                                        <option value="Oman" {{ ( $comp['comp_alt_addr']['country'] == "Oman") ? 'selected' : '' }}>Oman</option>
                                        <option value="Pakistan" {{ ( $comp['comp_alt_addr']['country'] == "Pakistan") ? 'selected' : '' }}>Pakistan</option>
                                        <option value="Palau Island" {{ ( $comp['comp_alt_addr']['country'] == "Palau Island") ? 'selected' : '' }}>Palau Island</option>
                                        <option value="Palestine" {{ ( $comp['comp_alt_addr']['country'] == "Palestine") ? 'selected' : '' }}>Palestine</option>
                                        <option value="Panama" {{ ( $comp['comp_alt_addr']['country'] == "Panama") ? 'selected' : '' }}>Panama</option>
                                        <option value="Papua New Guinea" {{ ( $comp['comp_alt_addr']['country'] == "Papua New Guinea") ? 'selected' : '' }}>Papua New Guinea</option>
                                        <option value="Paraguay" {{ ( $comp['comp_alt_addr']['country'] == "Paraguay") ? 'selected' : '' }}>Paraguay</option>
                                        <option value="Peru" {{ ( $comp['comp_alt_addr']['country'] == "Peru") ? 'selected' : '' }}>Peru</option>
                                        <option value="Phillipines" {{ ( $comp['comp_alt_addr']['country'] == "Philippines") ? 'selected' : '' }}>Philippines</option>
                                        <option value="Pitcairn Island" {{ ( $comp['comp_alt_addr']['country'] == "Pitcairn Island") ? 'selected' : '' }}>Pitcairn Island</option>
                                        <option value="Poland" {{ ( $comp['comp_alt_addr']['country'] == "Poland") ? 'selected' : '' }}>Poland</option>
                                        <option value="Portugal" {{ ( $comp['comp_alt_addr']['country'] == "Portugal") ? 'selected' : '' }}>Portugal</option>
                                        <option value="Puerto Rico" {{ ( $comp['comp_alt_addr']['country'] == "Puerto Rico") ? 'selected' : '' }}>Puerto Rico</option>
                                        <option value="Qatar" {{ ( $comp['comp_alt_addr']['country'] == "Qatar") ? 'selected' : '' }}>Qatar</option>
                                        <option value="Republic of Montenegro" {{ ( $comp['comp_alt_addr']['country'] == "Republic of Montenegro") ? 'selected' : '' }}>Republic of Montenegro</option>
                                        <option value="Republic of Serbia" {{ ( $comp['comp_alt_addr']['country'] == "Republic of Serbia") ? 'selected' : '' }}>Republic of Serbia</option>
                                        <option value="Reunion" {{ ( $comp['comp_alt_addr']['country'] == "Reunion") ? 'selected' : '' }}>Reunion</option>
                                        <option value="Romania" {{ ( $comp['comp_alt_addr']['country'] == "Romania") ? 'selected' : '' }}>Romania</option>
                                        <option value="Russia" {{ ( $comp['comp_alt_addr']['country'] == "Russia") ? 'selected' : '' }}>Russia</option>
                                        <option value="Rwanda" {{ ( $comp['comp_alt_addr']['country'] == "Rwanda") ? 'selected' : '' }}>Rwanda</option>
                                        <option value="St Barthelemy" {{ ( $comp['comp_alt_addr']['country'] == "St Barthelemy") ? 'selected' : '' }}>St Barthelemy</option>
                                        <option value="St Eustatius" {{ ( $comp['comp_alt_addr']['country'] == "St Eustatius") ? 'selected' : '' }}>St Eustatius</option>
                                        <option value="St Helena" {{ ( $comp['comp_alt_addr']['country'] == "St Helena") ? 'selected' : '' }}>St Helena</option>
                                        <option value="St Kitts-Nevis" {{ ( $comp['comp_alt_addr']['country'] == "St Kitts-Nevis") ? 'selected' : '' }}>St Kitts-Nevis</option>
                                        <option value="St Lucia" {{ ( $comp['comp_alt_addr']['country'] == "St Lucia") ? 'selected' : '' }}>St Lucia</option>
                                        <option value="St Maarten" {{ ( $comp['comp_alt_addr']['country'] == "St Maarten") ? 'selected' : '' }}>St Maarten</option>
                                        <option value="St Pierre & Miquelon" {{ ( $comp['comp_alt_addr']['country'] == "St Pierre & Miquelon") ? 'selected' : '' }}>St Pierre & Miquelon</option>
                                        <option value="St Vincent & Grenadines" {{ ( $comp['comp_alt_addr']['country'] == "St Vincent & Grenadines") ? 'selected' : '' }}>St Vincent & Grenadines</option>
                                        <option value="Saipan" {{ ( $comp['comp_alt_addr']['country'] == "Saipan") ? 'selected' : '' }}>Saipan</option>
                                        <option value="Samoa" {{ ( $comp['comp_alt_addr']['country'] == "Samoa") ? 'selected' : '' }}>Samoa</option>
                                        <option value="Samoa American" {{ ( $comp['comp_alt_addr']['country'] == "Samoa American") ? 'selected' : '' }}>Samoa American</option>
                                        <option value="San Marino" {{ ( $comp['comp_alt_addr']['country'] == "San Marino") ? 'selected' : '' }}>San Marino</option>
                                        <option value="Sao Tome & Principe" {{ ( $comp['comp_alt_addr']['country'] == "Sao Tome & Principe") ? 'selected' : '' }}>Sao Tome & Principe</option>
                                        <option value="Saudi Arabia" {{ ( $comp['comp_alt_addr']['country'] == "Saudi Arabia") ? 'selected' : '' }}>Saudi Arabia</option>
                                        <option value="Senegal" {{ ( $comp['comp_alt_addr']['country'] == "Senegal") ? 'selected' : '' }}>Senegal</option>
                                        <option value="Seychelles" {{ ( $comp['comp_alt_addr']['country'] == "Seychelles") ? 'selected' : '' }}>Seychelles</option>
                                        <option value="Sierra Leone" {{ ( $comp['comp_alt_addr']['country'] == "Sierra Leone") ? 'selected' : '' }}>Sierra Leone</option>
                                        <option value="Singapore" {{ ( $comp['comp_alt_addr']['country'] == "Singapore") ? 'selected' : '' }}>Singapore</option>
                                        <option value="Slovakia" {{ ( $comp['comp_alt_addr']['country'] == "Slovakia") ? 'selected' : '' }}>Slovakia</option>
                                        <option value="Slovenia" {{ ( $comp['comp_alt_addr']['country'] == "Slovenia") ? 'selected' : '' }}>Slovenia</option>
                                        <option value="Solomon Islands" {{ ( $comp['comp_alt_addr']['country'] == "Solomon Islands") ? 'selected' : '' }}>Solomon Islands</option>
                                        <option value="Somalia" {{ ( $comp['comp_alt_addr']['country'] == "Somalia") ? 'selected' : '' }}>Somalia</option>
                                        <option value="South Africa" {{ ( $comp['comp_alt_addr']['country'] == "South Africa") ? 'selected' : '' }}>South Africa</option>
                                        <option value="Spain" {{ ( $comp['comp_alt_addr']['country'] == "Spain") ? 'selected' : '' }}>Spain</option>
                                        <option value="Sri Lanka" {{ ( $comp['comp_alt_addr']['country'] == "Sri Lanka") ? 'selected' : '' }}>Sri Lanka</option>
                                        <option value="Sudan" {{ ( $comp['comp_alt_addr']['country'] == "Sudan") ? 'selected' : '' }}>Sudan</option>
                                        <option value="Suriname" {{ ( $comp['comp_alt_addr']['country'] == "Suriname") ? 'selected' : '' }}>Suriname</option>
                                        <option value="Swaziland" {{ ( $comp['comp_alt_addr']['country'] == "Swaziland") ? 'selected' : '' }}>Swaziland</option>
                                        <option value="Sweden" {{ ( $comp['comp_alt_addr']['country'] == "Sweden") ? 'selected' : '' }}>Sweden</option>
                                        <option value="Switzerland" {{ ( $comp['comp_alt_addr']['country'] == "Switzerland") ? 'selected' : '' }}>Switzerland</option>
                                        <option value="Syria" {{ ( $comp['comp_alt_addr']['country'] == "Syria") ? 'selected' : '' }}>Syria</option>
                                        <option value="Tahiti" {{ ( $comp['comp_alt_addr']['country'] == "Tahiti") ? 'selected' : '' }}>Tahiti</option>
                                        <option value="Taiwan" {{ ( $comp['comp_alt_addr']['country'] == "Taiwan") ? 'selected' : '' }}>Taiwan</option>
                                        <option value="Tajikistan" {{ ( $comp['comp_alt_addr']['country'] == "Tajikistan") ? 'selected' : '' }}>Tajikistan</option>
                                        <option value="Tanzania" {{ ( $comp['comp_alt_addr']['country'] == "Tanzania") ? 'selected' : '' }}>Tanzania</option>
                                        <option value="Thailand" {{ ( $comp['comp_alt_addr']['country'] == "Thailand") ? 'selected' : '' }}>Thailand</option>
                                        <option value="Togo" {{ ( $comp['comp_alt_addr']['country'] == "Togo") ? 'selected' : '' }}>Togo</option>
                                        <option value="Tokelau" {{ ( $comp['comp_alt_addr']['country'] == "Tokelau") ? 'selected' : '' }}>Tokelau</option>
                                        <option value="Tonga" {{ ( $comp['comp_alt_addr']['country'] == "Tonga") ? 'selected' : '' }}>Tonga</option>
                                        <option value="Trinidad & Tobago" {{ ( $comp['comp_alt_addr']['country'] == "Trinidad & Tobago") ? 'selected' : '' }}>Trinidad & Tobago</option>
                                        <option value="Tunisia" {{ ( $comp['comp_alt_addr']['country'] == "Tunisia") ? 'selected' : '' }}>Tunisia</option>
                                        <option value="Turkey" {{ ( $comp['comp_alt_addr']['country'] == "Turkey") ? 'selected' : '' }}>Turkey</option>
                                        <option value="Turkmenistan" {{ ( $comp['comp_alt_addr']['country'] == "Turkmenistan") ? 'selected' : '' }}>Turkmenistan</option>
                                        <option value="Turks & Caicos Is" {{ ( $comp['comp_alt_addr']['country'] == "Turks & Caicos Is") ? 'selected' : '' }}>Turks & Caicos Is</option>
                                        <option value="Tuvalu" {{ ( $comp['comp_alt_addr']['country'] == "Tuvalu") ? 'selected' : '' }}>Tuvalu</option>
                                        <option value="Uganda" {{ ( $comp['comp_alt_addr']['country'] == "Uganda") ? 'selected' : '' }}>Uganda</option>
                                        <option value="United Kingdom" {{ ( $comp['comp_alt_addr']['country'] == "United Kingdom") ? 'selected' : '' }}>United Kingdom</option>
                                        <option value="Ukraine" {{ ( $comp['comp_alt_addr']['country'] == "Ukraine") ? 'selected' : '' }}>Ukraine</option>
                                        <option value="United Arab Erimates" {{ ( $comp['comp_alt_addr']['country'] == "United Arab Emirates") ? 'selected' : '' }}>United Arab Emirates</option>
                                        <option value="United States of America" {{ ( $comp['comp_alt_addr']['country'] == "United States of America") ? 'selected' : '' }}>United States of America</option>
                                        <option value="Uraguay" {{ ( $comp['comp_alt_addr']['country'] == "Uruguay") ? 'selected' : '' }}>Uruguay</option>
                                        <option value="Uzbekistan" {{ ( $comp['comp_alt_addr']['country'] == "Uzbekistan") ? 'selected' : '' }}>Uzbekistan</option>
                                        <option value="Vanuatu" {{ ( $comp['comp_alt_addr']['country'] == "Vanuatu") ? 'selected' : '' }}>Vanuatu</option>
                                        <option value="Vatican City State" {{ ( $comp['comp_alt_addr']['country'] == "Vatican City State") ? 'selected' : '' }}>Vatican City State</option>
                                        <option value="Venezuela" {{ ( $comp['comp_alt_addr']['country'] == "Venezuela") ? 'selected' : '' }}>Venezuela</option>
                                        <option value="Vietnam" {{ ( $comp['comp_alt_addr']['country'] == "Vietnam") ? 'selected' : '' }}>Vietnam</option>
                                        <option value="Virgin Islands (Brit)" {{ ( $comp['comp_alt_addr']['country'] == "Virgin Islands (Brit)") ? 'selected' : '' }}>Virgin Islands (Brit)</option>
                                        <option value="Virgin Islands (USA)" {{ ( $comp['comp_alt_addr']['country'] == "Virgin Islands (USA)") ? 'selected' : '' }}>Virgin Islands (USA)</option>
                                        <option value="Wake Island" {{ ( $comp['comp_alt_addr']['country'] == "Wake Island") ? 'selected' : '' }}>Wake Island</option>
                                        <option value="Wallis & Futana Is" {{ ( $comp['comp_alt_addr']['country'] == "Wallis & Futana Is") ? 'selected' : '' }}>Wallis & Futana Is</option>
                                        <option value="Yemen" {{ ( $comp['comp_alt_addr']['country'] == "Yemen") ? 'selected' : '' }}>Yemen</option>
                                        <option value="Zaire" {{ ( $comp['comp_alt_addr']['country'] == "Zaire") ? 'selected' : '' }}>Zaire</option>
                                        <option value="Zambia" {{ ( $comp['comp_alt_addr']['country'] == "Zambia") ? 'selected' : '' }}>Zambia</option>
                                        <option value="Zimbabwe" {{ ( $comp['comp_alt_addr']['country'] == "Zimbabwe") ? 'selected' : '' }}>Zimbabwe</option>
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Point Of Contact</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-3">
                                    <label><b>Name</b></label>
                                    <input class="form-control" type="text" name="comp_poc_name" id="" value="{{$comp['comp_contact_person']['name']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Phone</b></label>
                                    <input class="form-control" type="text" name="comp_poc_phone" id="" value="{{$comp['comp_contact_person']['phone']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Mobile</b></label>
                                    <input class="form-control" type="text" name="comp_poc_mobile" id="" value="{{$comp['comp_contact_person']['mobile']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Email</b></label>
                                    <input class="form-control" type="text" name="comp_poc_email" id="" value="{{$comp['comp_contact_person']['email']??''}}"/>
                                </div>
                            </div>
                            
                        </fieldset>

                        <fieldset>
                            <legend>(Alt) Point Of Contact</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-3">
                                    <label><b>Name</b></label>
                                    <input class="form-control" type="text" name="comp_alt_poc_name" id="" value="{{$comp['comp_alt_contact_person']['name']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Phone</b></label>
                                    <input class="form-control" type="text" name="comp_alt_poc_phone" id="" value="{{$comp['comp_alt_contact_person']['phone']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Mobile</b></label>
                                    <input class="form-control" type="text" name="comp_alt_poc_mobile" id="" value="{{$comp['comp_alt_contact_person']['mobile']??''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Email</b></label>
                                    <input class="form-control" type="text" name="comp_alt_poc_email" id="" value="{{$comp['comp_alt_contact_person']['email']??''}}"/>
                                </div>
                            </div>
                        </fieldset>

                        <fieldset>
                            <legend>Invoice Number Setup</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Invoice Prefix (Max 10 Char.)</b></label>
                                    <input class="form-control" type="text" name="comp_inv_prefix" id=""  value="{{$comp['comp_inv_prefix']??''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Invoice Year (Max 4 Char.)</b></label>
                                    <input class="form-control" type="text" name="comp_inv_year" id=""  value="{{$comp['comp_inv_year']??''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Invoice Number (Max 4 Char.)</b></label>
                                    <input class="form-control" type="text" name="comp_inv_number" id=""  value="{{$comp['comp_inv_number']??''}}"/>
                                </div>
                            </div>
                        </fieldset>
                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Update Company
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section("custom_script")
    

@endsection