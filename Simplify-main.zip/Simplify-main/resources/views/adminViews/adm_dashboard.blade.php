@extends('layouts.admin')
@section('content')



<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800"><b></b></h1>
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">



</div>

<div class="custom-container">
    <div class="box">
        <h2>COA</h2>
        <h3><i class="fas fa-clipboard-list"></i></h3>
        <p>
            Chart Of Accounts : 2
        </p>
        <div class="">
            <ul class="btngps">
                <li><a href="{{url('/admin/create-COA')}}"><i class="far fa-plus-square" aria-hidden="true"></i> Create COA</a></li>
                <li><a href="{{url('/admin/COA-list')}}"><i class="fas fa-layer-group"></i> COA List</a></li>
            </ul>
            
        </div>
    </div>
    <div class="box">
        <h2>Company</h2>
        <h3><i class="far fa-building"></i></h3>
        <p>
            Companies : 2000
        </p>
        <div class="">
            <ul class="btngps">
                <li><a href="{{url('/admin/create-company')}}"><i class="far fa-plus-square" aria-hidden="true"></i> Create Company</a></li>
                <li><a href="{{url('/admin/company-list')}}"><i class="fas fa-layer-group"></i> Companies List</a></li>
            </ul>
            
        </div>
    </div>
    <div class="box">
        <h2>Reports</h2>
        <h3><i class="fas fa-chart-pie"></i></h3>
        <p>
            Reports : 100
        </p>
        <div class="">
            <ul class="btngps">
                {{-- <li><a href="{{url('/admin/user')}}"><i class="far fa-plus-square" aria-hidden="true"></i> Create User</a></li> --}}
                <li><a href="{{url('/admin/comp-user-list')}}"><i class="fas fa-layer-group"></i>  List</a></li>
            </ul>
            
        </div>
    </div>
    <div class="box">
        <h2>Profile</h2>
        <h3><i class="far fa-id-badge"></i></h3>
        <p>
            Total Profiles : 2
        </p>
        <div class="">
            <ul class="btngps">
                {{-- <li><a href="{{url('/admin/vendor')}}"><i class="far fa-plus-square" aria-hidden="true"></i> Create Vendor</a></li> --}}
                <li><a href="{{url('/admin/comp-user-list')}}"><i class="fas fa-layer-group"></i> List</a></li>
            </ul>
            
        </div>
    </div>
    
</div>

@endsection