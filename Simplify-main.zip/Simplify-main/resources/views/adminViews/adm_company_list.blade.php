@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3" style="display: flex;justify-content: space-between;align-items: center;">
                    <div>
                        <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}"><i class="fas fa-arrow-left"></i></a> <b>Company List</b> </h6>                    
                    </div>
                    <div>
                        <i class="fas fa-download mr-1 text-primary"></i><a href="#" class="font-weight-bold text-primary"> Download </a>
                    </div>    
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th><b>#</b></th>
                                    <th><b>Company Name</b></th>
                                    <th><b>Business Reg No.</b></th>
                                    <th><b>GST/VAT Reg No.</b></th>
                                    <th><b>Incorporate Date</b></th>
                                    <th><b>Entity Type</b></th>
                                    <th><b>Edit</b></th>
                                    <th><b>Action</b></th>
                                </tr>

                            </thead>

                           
                            <tfoot>
                                <tr>
                                    <th><b>#</b></th>
                                    <th><b>Company Name</b></th>
                                    <th><b>Business Reg No.</b></th>
                                    <th><b>GST/VAT Reg No.</b></th>
                                    <th><b>Incorporate Date</b></th>
                                    <th><b>Entity Type</b></th>
                                    <th><b>Edit</b></th>
                                    <th><b>Action</b></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @isset($compList)
                                @foreach($compList as $noti)
                                <tr>
                                    <td>{{$loop->index + 1}}</td>
                                    <td>{{$noti['comp_name']}}</td>
                                    <td>{{$noti['comp_reg_number']}}</td>
                                    <td>{{$noti['comp_gst_number']}}</td>
                                    <td>{{$noti['comp_incorp_date']}}</td>
                                    <td>{{$noti['comp_entity_type']}}</td>
                                    <td>
                                        <a href="{{url('/admin/company-detail')}}/{{$noti['comp_id']}}" class="text-primary">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                    </td>
                                    @if ($noti['comp_sts'] == 'Active')
                                    <td>
                                        <a href="{{url('/admin/company-deactivate')}}/{{$noti['comp_id']}}" class="btn btn-danger">Deactivate</a>
                                    </td>
                                    @else
                                    <td>
                                        <a href="{{url('/admin/company-activate')}}/{{$noti['comp_id']}}" class="btn btn-light">Activate</a>
                                    </td>
                                    @endif
                                </tr>
                                @endforeach
                                @endisset
                                {{-- <tr>
                                    <td>2</td>
                                    <td>Comp Name 2</td>
                                    <td>1234567</td>
                                    <td>1234567</td>
                                    <td>04/12/2005</td>
                                    <td>Partnership</td>
                                    <td>
                                        <a href="{{url('/admin/edit-company')}}/" class="text-primary">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                    </td>
                                    <td>
                                        <button class="btn btn-outline-primary">Deactivate</button>
                                    </td>
                                </tr> --}}
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
@section('custom_script')
<script>
    $(document).ready(function () {
        $('#notidataTable').DataTable();
    });
</script>
@endsection