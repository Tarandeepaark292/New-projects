@extends('layouts.admin')
@section('content')



<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>

<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Data Entry (Supplier Payment)</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('admin/account-recieve-create')}}" method="post" accept-charset="utf-8"
                    enctype="multipart/form-data">
                    @csrf
                    <fieldset>
                        <legend>Invoice Info</legend>

                        <div class="form-row">
                            {{-- <div class="form-group col-lg-5">
                                <label><b>Supplier Name</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                                
                            </div>
                            <div class="form-group col-lg-2" style="text-align: center;display: flex;justify-content: center;align-items: center;font-size: 2rem;">
                                <b><span>OR</span> </b>
                            </div> --}}
                            <div class="form-group col-lg-5">
                                <label><b>Select Supplier Name</b></label>
                                <select class="form-control">
                                    <option value="">Select Supplier</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-4">
                                <label><b>Invoice No.</b></label>
                                {{-- <input class="form-control" type="text" name="" id=""/> --}}
                                <select class="form-control">
                                    <option value="">Select Invoice</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-4">
                                <label><b>Date of Invoice</b></label>
                                <input class="form-control" type="date" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-4">
                                <label><b>Invoice Due Date</b></label>
                                <input class="form-control" type="date" name="" id="" readonly/>
                            </div>
                        </div>
                        

                        {{-- <div class="form-row">
                            <div class="form-group col-lg-5">
                                <label><b>Customer Name</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                            <div class="form-group col-lg-2" style="text-align: center;display: flex;justify-content: center;align-items: center;font-size: 2rem;">
                                <b><span>OR</span> </b>
                            </div>
                            <div class="form-group col-lg-5">
                                <label><b>Select Customer Name</b></label>
                                <select class="form-control">
                                    <option value="">Select Customer</option>
                                </select>
                            </div>
                        </div> --}}
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label><b>Invoice Description</b></label>
                                <textarea class="form-control" name="notes" id="" cols="30" rows="5" readonly></textarea>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-3">
                                <label><b>Invoice Currency</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Invoice Net Amt</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Invoice GST</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Invoice Gross Amt</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-3">
                                <label><b>Exchange Rate</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Translated Invoice Net Amt</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Translated Invoice GST</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Translated Invoice Gross Amt</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>

                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label><b>Payment amount</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-6">
                                <label><b>Outstanding amount</b></label>
                                <input class="form-control" type="text" name="" id="" readonly />
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label><b>Nature of Transaction</b></label>
                                <select class="form-control">
                                    <option value="">Select</option>
                                </select>
                            </div>
                            
                        </div>

                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <input onclick="" checked="checked" name="check_cust" type="checkbox" id="check_cust" value="" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Cash</span><br>
                                <input onclick="" name="check_cust" type="checkbox" id="check_cust" value="" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Credit</span><br>
                                <input onclick="" name="check_cust" type="checkbox" id="check_cust" value="" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Expenses Paid in Advance</span>
                            </div>
                            <div class="form-group col-lg-6">
                                
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label><b>Is Fixed Asset?</b></label><br/>
                                <input onclick="" name="check_cust" type="checkbox" id="check_cust_fa" value="" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Fixed Asset</span>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label><b>Fixed Assets Category</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                            </div>
                            <div class="form-group col-lg-6">
                                <label><b>Fixed Assets Comments</b></label>
                                <textarea class="form-control"></textarea>
                            </div>
                        </div>

                    </fieldset>
                    <fieldset>
                        <legend>Payment Section</legend>
                        
                    
                        <div class="form-row">
                            <div class="form-group col-lg-4">
                                <label><b>Payment Method</b></label>
                                <select class="form-control">
                                    <option value="">Select</option>
                                    <option value="">Cash</option>
                                    <option value="">Cash at Bank</option>
                                    <option value="">Prepaid</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-4">
                                <label><b>Bank Account No.</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                            <div class="form-group col-lg-4">
                                <label><b>Cheque No.</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                        </div>
                        
                        <div class="form-row">
                        </div>
                    </fieldset>
                    <div class="row" style="text-align:center;">
                        <div class="col-lg-12 ml-auto">
                            <button class="btn-cutom">
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                Create
                            </button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
@section('custom_script')
<script type="text/javascript">
    function test(){
        var trans_nat = $('#sel_trans_nat').val();
        console.log(trans_nat);
        if(trans_nat === '1'){
            $('#check_cust_fa').prop('checked',true);
        }else{
            $('#check_cust_fa').prop('checked',false);
        }
    }
</script>
@endsection