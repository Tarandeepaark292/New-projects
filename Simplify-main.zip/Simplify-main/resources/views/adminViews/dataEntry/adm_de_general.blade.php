@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>

<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Data Entry (General Journal)</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('admin/account-recieve-create')}}" method="post" accept-charset="utf-8"
                    enctype="multipart/form-data">
                    @csrf
                    <fieldset>
                        <legend>General Journal Info</legend>
                        <div class="form-row">
                            {{-- <div class="form-group col-lg-4">
                                <label><b>Invoice No.</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div> --}}
                            <div class="form-group col-lg-4">
                                <label><b>Invoice Date</b></label>
                                <input class="form-control" type="date" name="" id=""/>
                            </div>
                            <div class="form-group col-lg-4">
                                <label><b>Account Code</b></label>
                                <select class="form-control">
                                    <option value="">Select COA</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-4">
                                <label><b>Account Name</b></label>
                                <input class="form-control" type="text" name="" id="" readonly/>
                                {{-- <br /> OR <br/> --}}

                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-6">
                                <label><b>Select Debit/Credit</b></label>
                                <select class="form-control">
                                    <option value="">Debit</option>
                                    <option value="">Credit</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-6">
                                <label><b>Transaction Description</b></label>
                                <textarea class="form-control" cols="30" rows="5"></textarea>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group col-lg-3">
                                <label><b>Currency</b></label>
                                <select class="form-control">
                                    <option value="-1">Select Currency</option>
                                    <option value="">SGC</option>
                                    <option value="">USD</option>
                                    <option value="">INR</option>
                                </select>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Invoice Net Amt</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Invoice GST</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Invoice Gross Amt</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-lg-3">
                                <label><b>Exchange Rate</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Translated Invoice Net Amt</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Translated Invoice GST</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>
                            <div class="form-group col-lg-3">
                                <label><b>Translated Invoice Gross Amt</b></label>
                                <input class="form-control" type="text" name="" id=""/>
                            </div>

                        </div>
                        
                        
                    </fieldset>
                    <div class="row" style="text-align:center;">
                        <div class="col-lg-12 ml-auto">
                            <button class="btn-cutom">
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                Create
                            </button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
