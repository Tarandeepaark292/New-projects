@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>

<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Supplier Data Entry Wizard</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('/admin/dataentry/form/select')}}" method="post" accept-charset="utf-8"
                    enctype="multipart/form-data">
                    @csrf
                    <fieldset>
                        <legend>Company</legend>
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label><b>Select Company</b></label>
                                {{-- <input class="form-control" type="text" name="acc_code" id=""/> --}}
                                <select class="form-control" name="comp_id" id="comp_id">
                                    <option value="-1">Select</option>
                                    @foreach ($companylist as $comp)
                                    <option value="{{$comp['comp_id']}}">{{$comp['comp_name']}}</option>
                                    @endforeach
                                    
                                </select>
                            </div>
                        </div>
                    </fieldset>
                    <fieldset>
                        <legend>Supplier Transaction Data Entry Modes</legend>
                        <div class="form-row">
                            <div class="form-group col-lg-12">
                                <label><b>Select Data Entry Mode</b></label>
                                {{-- <input class="form-control" type="text" name="acc_code" id=""/> --}}
                                <select class="form-control" name="supplier_de_type" id="supplier_de_type"  onchange="">
                                    <option value="-1">Select</option>
                                    <option value="1">Supplier Invoice</option>
                                    <option value="2">Supplier Payment</option>
                                    {{-- <option value="3">Customer Invoice</option>
                                    <option value="4">Supplier Receipt</option> --}}
                                    {{-- <option value="3">Reverse/Cancel</option>
                                    <option value="4">Amend</option> --}}
                                </select>
                            </div>
                        </div>
                    </fieldset>
                    <div class="row" style="text-align:center;">
                        <div class="col-lg-12 ml-auto">
                            <button class="btn-cutom">
                                <span></span>
                                <span></span>
                                <span></span>
                                <span></span>
                                Submit
                            </button>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection