@php
    
    $fn_mnth=explode(",",$acc_detail[0]->ac_financial_month);
    $gst=explode(",",$acc_detail[0]->ac_gst);
    // dd($gst);
@endphp

@extends('layouts.admin')
@section('content')



<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Company financial Setup</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('admin/acc-setup-update')}}/{{$acc_detail[0]->ac_id}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <legend>Company</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Select Company</b></label>
                                    {{-- <input class="form-control" type="text" name="acc_code" id=""/> --}}
                                    <select class="form-control" name="comp_id" id="comp_id">
                                        <option value="-1">Select</option>
                                        @foreach ($companylist as $comp)
                                        
                                        <option value="{{$comp['comp_id']}}" {{ ( $acc_detail[0]->ac_company == $comp['comp_id']) ? 'selected' : '' }}>{{$comp['comp_name']}}</option>
                                        @endforeach
                                        
                                        
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Company Bank Information</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank_name" id="" value="{{$acc_detail[0]->ac_bank_name}}"/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_code" id="" value="{{$acc_detail[0]->ac_bank_code}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank_branch_name" id="" value="{{$acc_detail[0]->ac_branch_name}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_branch_code" id="" value="{{$acc_detail[0]->ac_branch_code}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Swift Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_swift_code" id="" value="{{$acc_detail[0]->ac_swift_code}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Intermediary Bank</b></label>
                                    <input class="form-control" type="text" name="comp_bank_intermed" id="" value="{{$acc_detail[0]->ac_inter_bank}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Type</b></label>
                                    <input class="form-control" type="text" name="comp_bank_acc_type" id="" value="{{$acc_detail[0]->ac_acc_type}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Number</b></label>
                                    <input class="form-control" type="text" name="comp_bank_acc_number" id="" value="{{$acc_detail[0]->ac_acc_number}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label for=""><b>Is Multicurrency Support</b></label><br/>
                                    
                                    {{-- <input onclick="onchkclick()" name="check_cust" type="checkbox" id="check_cust" value="" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Corresponding Customer</span>
                                    <input type="hidden" id="acc_chk_asset_vals" name="acc_chk_asset_vals" value=1 /> --}}
                                    @if($acc_detail[0]->ac_multi_support == 0)
                                        <input onclick="onchkclick()" name="check_cust" type="checkbox" id="check_cust"  value="{{$acc_detail[0]->ac_multi_support}}" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Yes</span>
                                        <input type="hidden" id="acc_chk_asset_vals" name="acc_chk_asset_vals" value=0 />
                                    @else
                                        <input onclick="onchkclick()" name="check_cust" type="checkbox" id="check_cust" checked="checked" value="{{$acc_detail[0]->ac_multi_support}}" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Yes</span>
                                        <input type="hidden" id="acc_chk_asset_vals" name="acc_chk_asset_vals" value=1 />
                                    @endif
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Accounting Period</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Start Period</b></label>
                                    <select name="start_period" class="form-control">
                                        <option value="-1">Select Start Period</option>
                                        <option value="2000" {{ ( $acc_detail[0]->ac_strt_period == "2000") ? 'selected' : '' }} >2000</option>
                                        <option value="2001" {{ ( $acc_detail[0]->ac_strt_period == "2001") ? 'selected' : '' }} >2001</option>
                                        <option value="2002" {{ ( $acc_detail[0]->ac_strt_period == "2002") ? 'selected' : '' }} >2002</option>
                                        <option value="2003" {{ ( $acc_detail[0]->ac_strt_period == "2003") ? 'selected' : '' }} >2003</option>
                                        <option value="2004" {{ ( $acc_detail[0]->ac_strt_period == "2004") ? 'selected' : '' }} >2004</option>
                                        <option value="2005" {{ ( $acc_detail[0]->ac_strt_period == "2005") ? 'selected' : '' }} >2005</option>
                                        <option value="2006" {{ ( $acc_detail[0]->ac_strt_period == "2006") ? 'selected' : '' }} >2006</option>
                                        <option value="2007" {{ ( $acc_detail[0]->ac_strt_period == "2007") ? 'selected' : '' }} >2007</option>
                                        <option value="2008" {{ ( $acc_detail[0]->ac_strt_period == "2008") ? 'selected' : '' }} >2008</option>
                                        <option value="2009" {{ ( $acc_detail[0]->ac_strt_period == "2009") ? 'selected' : '' }} >2009</option>
                                        <option value="2010" {{ ( $acc_detail[0]->ac_strt_period == "2010") ? 'selected' : '' }} >2010</option>
                                        <option value="2011" {{ ( $acc_detail[0]->ac_strt_period == "2011") ? 'selected' : '' }} >2011</option>
                                        <option value="2012" {{ ( $acc_detail[0]->ac_strt_period == "2012") ? 'selected' : '' }} >2012</option>
                                        <option value="2013" {{ ( $acc_detail[0]->ac_strt_period == "2013") ? 'selected' : '' }} >2013</option>
                                        <option value="2014" {{ ( $acc_detail[0]->ac_strt_period == "2014") ? 'selected' : '' }} >2014</option>
                                        <option value="2015" {{ ( $acc_detail[0]->ac_strt_period == "2015") ? 'selected' : '' }} >2015</option>
                                        <option value="2016" {{ ( $acc_detail[0]->ac_strt_period == "2016") ? 'selected' : '' }} >2016</option>
                                        <option value="2017" {{ ( $acc_detail[0]->ac_strt_period == "2017") ? 'selected' : '' }} >2017</option>
                                        <option value="2018" {{ ( $acc_detail[0]->ac_strt_period == "2018") ? 'selected' : '' }} >2018</option>
                                        <option value="2019" {{ ( $acc_detail[0]->ac_strt_period == "2019") ? 'selected' : '' }} >2019</option>
                                        <option value="2021" {{ ( $acc_detail[0]->ac_strt_period == "2021") ? 'selected' : '' }} >2021</option>
                                        <option value="2022" {{ ( $acc_detail[0]->ac_strt_period == "2022") ? 'selected' : '' }} >2022</option>
                                        <option value="2023" {{ ( $acc_detail[0]->ac_strt_period == "2023") ? 'selected' : '' }} >2023</option>
                                        <option value="2024" {{ ( $acc_detail[0]->ac_strt_period == "2024") ? 'selected' : '' }} >2024</option>
                                        <option value="2025" {{ ( $acc_detail[0]->ac_strt_period == "2025") ? 'selected' : '' }} >2025</option>

                                        
                                        
                                    </select>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>End Period</b></label>
                                    <select name="end_period" class="form-control">
                                        <option value="-1">Select End Period</option>
                                        <option value="2000" {{ ( $acc_detail[0]->ac_end_period == "2000") ? 'selected' : '' }} >2000</option>
                                        <option value="2001" {{ ( $acc_detail[0]->ac_end_period == "2001") ? 'selected' : '' }} >2001</option>
                                        <option value="2002" {{ ( $acc_detail[0]->ac_end_period == "2002") ? 'selected' : '' }} >2002</option>
                                        <option value="2003" {{ ( $acc_detail[0]->ac_end_period == "2003") ? 'selected' : '' }} >2003</option>
                                        <option value="2004" {{ ( $acc_detail[0]->ac_end_period == "2004") ? 'selected' : '' }} >2004</option>
                                        <option value="2005" {{ ( $acc_detail[0]->ac_end_period == "2005") ? 'selected' : '' }} >2005</option>
                                        <option value="2006" {{ ( $acc_detail[0]->ac_end_period == "2006") ? 'selected' : '' }} >2006</option>
                                        <option value="2007" {{ ( $acc_detail[0]->ac_end_period == "2007") ? 'selected' : '' }} >2007</option>
                                        <option value="2008" {{ ( $acc_detail[0]->ac_end_period == "2008") ? 'selected' : '' }} >2008</option>
                                        <option value="2009" {{ ( $acc_detail[0]->ac_end_period == "2009") ? 'selected' : '' }} >2009</option>
                                        <option value="2010" {{ ( $acc_detail[0]->ac_end_period == "2010") ? 'selected' : '' }} >2010</option>
                                        <option value="2011" {{ ( $acc_detail[0]->ac_end_period == "2011") ? 'selected' : '' }} >2011</option>
                                        <option value="2012" {{ ( $acc_detail[0]->ac_end_period == "2012") ? 'selected' : '' }} >2012</option>
                                        <option value="2013" {{ ( $acc_detail[0]->ac_end_period == "2013") ? 'selected' : '' }} >2013</option>
                                        <option value="2014" {{ ( $acc_detail[0]->ac_end_period == "2014") ? 'selected' : '' }} >2014</option>
                                        <option value="2015" {{ ( $acc_detail[0]->ac_end_period == "2015") ? 'selected' : '' }} >2015</option>
                                        <option value="2016" {{ ( $acc_detail[0]->ac_end_period == "2016") ? 'selected' : '' }} >2016</option>
                                        <option value="2017" {{ ( $acc_detail[0]->ac_end_period == "2017") ? 'selected' : '' }} >2017</option>
                                        <option value="2018" {{ ( $acc_detail[0]->ac_end_period == "2018") ? 'selected' : '' }} >2018</option>
                                        <option value="2019" {{ ( $acc_detail[0]->ac_end_period == "2019") ? 'selected' : '' }} >2019</option>
                                        <option value="2021" {{ ( $acc_detail[0]->ac_end_period == "2021") ? 'selected' : '' }} >2021</option>
                                        <option value="2022" {{ ( $acc_detail[0]->ac_end_period == "2022") ? 'selected' : '' }} >2022</option>
                                        <option value="2023" {{ ( $acc_detail[0]->ac_end_period == "2023") ? 'selected' : '' }} >2023</option>
                                        <option value="2024" {{ ( $acc_detail[0]->ac_end_period == "2024") ? 'selected' : '' }} >2024</option>
                                        <option value="2025" {{ ( $acc_detail[0]->ac_end_period == "2025") ? 'selected' : '' }} >2025</option>
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Active Accounting Period</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Active Financial Year</b></label>
                                    <select name="act_fin_yr" class="form-control">
                                        <option value="-1">Select Financial Year</option>
                                        <option value="2000" {{ ( $acc_detail[0]->ac_financial == "2000") ? 'selected' : '' }} >2000</option>
                                        <option value="2001" {{ ( $acc_detail[0]->ac_financial == "2001") ? 'selected' : '' }} >2001</option>
                                        <option value="2002" {{ ( $acc_detail[0]->ac_financial == "2002") ? 'selected' : '' }} >2002</option>
                                        <option value="2003" {{ ( $acc_detail[0]->ac_financial == "2003") ? 'selected' : '' }} >2003</option>
                                        <option value="2004" {{ ( $acc_detail[0]->ac_financial == "2004") ? 'selected' : '' }} >2004</option>
                                        <option value="2005" {{ ( $acc_detail[0]->ac_financial == "2005") ? 'selected' : '' }} >2005</option>
                                        <option value="2006" {{ ( $acc_detail[0]->ac_financial == "2006") ? 'selected' : '' }} >2006</option>
                                        <option value="2007" {{ ( $acc_detail[0]->ac_financial == "2007") ? 'selected' : '' }} >2007</option>
                                        <option value="2008" {{ ( $acc_detail[0]->ac_financial == "2008") ? 'selected' : '' }} >2008</option>
                                        <option value="2009" {{ ( $acc_detail[0]->ac_financial == "2009") ? 'selected' : '' }} >2009</option>
                                        <option value="2010" {{ ( $acc_detail[0]->ac_financial == "2010") ? 'selected' : '' }} >2010</option>
                                        <option value="2011" {{ ( $acc_detail[0]->ac_financial == "2011") ? 'selected' : '' }} >2011</option>
                                        <option value="2012" {{ ( $acc_detail[0]->ac_financial == "2012") ? 'selected' : '' }} >2012</option>
                                        <option value="2013" {{ ( $acc_detail[0]->ac_financial == "2013") ? 'selected' : '' }} >2013</option>
                                        <option value="2014" {{ ( $acc_detail[0]->ac_financial == "2014") ? 'selected' : '' }} >2014</option>
                                        <option value="2015" {{ ( $acc_detail[0]->ac_financial == "2015") ? 'selected' : '' }} >2015</option>
                                        <option value="2016" {{ ( $acc_detail[0]->ac_financial == "2016") ? 'selected' : '' }} >2016</option>
                                        <option value="2017" {{ ( $acc_detail[0]->ac_financial == "2017") ? 'selected' : '' }} >2017</option>
                                        <option value="2018" {{ ( $acc_detail[0]->ac_financial == "2018") ? 'selected' : '' }} >2018</option>
                                        <option value="2019" {{ ( $acc_detail[0]->ac_financial == "2019") ? 'selected' : '' }} >2019</option>
                                        <option value="2021" {{ ( $acc_detail[0]->ac_financial == "2021") ? 'selected' : '' }} >2021</option>
                                        <option value="2022" {{ ( $acc_detail[0]->ac_financial == "2022") ? 'selected' : '' }} >2022</option>
                                        <option value="2023" {{ ( $acc_detail[0]->ac_financial == "2023") ? 'selected' : '' }} >2023</option>
                                        <option value="2024" {{ ( $acc_detail[0]->ac_financial == "2024") ? 'selected' : '' }} >2024</option>
                                        <option value="2025" {{ ( $acc_detail[0]->ac_financial == "2025") ? 'selected' : '' }} >2025</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-8">
                                    <label><b>Active Financial Month</b></label><br/>
                                    {{-- <select name="act_fin_mon" class="form-control">
                                        <option value="All">All</option>
                                    </select> --}}
                                    <input  type="checkbox" name="category1[]" value="January" {{ (in_array("January",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">January</span>
                                    <input  type="checkbox" name="category1[]" value="February" {{ (in_array("February",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">February</span>
                                    <input  type="checkbox" name="category1[]" value="March" {{ (in_array("March",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">March</span>
                                    <input  type="checkbox" name="category1[]" value="April" {{ (in_array("April",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">April</span>
                                    <input  type="checkbox" name="category1[]" value="May" {{ (in_array("May",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">May</span>
                                    <input  type="checkbox" name="category1[]" value="June" {{ (in_array("June",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">June</span>
                                    <input  type="checkbox" name="category1[]" value="July" {{ (in_array("July",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">July</span>
                                    <input  type="checkbox" name="category1[]" value="August" {{ (in_array("August",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">August</span>
                                    <input  type="checkbox" name="category1[]" value="September" {{ (in_array("September",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">September</span>
                                    <input  type="checkbox" name="category1[]" value="October" {{ (in_array("October",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">October</span>
                                    <input  type="checkbox" name="category1[]" value="November" {{ (in_array("November",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">November</span>
                                    <input  type="checkbox" name="category1[]" value="December" {{ (in_array("December",$fn_mnth)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">December</span>
                                   
                                   
                                   
                                    
                                  
                                   
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Company Currency</b></label>
                                    <select name="comp_curr" class="form-control">
                                        <option value="USD">USD</option>
                                        <option value="INR">INR</option>
                                        <option value="AUD">AUD</option>
                                    </select>
                                </div>
                            {{-- </div>
                            <div class="form-row"> --}}
                                <div class="form-group col-lg-8">
                                    <label><b>Select GST Rate</b></label><br/>
                                    <input  type="checkbox" name="category[]" value="18" {{ (in_array("18",$gst)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">18%</span>
                                    <input  type="checkbox" name="category[]" value="5" {{ (in_array("5",$gst)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">5%</span>
                                    <input  type="checkbox" name="category[]" value="20" {{ (in_array("20",$gst)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">20%</span>
                                    <input  type="checkbox" name="category[]" value="3" {{ (in_array("3",$gst)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">3%</span>
                                    <input  type="checkbox" name="category[]" value="24" {{ (in_array("24",$gst)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">24%</span>
                                    <input  type="checkbox" name="category[]" value="12" {{ (in_array("12",$gst)) ? 'checked="checked"' : '' }} style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">12%</span>
                                    
                                    
                                    {{-- <select name="gstrate" id="gstrate" multiple="multiple" class="form-control">
                                        <option value="18%">18%</option>
                                        <option value="6%">6%</option>
                                        <option value="12%">12%</option>
                                        <option value="24%">24%</option>
                                        <option value="18%">18%</option>
                                        <option value="6%">6%</option>
                                        <option value="12%">12%</option>
                                        <option value="24%">24%</option>
                                    </select> --}}
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Select Date Format</b></label>
                                    <select name="comp_dateformat" class="form-control">
                                        <option value="dd/mm/yy">dd/mm/yy </option>
                                        <option value="mm/dd/yy">mm/dd/yy</option>
                                    </select>
                                    
                                </div>
                                <div class="form-group col-lg-8">
                                    <label><b>Document Format</b></label>
                                    <div style="display:flex">
                                        <ul>
                                            <li>Customer Invoice 	CI</li>
                                            <li>Receive Customer Payment	CP</li>
                                            <li>Supplier Invoice	SI</li>
                                            <li>Invoice Payment	SP</li>
                                        </ul>
                                        <ul>
                                            <li>Depreciation	DP</li>
                                            <li>Journal Entries	DP</li>
                                            <li>Opening Balance	OB</li>
                                        </ul>
                                    </div>
                                    
                                </div>
                            </div>
                        </fieldset>

                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Setup
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('custom_script')
<script type="text/javascript">
$(document).ready(function() {
    // $('#gstrate').multiselect();
});
</script>
<script>
    function onchkclick(){
            $('#acc_chk_asset_vals').val('');
            chkeles = $('#check_cust');
            if($(chkeles).prop('checked') == true){
                console.log("checked");
                $('#acc_chk_asset_vals').val(1);
            }else{
                console.log("not checked");
                $('#acc_chk_asset_vals').val(0);
            }


            // chkeles.each((index,value)=>{
            //     if($(value).prop('checked') == true){
            //         if($('#cates').val() === ''){
            //             $('#cates').val( $(value).val());
            //         }else{
            //             $('#cates').val( $('#cates').val() + ',' + $(value).val());
            //         }
                    
            //     }
            // });
            // console.log($('#cates').val());
        }
</script>


@endsection