@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>

<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b>Useful life Creation</b> </h6>
                </div>
                <div class="card-body">
                    
                    <fieldset>
                        <legend>Useful-Life-Names</legend>
                        <div class="table-responsive">
                            <table class="table table-bordered" style="font-size: 14px;" id="notidataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th><b>#</b></th>
                                        <th><b>Useful Life Names</b></th>
                                    </tr>
                                </thead>
                                <tfoot>
                                    <tr>

                                    </tr>
                                </tfoot>
                                <tbody>
                                    @isset($useful_list)
                                    @foreach($useful_list as $noti)
                                    <tr>
                                        <td>{{$loop->index + 1}}</td>
                                        <td>{{$noti['u_life']}}</td>
                                    </tr>
                                    @endforeach
                                    @else
                                    skhsvh
                                    @endisset
                                </tbody>
                            </table>
                        </div>
                    </fieldset>
                    <form action="{{url('/admin/generate-fa-useful-life')}}" method="post" accept-charset="utf-8"
                    enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <legend>Fixed Assets Useful life Information</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Fixed Assets Useful life Value</b></label>
                                    <input class="form-control" type="text" name="useful_life_value" id=""/>
                                </div>
                            </div>
                        </fieldset>
                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Create Fixed Asset Useful life
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@section('custom_script')
<script>
    $(document).ready(function () {
        $('#notidataTable').DataTable();
    });
</script>

@endsection
