@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3" style="display: flex;justify-content: space-between;align-items: center;">
                    <div>
                        <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}"><i class="fas fa-arrow-left"></i></a> <b>Chart Of Account List</b> <a class="btn btn-sm btn-outline-primary" style="margin-left: 2rem"  href="{{url('/admin/create-COA')}}"> <i class="fas fa-plus"></i> Create </a>  </h6>  
                                        
                    </div>
                    <div>
                        <i class="fas fa-download mr-1 text-primary"></i><a href="#" class="font-weight-bold text-primary"> Download </a>
                    </div>    
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" style="font-size: 14px;" id="notidataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th><b>#</b></th>
                                    <th><b>Acc Code</b></th>
                                    <th><b>Accounts</b></th>
                                    <th><b>Desc</b></th>
                                    <th><b>Base Acc Nature</b></th>
                                    <th><b>Auto Fixed Assets</b></th>
                                    <th><b>Data Entry Behaviour</b></th>
                                    <th><b>Financial Stmt</b></th>
                                    <th><b>FS Main Cate</b></th>
                                    <th><b>FS Main Sub Cate</b></th>
                                    <th><b>Status</b></th>
                                    <th><b>Date Of Inactivation</b></th>
                                    <th><b>Action</b></th>
                                    <th><b>Edit</b></th>
                                </tr>

                            </thead>

                           
                            <tfoot>
                                <tr>
                                    <th><b>#</b></th>
                                    <th><b>Acc Code</b></th>
                                    <th><b>Accounts</b></th>
                                    <th><b>Desc</b></th>
                                    <th><b>Base Acc Nature</b></th>
                                    <th><b>Auto Fixed Assets</b></th>
                                    <th><b>Data Entry Behaviour</b></th>
                                    <th><b>Financial Stmt</b></th>
                                    <th><b>FS Main Cate</b></th>
                                    <th><b>FS Main Sub Cate</b></th>
                                    <th><b>Status</b></th>
                                    <th><b>Date Of Inactivation</b></th>
                                    <th><b>Action</b></th>
                                    <th><b>Edit</b></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @isset($coaList)
                                @foreach($coaList as $noti)
                                <tr>
                                    <td>{{$loop->index + 1}}</td>
                                    <td>{{$noti['coa_acc_code']}}</td>
                                    <td>{{$noti['coa_acc_name']}}</td>
                                    <td>{{$noti['coa_acc_desc']}}</td>
                                    <td>{{$noti['coa_base_acc_nat']}}</td>
                                    <td>{{$noti['coa_fix_asset']}}</td>
                                    <td>{{$noti['coa_data_entry_beh']}}</td>
                                    <td>{{$noti['coa_fin_stat']}}</td>
                                    <td>{{$noti['coa_fin_stat_main_cate']}}</td>
                                    <td>{{$noti['coa_fin_stat_sub_cate']}}</td>
                                    <td>{{$noti['coa_act_sts']}}</td>
                                    <td>{{$noti['coa_deactivate_time']}}</td>
                                    @if ($noti['coa_act_sts'] == 'Active')
                                    <td>
                                        <a href="{{url('/admin/COA-deactivate')}}/{{$noti['coa_id']}}" class="btn btn-danger">Deactivate</a>
                                    </td>
                                    @else
                                    <td>
                                        <a href="{{url('/admin/COA-activate')}}/{{$noti['coa_id']}}" class="btn btn-light">Activate</a>
                                    </td>
                                    @endif
                                    <td>
                                       
                                        <a href="{{url('/admin/COA-detail')}}/{{$noti['coa_id']}}" class="text-primary">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                        
                                    </td>
                                </tr>
                                @endforeach
                                @endisset

                                {{-- <tr>
                                    <td>2</td>
                                    <td>102</td>
                                    <td>Furniture and Fiittings</td>
                                    <td>Refer to Fixed Assets Setup</td>
                                    <td>Debit</td>
                                    <td>Yes</td>
                                    <td>+</td>
                                    <td>BS</td>
                                    <td>Total Assets</td>
                                    <td>Non Current Assets +ve</td>
                                    <td>Active</td>
                                    <td>N/A</td>
                                    <td>
                                       
                                        <a href="{{url('/admin/edit-COA')}}/" class="text-primary">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                        
                                    </td>
                                </tr> --}}
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



@endsection
@section('custom_script')
<script>
    $(document).ready(function () {
        $('#notidataTable').DataTable();
    });
</script>
@endsection