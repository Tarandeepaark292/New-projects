@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Update Chart Of Accounts</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('admin/update-coa')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        @if($errors->any())
                        @error('error_reason')
                        <h4 style="color:red">{{$errors->first()}}</h4>
                        @enderror
                        @endif
                        @if($coa['coa_act_sts'] == 0)
                        <h4 style="color:red">This Chart of Account is INACTIVE </h4>
                        @endif
                        <fieldset>
                            <legend>Data Detail</legend>
                            <input type="hidden" value="{{$coa['coa_id']}}" name="coa_id"/>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Accounts Code</b></label>
                                    <input class="form-control" type="text" name="acc_code" id="" value="{{$coa['coa_acc_code']}}"/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Accounts Name</b></label>
                                    <input class="form-control" type="text" name="acc_name" id="" value="{{$coa['coa_acc_name']}}"/>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Account Description</b></label>
                                    <textarea name="acc_desc" class="form-control" rows="5"
                                        style="height: auto;resize: none;" required>{{$coa['coa_acc_desc']}}
                                    </textarea>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Base Account Nature</b></label>
                                    <select class="form-control" name="acc_nature" id="">
                                        <option value="">Select</option>
                                        <option value="Debit" {{ ( $coa['coa_base_acc_nat'] == "Debit") ? 'selected' : '' }} >Debit</option>
                                        <option value="Credit" {{ ( $coa['coa_base_acc_nat'] == "Credit") ? 'selected' : '' }}>Credit</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-6">
                                    <div class="checkbox">
                                        <label><b>
                                            Select Auto Fixed Assets</b>
                                        </label><br/>
                                        <input onclick="onchkclick()" {{ ( $coa['coa_fix_asset'] == 1) ? 'checked' : '' }} type="checkbox" id="acc_chk_asset" value="" style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">Auto Fixed Assets Field Checked</span>
                                        <input type="hidden" id="acc_chk_asset_val" name="acc_chk_asset_val" value={{$coa['coa_fix_asset']}} />
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Data Entry Behaviour</b></label>
                                    <select class="form-control" name="acc_beh" id="">
                                        <option value="">Select</option>
                                        <option value="+" {{ ( $coa['coa_data_entry_beh'] == "+") ? 'selected' : '' }}>Plus (+)</option>
                                        <option value="-" {{ ( $coa['coa_data_entry_beh'] == "-") ? 'selected' : '' }}>Minus (-)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Financial Statement</b></label>
                                    <select class="form-control" name="acc_fin_stmt" id="">
                                        <option value="">Select</option>
                                        <option value="BS" {{ ( $coa['coa_fin_stat'] == "BS") ? 'selected' : '' }}>BS (Balance sheet)</option>
                                        <option value="PL" {{ ( $coa['coa_fin_stat'] == "PL") ? 'selected' : '' }}>PL (Profit and Loss)</option>
                                        
                                    </select>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Financial Statement Main Category</b></label>
                                    <select class="form-control" name="main_cate" id="">
                                        <option value="-1">Select</option>
                                        @foreach ($main_cates as $cate)
                                        <option value="{{$cate['main_cate_id']}}" {{ ( $coa['coa_fin_stat_main_cate'] == $cate['main_cate_id']) ? 'selected' : '' }}>{{$cate['main_cate_name']}}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-lg-4">
                                    <label><b>Financial Statement Sub Category</b></label>
                                    <select class="form-control" name="sub_cate" id="">
                                        <option value="-1">Select</option>
                                        @foreach ($sub_cates as $cate)
                                        <option value="{{$cate['sub_cate_id']}}" {{ ( $coa['coa_fin_stat_sub_cate'] == $cate['sub_cate_id']) ? 'selected' : '' }}>{{$cate['sub_cate_name']}}</option>
                                        @endforeach
                                        
                                    </select>
                                </div>
                            </div>

                            {{-- <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <div class="checkbox">
                                        <label><b>
                                            Select Status
                                        </b>
                                        </label><br/>
                                        <input type="checkbox" value="" style="margin-right: 1rem">
                                        <span style="height:calc(1.5em + 0.75rem + 2px)">Mark Account Inactive</span>
                                    </div>
                                </div>
                            </div> --}}

                            

                        </fieldset>
                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Update
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section("custom_script")
<script>
    function onchkclick(){
            $('#acc_chk_asset_val').val('');
            chkeles = $('#acc_chk_asset');
            if($(chkeles).prop('checked') == true){
                console.log("checked");
                $('#acc_chk_asset_val').val(1);
            }else{
                console.log("not checked");
                $('#acc_chk_asset_val').val(0);
            }


            // chkeles.each((index,value)=>{
            //     if($(value).prop('checked') == true){
            //         if($('#cates').val() === ''){
            //             $('#cates').val( $(value).val());
            //         }else{
            //             $('#cates').val( $('#cates').val() + ',' + $(value).val());
            //         }
                    
            //     }
            // });
            // console.log($('#cates').val());
        }
</script>
@endsection