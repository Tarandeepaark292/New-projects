@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3" style="display: flex;justify-content: space-between;align-items: center;">
                    <div>
                        <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}"><i class="fas fa-arrow-left"></i></a> <b>Account Receivable List</b> </h6>                    
                    </div>
                    <div>
                        <i class="fas fa-download mr-1 text-primary"></i><a href="#" class="font-weight-bold text-primary"> Download </a>
                    </div>    
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="notidataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th><b>ID</b></th>
                                    <th><b>Company Name</b></th>
                                    <th><b>Supplier Name</b></th>
                                    <th><b>Currency</b></th>
                                    <th><b>Gst</b></th>
                                    <th><b>Payment Terms</b></th>
                                    <th><b>Edit</b></th>
                                    
                                </tr>

                            </thead>

                           
                            
                            <tbody>
                                
                                @foreach($acc_list as $acc)
                                <tr>
                                    <td>{{$loop->index + 1}}</td>
                                    <td>{{$acc['comp_name']}}</td>
                                    <td>{{$acc['acc_customer_name']}}</td>
                                    <td>{{$acc['acc_currency']}}</td>
                                    <td>{{$acc['gst_val']}}</td>
                                    <td>{{$acc['pt_value']}}</td>
                                    
                                    <td>
                                        <a href="{{url('/admin/acc_recieve')}}/{{$acc['acc_id']}}" class="text-primary">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                    </td>
                                </tr>

                                @endforeach
                                
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
@section('custom_script')
<script>
    $(document).ready(function () {
        $('#notidataTable').DataTable();
    });
</script>
@endsection