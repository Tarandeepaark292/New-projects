@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3" style="display: flex;justify-content: space-between;align-items: center;">
                    <div>
                        <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}"><i class="fas fa-arrow-left"></i></a> <b>Company User List</b> <a class="btn btn-sm btn-outline-primary" style="margin-left: 2rem"  href="{{url('/admin/create-company-user')}}"> <i class="fas fa-plus"></i> Create </a>  </h6>  
                                        
                    </div>
                    <div>
                        <i class="fas fa-download mr-1 text-primary"></i><a href="#" class="font-weight-bold text-primary"> Download </a>
                    </div>    
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" style="font-size: 14px;" id="notidataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th><b>#</b></th>
                                    <th><b>Name</b></th>
                                    <th><b>Email</b></th>
                                    <th><b>Pwd</b></th>
                                    <th><b>Company</b></th>
                                    <th><b>Create Date</b></th>
                                    <th><b>Edit</b></th>
                                </tr>

                            </thead>

                           
                            <tfoot>
                                <tr>
                                    <th><b>#</b></th>
                                    <th><b>Name</b></th>
                                    <th><b>Email</b></th>
                                    <th><b>Pwd</b></th>
                                    <th><b>Company</b></th>
                                    <th><b>Create Date</b></th>
                                    <th><b>Edit</b></th>
                                </tr>
                            </tfoot>
                            <tbody>
                                @isset($compuList)
                                @foreach($compuList as $noti)
                                <tr>
                                    <td>{{$loop->index + 1}}</td>
                                    <td>{{$noti['c_user_name']}}</td>
                                    <td>{{$noti['c_user_email']}}</td>
                                    <td>{{$noti['c_user_pwd']}}</td>
                                    <td>{{$noti['comp_name']}}</td>
                                    <td>{{$noti['c_user_create_date']}}</td>
                                    <td>
                                        <a href="{{url('/admin/edit-comp-user')}}/" class="text-primary">
                                            <i class="fas fa-pencil-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                                @endisset
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



@endsection
@section('custom_script')
<script>
    $(document).ready(function () {
        $('#notidataTable').DataTable();
    });
</script>
@endsection