@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>
<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Chart Of Accounts</b> </h6>
                </div>
                <div class="card-body">
                    <form action="{{url('admin/generate-coa')}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf

                        @error('acc_code') <p style="color:red">{{$message}}</p>@enderror
                        <fieldset>
                            <legend>Data Detail</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Accounts Code</b></label>
                                    <input class="form-control" type="text" name="acc_code" id=""/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Accounts Name</b></label>
                                    <input class="form-control" type="text" name="acc_name" id=""/>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Account Description</b></label>
                                    <textarea name="acc_desc" class="form-control" rows="5"
                                        style="height: auto;resize: none;" required></textarea>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Base Account Nature</b></label>
                                    <select class="form-control" name="acc_nature" id="">
                                        <option value="">Select</option>
                                        <option value="Debit">Debit</option>
                                        <option value="Credit">Credit</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-6">
                                    <div class="checkbox">
                                        <label><b>
                                            Select Auto Fixed Assets</b>
                                        </label><br/>
                                        <input onclick="onchkclick()" type="checkbox" id="acc_chk_asset" value="" style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">Auto Fixed Assets Field Checked</span>
                                        <input type="hidden" id="acc_chk_asset_val" name="acc_chk_asset_val" value=0 />
                                    </div>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Data Entry Behaviour</b></label>
                                    <select class="form-control" name="acc_beh" id="">
                                        <option value="">Select</option>
                                        <option value="+">Plus (+)</option>
                                        <option value="-">Minus (-)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Financial Statement</b></label>
                                    <select class="form-control" name="acc_fin_stmt" id="">
                                        <option value="">Select</option>
                                        <option value="BS">BS (Balance sheet)</option>
                                        <option value="PL">PL (Profit and Loss)</option>
                                        
                                    </select>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Financial Statement Main Category</b></label>
                                    <select class="form-control" name="main_cate" id="">
                                        <option value="-1">Select</option>
                                        @foreach ($main_cates as $cate)
                                        <option value="{{$cate['main_cate_id']}}">{{$cate['main_cate_name']}}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group col-lg-4">
                                    <label><b>Financial Statement Sub Category</b></label>
                                    <select class="form-control" name="sub_cate" id="">
                                        <option value="-1">Select</option>
                                        @foreach ($sub_cates as $cate)
                                        <option value="{{$cate['sub_cate_id']}}">{{$cate['sub_cate_name']}}</option>
                                        @endforeach
                                        
                                    </select>
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <div class="checkbox">
                                        <label><b>
                                            Select Status
                                        </b>
                                        </label><br/>
                                        <input type="checkbox" value="" style="margin-right: 1rem"><span style="height:calc(1.5em + 0.75rem + 2px)">Mark Account Inactive</span>
                                    </div>
                                </div>
                            </div>

                            

                        </fieldset>
                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Create
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section("custom_script")
<script>
    function onchkclick(){
            $('#acc_chk_asset_val').val('');
            chkeles = $('#acc_chk_asset');
            if($(chkeles).prop('checked') == true){
                console.log("checked");
                $('#acc_chk_asset_val').val(1);
            }else{
                console.log("not checked");
                $('#acc_chk_asset_val').val(0);
            }


            // chkeles.each((index,value)=>{
            //     if($(value).prop('checked') == true){
            //         if($('#cates').val() === ''){
            //             $('#cates').val( $(value).val());
            //         }else{
            //             $('#cates').val( $('#cates').val() + ',' + $(value).val());
            //         }
                    
            //     }
            // });
            // console.log($('#cates').val());
        }
</script>
@endsection