

@extends('layouts.admin')
@section('content')

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    {{-- <h1 class="h3 mb-0 ml-3" style="color: black"> <b>PRODUCT UPDATE</b> </h1> --}}
    {{-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> --}}
</div>

<!-- Content Row -->
<div class="row justify-content-center">

</div>

<div class="container-fluid">

    <div class="row">
        <div class="col-lg-12 mb-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary"><a href="{{url('/admin/dashboard')}}">
                            <i class="fas fa-arrow-left"></i></a> <b> Company Account Payable Setup Detail</b> </h6>
                </div>
                <div class="card-body">
                    @if(isset($acc_detail))
                    <form action="{{url('admin/acc_payable_update')}}/{{$acc_detail[0]->ap_id}}" method="post" accept-charset="utf-8"
                        enctype="multipart/form-data">
                        @csrf
                        <fieldset>
                            <legend>Company</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Select Company</b></label>
                                    {{-- <input class="form-control" type="text" name="acc_code" id=""/> --}}
                                    <select class="form-control" name="comp_id" id="comp_id">
                                        <option value="-1">Select</option>
                                        @foreach ($companylist as $comp)
                                        <option value="{{$comp['comp_id']}}" {{ ( $acc_detail[0]->ap_company == $comp['comp_id']) ? 'selected' : '' }}>{{$comp['comp_name']}}</option>
                                        
                                        @endforeach
                                        
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <hr style="border:2px solid #1e355c;margin-bottom: 1px;">
                        <hr style="border:2px solid #E9751E;margin-top: 1px;">
                        <fieldset>
                            <legend>Supplier General Info</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Supplier Name</b></label>
                                    <input class="form-control" type="text" name="acc_supplier_name" id="acc_supplier_name" value="{{$acc_detail[0]->ap_supplier_name}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Select Currency</b></label>
                                    <select name="comp_curr" id="comp_curr" class="form-control">
                                        @foreach($currency as $curr)
                                        <option value="{{$curr}}" {{ ( $acc_detail[0]->ap_currency == $curr) ? 'selected' : '' }}>{{$curr}}</option>
                                        @endforeach
                                        {{-- <option value="USD" {{ ( $acc_detail[0]->ap_currency == "USD") ? 'selected' : '' }} >USD</option>
                                        <option value="INR" {{ ( $acc_detail[0]->ap_currency == "INR") ? 'selected' : '' }}>INR</option>
                                        <option value="AUD" {{ ( $acc_detail[0]->ap_currency == "AUD") ? 'selected' : '' }}>AUD</option> --}}
                                    </select>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Select GST</b></label>
                                    <select name="comp_gst" id="comp_gst" class="form-control">
                                       
                                        <option value="5%" {{ ( $acc_detail[0]->ap_gst == "5") ? 'selected' : '' }} >5%</option>
                                        <option value="12%" {{ ( $acc_detail[0]->ap_gst == "12") ? 'selected' : '' }}>12%</option>
                                        <option value="18%" {{ ( $acc_detail[0]->ap_gst == "18") ? 'selected' : '' }}>18%</option>
                                        <option value="24%" {{ ( $acc_detail[0]->ap_gst == "24") ? 'selected' : '' }}>24%</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Membership ID</b></label>
                                    <input class="form-control" type="text" name="acc_pay_sup_name" id="" value="{{$acc_detail[0]->ap_membership_id}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Supplier Categories</b></label>
                                    <select name="comp_cate" class="form-control">
                                        <option value="5">Select</option>
                                      
                                        <option value="1" {{ ( $acc_detail[0]->ap_supplier_categories == "1") ? 'selected' : '' }} >1</option>
                                        <option value="2" {{ ( $acc_detail[0]->ap_supplier_categories == "2") ? 'selected' : '' }}>2</option>
                                        <option value="3" {{ ( $acc_detail[0]->ap_supplier_categories == "3") ? 'selected' : '' }}>3</option>
                                    </select>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Payment terms</b></label>
                                    <select name="comp_pay_trms" id="comp_pay_trms" class="form-control">
                                        <option value="-1">Select</option>
                                        @foreach($payment_terms as $pterms)
                                        <option value="{{$pterms['pt_id']}}" {{ ( $acc_detail[0]->ap_payment_terms == $pterms['pt_id']) ? 'selected' : '' }}>{{$pterms['pt_value']}}</option>
                                       
                                        @endforeach

                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label for=""><b>Is Corresponding Customer</b></label><br/>
                                    @if($acc_detail[0]->ap_corresponding_customer == 0)
                                        <input onclick="onchkclick()" name="check_cust" type="checkbox" id="check_cust"  value="{{$acc_detail[0]->ap_corresponding_customer}}" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Corresponding Customer</span>
                                        <input type="hidden" id="acc_chk_asset_vals" name="acc_chk_asset_vals" value=0 />
                                    @else
                                        <input onclick="onchkclick()" name="check_cust" type="checkbox" id="check_cust" checked="checked" value="{{$acc_detail[0]->ap_corresponding_customer}}" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">Corresponding Customer</span>
                                        <input type="hidden" id="acc_chk_asset_vals" name="acc_chk_asset_vals" value=1 />
                                    @endif
                                    
                                </div>
                                <div class="form-group col-lg-8">
                                    <label><b>Notes</b></label>
                                    <textarea class="form-control" name="notes" id="" cols="30" rows="5">{{$acc_detail[0]->ap_notes}}</textarea>
                                </div>
                            </div>

                        </fieldset>
                        <fieldset>
                            <legend>Supplier Bank Information</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Name</b></label>
                                
                                    <input class="form-control" type="text" name="comp_bank_name" id="" value="{{$data->b_name ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Bank Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_code" id="" value="{{$data->b_code ?? ''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Name</b></label>
                                    <input class="form-control" type="text" name="comp_bank_branch_name" value="{{$data->branch_name ?? ''}}" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Branch Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_branch_code" value="{{$data->branch_code ?? ''}}" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Swift Code</b></label>
                                    <input class="form-control" type="text" name="comp_bank_swift_code" value="{{$data->swift_code ?? ''}}"  id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>Intermediary Bank</b></label>
                                    <input class="form-control" type="text" name="comp_bank_intermed" value="{{$data->intermediary_bank ?? ''}}" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Type</b></label>
                                    <input class="form-control" type="text" name="comp_bank_acc_type" value="{{$data->acc_type ?? ''}}" id=""/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Account Number</b></label>
                                    <input class="form-control" type="text" name="comp_bank_acc_number" value="{{$data->acc_number ?? ''}}" id=""/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label for=""><b>Is Multicurrency Support</b></label><br/>
                                    @if($data->multi_support == 0)
                                    <input onclick="onchksssclick()" type="checkbox" id="currency" name=""  value="{{$data->multi_support}}" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">MultiCurrency</span>
                                    <input type="hidden" id="acc_chk_asset_valss" name="acc_chk_asset_valss" value=0 />
                                    @else
                                    <input onclick="onchksssclick()" type="checkbox" id="currency" name="" checked="checked" value="{{$data->multi_support}}" style="margin-right: 1rem" ><span style="height:calc(1.5em + 0.75rem + 2px)">MultiCurrency</span>
                                    <input type="hidden" id="acc_chk_asset_valss" name="acc_chk_asset_valss" value=1 />
                                    @endif
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Supplier Contact Information</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-3">
                                    <label><b>Phone 1</b></label>
                                    <input class="form-control" type="text" name="comp_phone_1" id="" value="{{$contact->phone_1 ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Phone 2</b></label>
                                    <input class="form-control" type="text" name="comp_phone_2" id="" value="{{$contact->phone_2 ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Mobile 1</b></label>
                                    <input class="form-control" type="text" name="comp_mobile_1" id="" value="{{$contact->mob_1 ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Mobile 2</b></label>
                                    <input class="form-control" type="text" name="comp_mobile_2" id="" value="{{$contact->mob_2 ?? ''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-6">
                                    <label><b>Fax</b></label>
                                    <input class="form-control" type="text" name="comp_fax" id="" value="{{$contact->fax ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-6">
                                    <label><b>Email</b></label>
                                    <input class="form-control" type="text" name="comp_email" id="" value="{{$contact->email ?? ''}}"/>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Supplier Registered Address</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Address Line 1</b></label>
                                    <input class="form-control" type="text" name="leg_addr_line_1" id="" value="{{$supplier_regstr->addr_line1 ?? ''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Address Line 2</b></label>
                                    <input class="form-control" type="text" name="leg_addr_line_2" id="" value="{{$supplier_regstr->addr_line2 ?? ''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>State</b></label>
                                    <input class="form-control" type="text" name="leg_addr_state" id="" value="{{$supplier_regstr->state ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>City</b></label>
                                    <input class="form-control" type="text" name="leg_addr_city" id="" value="{{$supplier_regstr->city ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Postal Code</b></label>
                                    <input class="form-control" type="text" name="leg_addr_postal" id="" value="{{$supplier_regstr->postal ?? ''}}"/>
                                </div>
                                
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Country</b></label>
                                    {{-- <input class="form-control" type="text" name="leg_addr_country" id=""/> --}}
                                    <select name="leg_addr_country" class="form-control">
                                        ier_regstr->country == "Afganistan") ? 'selected' : '' }} >Afganistan</option>
                                        <option value="Albania" {{ ( $supplier_regstr->country == "Albania") ? 'selected' : '' }} >Albania</option>
                                        <option value="Algeria" {{ ( $supplier_regstr->country == "Algeria") ? 'selected' : '' }} >Algeria</option>
                                        <option value="American Samoa" {{ ( $supplier_regstr->country == "American Samoa") ? 'selected' : '' }} >American Samoa</option>
                                        <option value="Andorra" {{ ( $supplier_regstr->country == "Andorra") ? 'selected' : '' }} >Andorra</option>
                                        <option value="Angola" {{ ( $supplier_regstr->country == "Angola") ? 'selected' : '' }} >Angola</option>
                                        <option value="Anguilla" {{ ( $supplier_regstr->country == "Anguilla") ? 'selected' : '' }} >Anguilla</option>
                                        <option value="Antigua & Barbuda" {{ ( $supplier_regstr->country == "Antigua & Barbuda") ? 'selected' : '' }} >Antigua & Barbuda</option>
                                        <option value="Argentina" {{ ( $supplier_regstr->country == "Argentina") ? 'selected' : '' }} >Argentina</option>
                                        <option value="Armenia" {{ ( $supplier_regstr->country == "Armenia") ? 'selected' : '' }} >Armenia</option>
                                        <option value="Aruba" {{ ( $supplier_regstr->country == "Aruba") ? 'selected' : '' }} >Aruba</option>
                                        <option value="Australia" {{ ( $supplier_regstr->country == "Australia") ? 'selected' : '' }} >Australia</option>
                                        <option value="Austria" {{ ( $supplier_regstr->country == "Austria") ? 'selected' : '' }} >Austria</option>
                                        <option value="Azerbaijan" {{ ( $supplier_regstr->country == "Azerbaijan") ? 'selected' : '' }} >Azerbaijan</option>
                                        <option value="Bahamas" {{ ( $supplier_regstr->country == "Bahamas") ? 'selected' : '' }} >Bahamas</option>
                                        <option value="Bahrain" {{ ( $supplier_regstr->country == "Bahrain") ? 'selected' : '' }} >Bahrain</option>
                                        <option value="Bangladesh" {{ ( $supplier_regstr->country == "Bangladesh") ? 'selected' : '' }} >Bangladesh</option>
                                        <option value="Barbados" {{ ( $supplier_regstr->country == "Barbados") ? 'selected' : '' }} >Barbados</option>
                                        <option value="Belarus" {{ ( $supplier_regstr->country == "Belarus") ? 'selected' : '' }} >Belarus</option>
                                        <option value="Belgium" {{ ( $supplier_regstr->country == "Belgium") ? 'selected' : '' }} >Belgium</option>
                                        <option value="Belize" {{ ( $supplier_regstr->country == "Belize") ? 'selected' : '' }} >Belize</option>
                                        <option value="Benin" {{ ( $supplier_regstr->country == "Benin") ? 'selected' : '' }} >Benin</option>
                                        <option value="Bermuda" {{ ( $supplier_regstr->country == "Bermuda") ? 'selected' : '' }} >Bermuda</option>
                                        <option value="Bhutan" {{ ( $supplier_regstr->country == "Bhutan") ? 'selected' : '' }} >Bhutan</option>
                                        <option value="Bolivia" {{ ( $supplier_regstr->country == "Bolivia") ? 'selected' : '' }} >Bolivia</option>
                                        <option value="Bonaire" {{ ( $supplier_regstr->country == "Bonaire") ? 'selected' : '' }} >Bonaire</option>
                                        <option value="Bosnia & Herzegovina" {{ ( $supplier_regstr->country == "Bosnia & Herzegovina") ? 'selected' : '' }} >Bosnia & Herzegovina</option>
                                        <option value="Botswana" {{ ( $supplier_regstr->country == "Botswana") ? 'selected' : '' }} >Botswana</option>
                                        <option value="Brazil" {{ ( $supplier_regstr->country == "Brazil") ? 'selected' : '' }} >Brazil</option>
                                        <option value="British Indian Ocean Ter" {{ ( $supplier_regstr->country == "British Indian Ocean Ter") ? 'selected' : '' }} >British Indian Ocean Ter</option>
                                        <option value="Brunei" {{ ( $supplier_regstr->country == "Brunei") ? 'selected' : '' }} >Brunei</option>
                                        <option value="Bulgaria" {{ ( $supplier_regstr->country == "Bulgaria") ? 'selected' : '' }} >Bulgaria</option>
                                        <option value="Burkina Faso" {{ ( $supplier_regstr->country == "Burkina Faso") ? 'selected' : '' }} >Burkina Faso</option>
                                        <option value="Burundi" {{ ( $supplier_regstr->country == "Burundi") ? 'selected' : '' }} >Burundi</option>
                                        <option value="Cambodia" {{ ( $supplier_regstr->country == "Cambodia") ? 'selected' : '' }} >Cambodia</option>
                                        <option value="Cameroon" {{ ( $supplier_regstr->country == "Cameroon") ? 'selected' : '' }} >Cameroon</option>
                                        <option value="Canada" {{ ( $supplier_regstr->country == "Canada") ? 'selected' : '' }} >Canary Islands</option>
                                        <option value="Canary Islands" {{ ( $supplier_regstr->country == "Canary Islands") ? 'selected' : '' }} >Canada</option>
                                        <option value="Cape Verde" {{ ( $supplier_regstr->country == "Cape Verde") ? 'selected' : '' }} >Cape Verde</option>
                                        <option value="Cayman Islands" {{ ( $supplier_regstr->country == "Cayman Islands") ? 'selected' : '' }} >Cayman Islands</option>
                                        <option value="Central African Republic" {{ ( $supplier_regstr->country == "Central African Republic") ? 'selected' : '' }} >Central African Republic</option>
                                        <option value="Chad" {{ ( $supplier_regstr->country == "Chad") ? 'selected' : '' }} >Chad</option>
                                        <option value="Channel Islands" {{ ( $supplier_regstr->country == "Channel Islands") ? 'selected' : '' }} >Channel Islands</option>
                                        <option value="Chile" {{ ( $supplier_regstr->country == "Chile") ? 'selected' : '' }} >Chile</option>
                                        <option value="China" {{ ( $supplier_regstr->country == "China") ? 'selected' : '' }} >China</option>
                                        <option value="Christmas Island" {{ ( $supplier_regstr->country == "Christmas Island") ? 'selected' : '' }} >Christmas Island</option>
                                        <option value="Cocos Island" {{ ( $supplier_regstr->country == "Cocos Island") ? 'selected' : '' }} >Cocos Island</option>
                                        <option value="Colombia" {{ ( $supplier_regstr->country == "Colombia") ? 'selected' : '' }} >Colombia</option>
                                        <option value="Comoros" {{ ( $supplier_regstr->country == "Comoros") ? 'selected' : '' }} >Comoros</option>
                                        <option value="Congo" {{ ( $supplier_regstr->country == "Congo") ? 'selected' : '' }} >Congo</option>
                                        <option value="Cook Islands" {{ ( $supplier_regstr->country == "Cook Islands") ? 'selected' : '' }} >Cook Islands</option>
                                        <option value="Costa Rica" {{ ( $supplier_regstr->country == "Costa Rica") ? 'selected' : '' }} >Costa Rica</option>
                                        <option value="Cote DIvoire" {{ ( $supplier_regstr->country == "Cote DIvoire") ? 'selected' : '' }} >Cote DIvoire</option>
                                        <option value="Croatia" {{ ( $supplier_regstr->country == "Croatia") ? 'selected' : '' }} >Croatia</option>
                                        <option value="Cuba" {{ ( $supplier_regstr->country == "Cuba") ? 'selected' : '' }} >Cuba</option>
                                        <option value="Curaco" {{ ( $supplier_regstr->country == "Curaco") ? 'selected' : '' }} >Curaco</option>
                                        <option value="Cyprus" {{ ( $supplier_regstr->country == "Cyprus") ? 'selected' : '' }} >Cyprus</option>
                                        <option value="Czech Republic" {{ ( $supplier_regstr->country == "Czech Republic") ? 'selected' : '' }} >Czech Republic</option>
                                        <option value="Denmark" {{ ( $supplier_regstr->country == "Denmark") ? 'selected' : '' }} >Denmark</option>
                                        <option value="Djibouti" {{ ( $supplier_regstr->country == "Djibouti") ? 'selected' : '' }} >Djibouti</option>
                                        <option value="Dominica" {{ ( $supplier_regstr->country == "Dominica") ? 'selected' : '' }} >Dominica</option>
                                        <option value="Dominican Republic" {{ ( $supplier_regstr->country == "Dominican Republic") ? 'selected' : '' }} >Dominican Republic</option>
                                        <option value="East Timor" {{ ( $supplier_regstr->country == "East Timor") ? 'selected' : '' }} >East Timor</option>
                                        <option value="Ecuador" {{ ( $supplier_regstr->country == "Ecuador") ? 'selected' : '' }} >Ecuador</option>
                                        <option value="Egypt" {{ ( $supplier_regstr->country == "Egypt") ? 'selected' : '' }} >Egypt</option>
                                        <option value="Equatorial Guinea" {{ ( $supplier_regstr->country == "El Salvador") ? 'selected' : '' }} >El Salvador</option>
                                        <option value="Eritrea" {{ ( $supplier_regstr->country == "Eritrea") ? 'selected' : '' }} >Eritrea</option>
                                        <option value="Estonia" {{ ( $supplier_regstr->country == "Estonia") ? 'selected' : '' }} >Estonia</option>
                                        <option value="Ethiopia" {{ ( $supplier_regstr->country == "Ethiopia") ? 'selected' : '' }} >Ethiopia</option>
                                        <option value="Falkland Islands" {{ ( $supplier_regstr->country == "Falkland Islands") ? 'selected' : '' }} >Falkland Islands</option>
                                        <option value="Faroe Islands" {{ ( $supplier_regstr->country == "Faroe Islands") ? 'selected' : '' }} >Faroe Islands</option>
                                        <option value="Fiji" {{ ( $supplier_regstr->country == "Fiji") ? 'selected' : '' }} >Fiji</option>
                                        <option value="Finland" {{ ( $supplier_regstr->country == "Finland") ? 'selected' : '' }} >Finland</option>
                                        <option value="France" {{ ( $supplier_regstr->country == "France") ? 'selected' : '' }} >France</option>
                                        <option value="French Guiana" {{ ( $supplier_regstr->country == "French Guiana") ? 'selected' : '' }} >French Guiana</option>
                                        <option value="French Polynesia" {{ ( $supplier_regstr->country == "French Polynesia") ? 'selected' : '' }} >French Polynesia</option>
                                        <option value="French Southern Ter" {{ ( $supplier_regstr->country == "French Southern Ter") ? 'selected' : '' }} >French Southern Ter  </option>
                                        <option value="Gabon" {{ ( $supplier_regstr->country == "Gabon") ? 'selected' : '' }} >Gabon  </option>
                                        <option value="Gambia" {{ ( $supplier_regstr->country == "Gambia") ? 'selected' : '' }} >Gambia  </option>
                                        <option value="Germany" {{ ( $supplier_regstr->country == "Germany") ? 'selected' : '' }} >Germany  </option>
                                        <option value="Ghana" {{ ( $supplier_regstr->country == "Ghana") ? 'selected' : '' }} >Ghana  </option>
                                        <option value="Great Britain" {{ ( $supplier_regstr->country == "Great Britain") ? 'selected' : '' }} >Great Britain  </option>
                                        <option value="Greece" {{ ( $supplier_regstr->country == "Greece") ? 'selected' : '' }} >Greece  </option>
                                        <option value="Greenland" {{ ( $supplier_regstr->country == "Greenland") ? 'selected' : '' }} >Greenland  </option>
                                        <option value="Grenada" {{ ( $supplier_regstr->country == "Grenada") ? 'selected' : '' }} >Grenada  </option>
                                        <option value="Guadeloupe" {{ ( $supplier_regstr->country == "Guadeloupe") ? 'selected' : '' }} >Guadeloupe  </option>
                                        <option value="Guam" {{ ( $supplier_regstr->country == "Guam") ? 'selected' : '' }} >Guam  </option>
                                        <option value="Guatemala" {{ ( $supplier_regstr->country == "Guatemala") ? 'selected' : '' }} >Guatemala  </option>
                                        <option value="Guinea" {{ ( $supplier_regstr->country == "Guinea") ? 'selected' : '' }} >Guinea  </option>
                                        <option value="Guyana" {{ ( $supplier_regstr->country == "Guyana") ? 'selected' : '' }} >Guyana  </option>
                                        <option value="Haiti" {{ ( $supplier_regstr->country == "Haiti") ? 'selected' : '' }} >Haiti  </option>
                                        <option value="Hawaii" {{ ( $supplier_regstr->country == "Hawaii") ? 'selected' : '' }} >Hawaii  </option>
                                        <option value="Honduras" {{ ( $supplier_regstr->country == "Honduras") ? 'selected' : '' }} >Honduras  </option>
                                        <option value="Hong Kong" {{ ( $supplier_regstr->country == "Hong Kong") ? 'selected' : '' }} >Hong Kong  </option>
                                        <option value="Hungary" {{ ( $supplier_regstr->country == "Hungary") ? 'selected' : '' }} >Hungary  </option>
                                        <option value="Iceland" {{ ( $supplier_regstr->country == "Iceland") ? 'selected' : '' }} >Iceland  </option>
                                        <option value="Indonesia" {{ ( $supplier_regstr->country == "Indonesia") ? 'selected' : '' }} >Indonesia  </option>
                                        <option value="India" {{ ( $supplier_regstr->country == "India") ? 'selected' : '' }} >India  </option>
                                        <option value="Iran" {{ ( $supplier_regstr->country == "Iran") ? 'selected' : '' }} >Iran  </option>
                                        <option value="Iraq" {{ ( $supplier_regstr->country == "Iraq") ? 'selected' : '' }} >Iraq  </option>
                                        <option value="Ireland" {{ ( $supplier_regstr->country == "Ireland") ? 'selected' : '' }} >Ireland  </option>
                                        <option value="Isle of Man" {{ ( $supplier_regstr->country == "Isle of Man") ? 'selected' : '' }} >Isle of Man  </option>
                                        <option value="Israel" {{ ( $supplier_regstr->country == "Israel") ? 'selected' : '' }} >Israel</option>
                                        <option value="Italy" {{ ( $supplier_regstr->country == "Italy") ? 'selected' : '' }} >Italy</option>
                                        <option value="Jamaica" {{ ( $supplier_regstr->country == "Jamaica") ? 'selected' : '' }} >Jamaica</option>
                                        <option value="Japan" {{ ( $supplier_regstr->country == "Japan") ? 'selected' : '' }} >Japan</option>
                                        <option value="Jordan" {{ ( $supplier_regstr->country == "Jordan") ? 'selected' : '' }} >Jordan</option>
                                        <option value="Kazakhstan" {{ ( $supplier_regstr->country == "Kazakhstan") ? 'selected' : '' }} >Kazakhstan</option>
                                        <option value="Kenya" {{ ( $supplier_regstr->country == "Kenya") ? 'selected' : '' }} >Kenya</option>
                                        <option value="Kiribati" {{ ( $supplier_regstr->country == "Kiribati") ? 'selected' : '' }} >Kiribati</option>
                                        <option value="Korea North" {{ ( $supplier_regstr->country == "Korea North") ? 'selected' : '' }} >Korea North</option>
                                        <option value="Korea South" {{ ( $supplier_regstr->country == "Korea South") ? 'selected' : '' }} >Korea South</option>
                                        <option value="Kuwait" {{ ( $supplier_regstr->country == "Kuwait") ? 'selected' : '' }} >Kuwait</option>
                                        <option value="Kyrgyzstan" {{ ( $supplier_regstr->country == "Kyrgyzstan") ? 'selected' : '' }} >Kyrgyzstan</option>
                                        <option value="Laos" {{ ( $supplier_regstr->country == "Laos") ? 'selected' : '' }} >Laos</option>
                                        <option value="Latvia" {{ ( $supplier_regstr->country == "Latvia") ? 'selected' : '' }} >Latvia</option>
                                        <option value="Lebanon" {{ ( $supplier_regstr->country == "Lebanon") ? 'selected' : '' }} >Lebanon</option>
                                        <option value="Lesotho" {{ ( $supplier_regstr->country == "Lesotho") ? 'selected' : '' }} >Lesotho</option>
                                        <option value="Liberia" {{ ( $supplier_regstr->country == "Liberia") ? 'selected' : '' }} >Liberia</option>
                                        <option value="Libya" {{ ( $supplier_regstr->country == "Libya") ? 'selected' : '' }} >Libya</option>
                                        <option value="Liechtenstein" {{ ( $supplier_regstr->country == "Liechtenstein") ? 'selected' : '' }} >Liechtenstein</option>
                                        <option value="Lithuania" {{ ( $supplier_regstr->country == "Lithuania") ? 'selected' : '' }} >Lithuania</option>
                                        <option value="Luxembourg" {{ ( $supplier_regstr->country == "Luxembourg") ? 'selected' : '' }} >Luxembourg</option>
                                        <option value="Macau" {{ ( $supplier_regstr->country == "Macau") ? 'selected' : '' }} >Macau</option>
                                        <option value="Macedonia" {{ ( $supplier_regstr->country == "Macedonia") ? 'selected' : '' }} >Macedonia</option>
                                        <option value="Madagascar" {{ ( $supplier_regstr->country == "Madagascar") ? 'selected' : '' }} >Madagascar</option>
                                        <option value="Malaysia" {{ ( $supplier_regstr->country == "Malaysia") ? 'selected' : '' }} >Malaysia</option>
                                        <option value="Malawi" {{ ( $supplier_regstr->country == "Malawi") ? 'selected' : '' }} >Malawi</option>
                                        <option value="Maldives" {{ ( $supplier_regstr->country == "Maldives") ? 'selected' : '' }} >Maldives</option>
                                        <option value="Mali" {{ ( $supplier_regstr->country == "Mali") ? 'selected' : '' }} >Mali</option>
                                        <option value="Malta" {{ ( $supplier_regstr->country == "Malta") ? 'selected' : '' }} >Malta</option>
                                        <option value="Marshall Islands" {{ ( $supplier_regstr->country == "Marshall Islands") ? 'selected' : '' }} >Marshall Islands</option>
                                        <option value="Martinique" {{ ( $supplier_regstr->country == "Martinique") ? 'selected' : '' }} >Martinique</option>
                                        <option value="Mauritania" {{ ( $supplier_regstr->country == "Mauritania") ? 'selected' : '' }} >Mauritania</option>
                                        <option value="Mauritius" {{ ( $supplier_regstr->country == "Mauritius") ? 'selected' : '' }} >Mauritius</option>
                                        <option value="Mayotte" {{ ( $supplier_regstr->country == "Mayotte") ? 'selected' : '' }} >Mayotte</option>
                                        <option value="Mexico" {{ ( $supplier_regstr->country == "Mexico") ? 'selected' : '' }} >Mexico</option>
                                        <option value="Midway Islands" {{ ( $supplier_regstr->country == "Midway Islands") ? 'selected' : '' }} >Midway Islands</option>
                                        <option value="Moldova" {{ ( $supplier_regstr->country == "Moldova") ? 'selected' : '' }} >Moldova</option>
                                        <option value="Monaco" {{ ( $supplier_regstr->country == "Monaco") ? 'selected' : '' }} >Monaco</option>
                                        <option value="Mongolia" {{ ( $supplier_regstr->country == "Mongolia") ? 'selected' : '' }} >Mongolia</option>
                                        <option value="Montserrat" {{ ( $supplier_regstr->country == "Montserrat") ? 'selected' : '' }} >Montserrat</option>
                                        <option value="Morocco" {{ ( $supplier_regstr->country == "Morocco") ? 'selected' : '' }} >Morocco</option>
                                        <option value="Mozambique" {{ ( $supplier_regstr->country == "Mozambique") ? 'selected' : '' }} >Mozambique</option>
                                        <option value="Myanmar" {{ ( $supplier_regstr->country == "Myanmar") ? 'selected' : '' }} >Myanmar</option>
                                        <option value="Nambia" {{ ( $supplier_regstr->country == "Nambia") ? 'selected' : '' }} >Nambia</option>
                                        <option value="Nauru" {{ ( $supplier_regstr->country == "Nauru") ? 'selected' : '' }} >Nauru</option>
                                        <option value="Nepal" {{ ( $supplier_regstr->country == "Nepal") ? 'selected' : '' }} >Nepal</option>
                                        <option value="Netherland Antilles" {{ ( $supplier_regstr->country == "Netherland Antilles") ? 'selected' : '' }} >Netherland Antilles</option>
                                        <option value="Netherlands" {{ ( $supplier_regstr->country == "Netherlands") ? 'selected' : '' }} >Netherlands</option>
                                        <option value="Nevis" {{ ( $supplier_regstr->country == "Nevis") ? 'selected' : '' }} >Nevis</option>
                                        <option value="New Caledonia" {{ ( $supplier_regstr->country == "New Caledonia") ? 'selected' : '' }} >New Caledonia</option>
                                        <option value="New Zealand" {{ ( $supplier_regstr->country == "New Zealand") ? 'selected' : '' }} >New Zealand</option>
                                        <option value="Nicaragua" {{ ( $supplier_regstr->country == "Nicaragua") ? 'selected' : '' }} >Nicaragua</option>
                                        <option value="Niger" {{ ( $supplier_regstr->country == "Niger") ? 'selected' : '' }} >Niger</option>
                                        <option value="Nigeria" {{ ( $supplier_regstr->country == "Nigeria") ? 'selected' : '' }} >Nigeria</option>
                                        <option value="Niue" {{ ( $supplier_regstr->country == "Niue") ? 'selected' : '' }} >Niue</option>
                                        <option value="Norfolk Island" {{ ( $supplier_regstr->country == "Norfolk Island") ? 'selected' : '' }} >Norfolk Island</option>
                                        <option value="Norway" {{ ( $supplier_regstr->country == "Norway") ? 'selected' : '' }} >Norway</option>
                                        <option value="Oman" {{ ( $supplier_regstr->country == "Oman") ? 'selected' : '' }} >Oman</option>
                                        <option value="Pakistan" {{ ( $supplier_regstr->country == "Pakistan") ? 'selected' : '' }} >Pakistan</option>
                                        <option value="Palau Island" {{ ( $supplier_regstr->country == "Palau Island") ? 'selected' : '' }} >Palau Island</option>
                                        <option value="Palestine" {{ ( $supplier_regstr->country == "Palestine") ? 'selected' : '' }} >Palestine</option>
                                        <option value="Panama" {{ ( $supplier_regstr->country == "Panama") ? 'selected' : '' }} >Panama</option>
                                        <option value="Papua New Guinea" {{ ( $supplier_regstr->country == "Papua New Guinea") ? 'selected' : '' }} >Papua New Guinea</option>
                                        <option value="Paraguay" {{ ( $supplier_regstr->country == "Paraguay") ? 'selected' : '' }} >Paraguay</option>
                                        <option value="Peru" {{ ( $supplier_regstr->country == "Peru") ? 'selected' : '' }} >Peru</option>
                                        <option value="Phillipines" {{ ( $supplier_regstr->country == "Phillipines") ? 'selected' : '' }} >Phillipines</option>
                                        <option value="Pitcairn Island" {{ ( $supplier_regstr->country == "Pitcairn Island") ? 'selected' : '' }} >Pitcairn Island</option>
                                        <option value="Poland" {{ ( $supplier_regstr->country == "Poland") ? 'selected' : '' }} >Poland</option>
                                        <option value="Portugal" {{ ( $supplier_regstr->country == "Portugal") ? 'selected' : '' }} >Portugal</option>
                                        <option value="Puerto Rico" {{ ( $supplier_regstr->country == "Puerto Rico") ? 'selected' : '' }} >Puerto Rico</option>
                                        <option value="Qatar" {{ ( $supplier_regstr->country == "Qatar") ? 'selected' : '' }} >Qatar</option>
                                        <option value="Republic of Montenegro" {{ ( $supplier_regstr->country == "Republic of Montenegro") ? 'selected' : '' }} >Republic of Montenegro</option>
                                        <option value="Republic of Serbia" {{ ( $supplier_regstr->country == "Republic of Serbia") ? 'selected' : '' }} >Republic of Serbia</option>
                                        <option value="Reunion" {{ ( $supplier_regstr->country == "Reunion") ? 'selected' : '' }} >Reunion</option>
                                        <option value="Romania" {{ ( $supplier_regstr->country == "Romania") ? 'selected' : '' }} >Romania</option>
                                        <option value="Russia" {{ ( $supplier_regstr->country == "Russia") ? 'selected' : '' }} >Russia</option>
                                        <option value="Rwanda" {{ ( $supplier_regstr->country == "Rwanda") ? 'selected' : '' }} >Rwanda</option>
                                        <option value="St Barthelemy" {{ ( $supplier_regstr->country == "St Barthelemy") ? 'selected' : '' }} >St Barthelemy</option>
                                        <option value="St Eustatius" {{ ( $supplier_regstr->country == "St Eustatius") ? 'selected' : '' }} >St Eustatius</option>
                                        <option value="St Helena" {{ ( $supplier_regstr->country == "St Helena") ? 'selected' : '' }} >St Helena</option>
                                        <option value="St Kitts-Nevis" {{ ( $supplier_regstr->country == "St Kitts-Nevis") ? 'selected' : '' }} >St Kitts-Nevis</option>
                                        <option value="St Lucia" {{ ( $supplier_regstr->country == "St Lucia") ? 'selected' : '' }} >St Lucia</option>
                                        <option value="St Maarten" {{ ( $supplier_regstr->country == "St Maarten") ? 'selected' : '' }} >St Maarten</option>
                                        <option value="St Pierre & Miquelon" {{ ( $supplier_regstr->country == "St Pierre & Miquelon") ? 'selected' : '' }} >St Pierre & Miquelon</option>
                                        <option value="St Vincent & Grenadines" {{ ( $supplier_regstr->country == "St Vincent & Grenadines") ? 'selected' : '' }} >St Vincent & Grenadines</option>
                                        <option value="Saipan" {{ ( $supplier_regstr->country == "Saipan") ? 'selected' : '' }} >Saipan</option>
                                        <option value="Samoa" {{ ( $supplier_regstr->country == "Samoa") ? 'selected' : '' }} >Samoa</option>
                                        <option value="Samoa American" {{ ( $supplier_regstr->country == "Samoa American") ? 'selected' : '' }} >Samoa American</option>
                                        <option value="San Marino" {{ ( $supplier_regstr->country == "San Marino") ? 'selected' : '' }} >San Marino</option>
                                        <option value="San Marino" {{ ( $supplier_regstr->country == "San Marino") ? 'selected' : '' }} >San Marino</option>
                                        <option value="Sao Tome & Principe" {{ ( $supplier_regstr->country == "Sao Tome & Principe") ? 'selected' : '' }} >Sao Tome & Principe</option>
                                        <option value="Saudi Arabia" {{ ( $supplier_regstr->country == "Saudi Arabia") ? 'selected' : '' }} >Saudi Arabia</option>
                                        <option value="Senegal" {{ ( $supplier_regstr->country == "Senegal") ? 'selected' : '' }} >Senegal</option>
                                        <option value="Seychelles" {{ ( $supplier_regstr->country == "Seychelles") ? 'selected' : '' }} >Seychelles</option>
                                        <option value="Sierra Leone" {{ ( $supplier_regstr->country == "Sierra Leone") ? 'selected' : '' }} >Sierra Leone</option>
                                        <option value="Singapore" {{ ( $supplier_regstr->country == "Singapore") ? 'selected' : '' }} >Singapore</option>
                                        <option value="Slovakia" {{ ( $supplier_regstr->country == "Slovakia") ? 'selected' : '' }} >Slovakia</option>
                                        <option value="Slovenia" {{ ( $supplier_regstr->country == "Slovenia") ? 'selected' : '' }} >Slovenia</option>
                                        <option value="Solomon Islands" {{ ( $supplier_regstr->country == "Solomon Islands") ? 'selected' : '' }} >Solomon Islands</option>
                                        <option value="Somalia" {{ ( $supplier_regstr->country == "Somalia") ? 'selected' : '' }} >Somalia</option>
                                        <option value="South Africa" {{ ( $supplier_regstr->country == "South Africa") ? 'selected' : '' }} >South Africa</option>
                                        <option value="Spain" {{ ( $supplier_regstr->country == "Spain") ? 'selected' : '' }} >Spain</option>
                                        <option value="Sri Lanka" {{ ( $supplier_regstr->country == "Sri Lanka") ? 'selected' : '' }} >Sri Lanka</option>
                                        <option value="Sudan" {{ ( $supplier_regstr->country == "Sudan") ? 'selected' : '' }} >Sudan</option>
                                        <option value="Suriname" {{ ( $supplier_regstr->country == "Suriname") ? 'selected' : '' }} >Suriname</option>
                                        <option value="Swaziland" {{ ( $supplier_regstr->country == "Swaziland") ? 'selected' : '' }} >Swaziland</option>
                                        <option value="Sweden" {{ ( $supplier_regstr->country == "Sweden") ? 'selected' : '' }} >Sweden</option>
                                        <option value="Switzerland" {{ ( $supplier_regstr->country == "Switzerland") ? 'selected' : '' }} >Switzerland</option>
                                        <option value="Syria" {{ ( $supplier_regstr->country == "Syria") ? 'selected' : '' }} >Syria</option>
                                        <option value="Tahiti" {{ ( $supplier_regstr->country == "Tahiti") ? 'selected' : '' }} >Tahiti</option>
                                        <option value="Taiwan" {{ ( $supplier_regstr->country == "Taiwan") ? 'selected' : '' }} >Taiwan</option>
                                        <option value="Tajikistan" {{ ( $supplier_regstr->country == "Tajikistan") ? 'selected' : '' }} >Tajikistan</option>
                                        <option value="Tanzania" {{ ( $supplier_regstr->country == "Tanzania") ? 'selected' : '' }} >Tanzania</option>
                                        <option value="Thailand" {{ ( $supplier_regstr->country == "Thailand") ? 'selected' : '' }} >Thailand</option>
                                        <option value="Togo" {{ ( $supplier_regstr->country == "Togo") ? 'selected' : '' }} >Togo</option>
                                        <option value="Tokelau" {{ ( $supplier_regstr->country == "Tokelau") ? 'selected' : '' }} >Tokelau</option>
                                        <option value="Tonga" {{ ( $supplier_regstr->country == "Tonga") ? 'selected' : '' }} >Tonga</option>
                                        <option value="Trinidad & Tobago" {{ ( $supplier_regstr->country == "Trinidad & Tobago") ? 'selected' : '' }} >Trinidad & Tobago</option>
                                        <option value="Tunisia" {{ ( $supplier_regstr->country == "Tunisia") ? 'selected' : '' }} >Tunisia</option>
                                        <option value="Turkey" {{ ( $supplier_regstr->country == "Turkey") ? 'selected' : '' }} >Turkey</option>
                                        <option value="Turkmenistan" {{ ( $supplier_regstr->country == "Turkmenistan") ? 'selected' : '' }} >Turkmenistan</option>
                                        <option value="Turks & Caicos Is" {{ ( $supplier_regstr->country == "Turks & Caicos Is") ? 'selected' : '' }} >Turks & Caicos Is</option>
                                        <option value="Tuvalu" {{ ( $supplier_regstr->country == "Tuvalu") ? 'selected' : '' }} >Tuvalu</option>
                                        <option value="Uganda" {{ ( $supplier_regstr->country == "Uganda") ? 'selected' : '' }} >Uganda</option>
                                        <option value="United Kingdom" {{ ( $supplier_regstr->country == "United Kingdom") ? 'selected' : '' }} >United Kingdom</option>
                                        <option value="Ukraine" {{ ( $supplier_regstr->country == "Ukraine") ? 'selected' : '' }} >Ukraine</option>
                                        <option value="United Arab Erimates" {{ ( $supplier_regstr->country == "United Arab Erimates") ? 'selected' : '' }} >United Arab Erimates</option>
                                        <option value="United States of America" {{ ( $supplier_regstr->country == "United States of America") ? 'selected' : '' }} >United States of America</option>
                                        <option value="Uraguay" {{ ( $supplier_regstr->country == "Uraguay") ? 'selected' : '' }} >Uraguay</option>
                                        <option value="Uzbekistan" {{ ( $supplier_regstr->country == "Uzbekistan") ? 'selected' : '' }} >Uzbekistan</option>
                                        <option value="Vanuatu" {{ ( $supplier_regstr->country == "Vanuatu") ? 'selected' : '' }} >Vanuatu</option>
                                        <option value="Vatican City State" {{ ( $supplier_regstr->country == "Vatican City State") ? 'selected' : '' }} >Vatican City State</option>
                                        <option value="Venezuela" {{ ( $supplier_regstr->country == "Venezuela") ? 'selected' : '' }} >Venezuela</option>
                                        <option value="Vietnam" {{ ( $supplier_regstr->country == "Vietnam") ? 'selected' : '' }} >Vietnam</option>
                                        <option value="Virgin Islands (Brit)" {{ ( $supplier_regstr->country == "Virgin Islands (Brit)") ? 'selected' : '' }} >Virgin Islands (Brit)</option>
                                        <option value="Virgin Islands (USA)" {{ ( $supplier_regstr->country == "Virgin Islands (USA)") ? 'selected' : '' }} >Virgin Islands (USA)</option>
                                        <option value="Wake Island" {{ ( $supplier_regstr->country == "Wake Island") ? 'selected' : '' }} >Wake Island</option>
                                        <option value="Wallis & Futana Is" {{ ( $supplier_regstr->country == "Wallis & Futana Is") ? 'selected' : '' }} >Wallis & Futana Is</option>
                                        <option value="Yemen" {{ ( $supplier_regstr->country == "Yemen") ? 'selected' : '' }} >Yemen</option>
                                        <option value="Zaire" {{ ( $supplier_regstr->country == "Zaire") ? 'selected' : '' }} >Zaire</option>
                                        <option value="Zambia" {{ ( $supplier_regstr->country == "Zambia") ? 'selected' : '' }} >Zambia</option>
                                        <option value="Zimbabwe" {{ ( $supplier_regstr->country == "Zimbabwe") ? 'selected' : '' }} >Zimbabwe</option>
                                     
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Supplier Alternate Business Address</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Address Line 1</b></label>
                                    <input class="form-control" type="text" name="alt_addr_line_1" id="" value="{{$supplier_alt_regstr->alt_addr_line1 ?? ''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Address Line 2</b></label>
                                    <input class="form-control" type="text" name="alt_addr_line_2" id="" value="{{$supplier_alt_regstr->alt_addr_line2 ?? ''}}"/>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-4">
                                    <label><b>State</b></label>
                                    <input class="form-control" type="text" name="alt_addr_state" id="" value="{{$supplier_alt_regstr->alt_state ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>City</b></label>
                                    <input class="form-control" type="text" name="alt_addr_city" id="" value="{{$supplier_alt_regstr->alt_city ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-4">
                                    <label><b>Postal Code</b></label>
                                    <input class="form-control" type="text" name="alt_addr_postal" id="" value="{{$supplier_alt_regstr->alt_postal ?? ''}}"/>
                                </div>
                                
                            </div>
                            <div class="form-row">
                                <div class="form-group col-lg-12">
                                    <label><b>Country</b></label>
                                    {{-- <input class="form-control" type="text" name="alt_addr_country" id=""/> --}}
                                    <select name="alt_addr_country" class="form-control">
                                        <option value="Afganistan" {{ ( $supplier_alt_regstr->alt_country == "Afganistan") ? 'selected' : '' }} >Afganistan</option>
                                        <option value="Albania" {{ ( $supplier_alt_regstr->alt_country == "Albania") ? 'selected' : '' }} >Albania</option>
                                        <option value="Algeria" {{ ( $supplier_alt_regstr->alt_country == "Algeria") ? 'selected' : '' }} >Algeria</option>
                                        <option value="American Samoa" {{ ( $supplier_alt_regstr->alt_country == "American Samoa") ? 'selected' : '' }} >American Samoa</option>
                                        <option value="Andorra" {{ ( $supplier_alt_regstr->alt_country == "Andorra") ? 'selected' : '' }} >Andorra</option>
                                        <option value="Angola" {{ ( $supplier_alt_regstr->alt_country == "Angola") ? 'selected' : '' }} >Angola</option>
                                        <option value="Anguilla" {{ ( $supplier_alt_regstr->alt_country == "Anguilla") ? 'selected' : '' }} >Anguilla</option>
                                        <option value="Antigua & Barbuda" {{ ( $supplier_alt_regstr->alt_country == "Antigua & Barbuda") ? 'selected' : '' }} >Antigua & Barbuda</option>
                                        <option value="Argentina" {{ ( $supplier_alt_regstr->alt_country == "Argentina") ? 'selected' : '' }} >Argentina</option>
                                        <option value="Armenia" {{ ( $supplier_alt_regstr->alt_country == "Armenia") ? 'selected' : '' }} >Armenia</option>
                                        <option value="Aruba" {{ ( $supplier_alt_regstr->alt_country == "Aruba") ? 'selected' : '' }} >Aruba</option>
                                        <option value="Australia" {{ ( $supplier_alt_regstr->alt_country == "Australia") ? 'selected' : '' }} >Australia</option>
                                        <option value="Austria" {{ ( $supplier_alt_regstr->alt_country == "Austria") ? 'selected' : '' }} >Austria</option>
                                        <option value="Azerbaijan" {{ ( $supplier_alt_regstr->alt_country == "Azerbaijan") ? 'selected' : '' }} >Azerbaijan</option>
                                        <option value="Bahamas" {{ ( $supplier_alt_regstr->alt_country == "Bahamas") ? 'selected' : '' }} >Bahamas</option>
                                        <option value="Bahrain" {{ ( $supplier_alt_regstr->alt_country == "Bahrain") ? 'selected' : '' }} >Bahrain</option>
                                        <option value="Bangladesh" {{ ( $supplier_alt_regstr->alt_country == "Bangladesh") ? 'selected' : '' }} >Bangladesh</option>
                                        <option value="Barbados" {{ ( $supplier_alt_regstr->alt_country == "Barbados") ? 'selected' : '' }} >Barbados</option>
                                        <option value="Belarus" {{ ( $supplier_alt_regstr->alt_country == "Belarus") ? 'selected' : '' }} >Belarus</option>
                                        <option value="Belgium" {{ ( $supplier_alt_regstr->alt_country == "Belgium") ? 'selected' : '' }} >Belgium</option>
                                        <option value="Belize" {{ ( $supplier_alt_regstr->alt_country == "Belize") ? 'selected' : '' }} >Belize</option>
                                        <option value="Benin" {{ ( $supplier_alt_regstr->alt_country == "Benin") ? 'selected' : '' }} >Benin</option>
                                        <option value="Bermuda" {{ ( $supplier_alt_regstr->alt_country == "Bermuda") ? 'selected' : '' }} >Bermuda</option>
                                        <option value="Bhutan" {{ ( $supplier_alt_regstr->alt_country == "Bhutan") ? 'selected' : '' }} >Bhutan</option>
                                        <option value="Bolivia" {{ ( $supplier_alt_regstr->alt_country == "Bolivia") ? 'selected' : '' }} >Bolivia</option>
                                        <option value="Bonaire" {{ ( $supplier_alt_regstr->alt_country == "Bonaire") ? 'selected' : '' }} >Bonaire</option>
                                        <option value="Bosnia & Herzegovina" {{ ( $supplier_alt_regstr->alt_country == "Bosnia & Herzegovina") ? 'selected' : '' }} >Bosnia & Herzegovina</option>
                                        <option value="Botswana" {{ ( $supplier_alt_regstr->alt_country == "Botswana") ? 'selected' : '' }} >Botswana</option>
                                        <option value="Brazil" {{ ( $supplier_alt_regstr->alt_country == "Brazil") ? 'selected' : '' }} >Brazil</option>
                                        <option value="British Indian Ocean Ter" {{ ( $supplier_alt_regstr->alt_country == "British Indian Ocean Ter") ? 'selected' : '' }} >British Indian Ocean Ter</option>
                                        <option value="Brunei" {{ ( $supplier_alt_regstr->alt_country == "Brunei") ? 'selected' : '' }} >Brunei</option>
                                        <option value="Bulgaria" {{ ( $supplier_alt_regstr->alt_country == "Bulgaria") ? 'selected' : '' }} >Bulgaria</option>
                                        <option value="Burkina Faso" {{ ( $supplier_alt_regstr->alt_country == "Burkina Faso") ? 'selected' : '' }} >Burkina Faso</option>
                                        <option value="Burundi" {{ ( $supplier_alt_regstr->alt_country == "Burundi") ? 'selected' : '' }} >Burundi</option>
                                        <option value="Cambodia" {{ ( $supplier_alt_regstr->alt_country == "Cambodia") ? 'selected' : '' }} >Cambodia</option>
                                        <option value="Cameroon" {{ ( $supplier_alt_regstr->alt_country == "Cameroon") ? 'selected' : '' }} >Cameroon</option>
                                        <option value="Canada" {{ ( $supplier_alt_regstr->alt_country == "Canada") ? 'selected' : '' }} >Canary Islands</option>
                                        <option value="Canary Islands" {{ ( $supplier_alt_regstr->alt_country == "Canary Islands") ? 'selected' : '' }} >Canada</option>
                                        <option value="Cape Verde" {{ ( $supplier_alt_regstr->alt_country == "Cape Verde") ? 'selected' : '' }} >Cape Verde</option>
                                        <option value="Cayman Islands" {{ ( $supplier_alt_regstr->alt_country == "Cayman Islands") ? 'selected' : '' }} >Cayman Islands</option>
                                        <option value="Central African Republic" {{ ( $supplier_alt_regstr->alt_country == "Central African Republic") ? 'selected' : '' }} >Central African Republic</option>
                                        <option value="Chad" {{ ( $supplier_alt_regstr->alt_country == "Chad") ? 'selected' : '' }} >Chad</option>
                                        <option value="Channel Islands" {{ ( $supplier_alt_regstr->alt_country == "Channel Islands") ? 'selected' : '' }} >Channel Islands</option>
                                        <option value="Chile" {{ ( $supplier_alt_regstr->alt_country == "Chile") ? 'selected' : '' }} >Chile</option>
                                        <option value="China" {{ ( $supplier_alt_regstr->alt_country == "China") ? 'selected' : '' }} >China</option>
                                        <option value="Christmas Island" {{ ( $supplier_alt_regstr->alt_country == "Christmas Island") ? 'selected' : '' }} >Christmas Island</option>
                                        <option value="Cocos Island" {{ ( $supplier_alt_regstr->alt_country == "Cocos Island") ? 'selected' : '' }} >Cocos Island</option>
                                        <option value="Colombia" {{ ( $supplier_alt_regstr->alt_country == "Colombia") ? 'selected' : '' }} >Colombia</option>
                                        <option value="Comoros" {{ ( $supplier_alt_regstr->alt_country == "Comoros") ? 'selected' : '' }} >Comoros</option>
                                        <option value="Congo" {{ ( $supplier_alt_regstr->alt_country == "Congo") ? 'selected' : '' }} >Congo</option>
                                        <option value="Cook Islands" {{ ( $supplier_alt_regstr->alt_country == "Cook Islands") ? 'selected' : '' }} >Cook Islands</option>
                                        <option value="Costa Rica" {{ ( $supplier_alt_regstr->alt_country == "Costa Rica") ? 'selected' : '' }} >Costa Rica</option>
                                        <option value="Cote DIvoire" {{ ( $supplier_alt_regstr->alt_country == "Cote DIvoire") ? 'selected' : '' }} >Cote DIvoire</option>
                                        <option value="Croatia" {{ ( $supplier_alt_regstr->alt_country == "Croatia") ? 'selected' : '' }} >Croatia</option>
                                        <option value="Cuba" {{ ( $supplier_alt_regstr->alt_country == "Cuba") ? 'selected' : '' }} >Cuba</option>
                                        <option value="Curaco" {{ ( $supplier_alt_regstr->alt_country == "Curaco") ? 'selected' : '' }} >Curaco</option>
                                        <option value="Cyprus" {{ ( $supplier_alt_regstr->alt_country == "Cyprus") ? 'selected' : '' }} >Cyprus</option>
                                        <option value="Czech Republic" {{ ( $supplier_alt_regstr->alt_country == "Czech Republic") ? 'selected' : '' }} >Czech Republic</option>
                                        <option value="Denmark" {{ ( $supplier_alt_regstr->alt_country == "Denmark") ? 'selected' : '' }} >Denmark</option>
                                        <option value="Djibouti" {{ ( $supplier_alt_regstr->alt_country == "Djibouti") ? 'selected' : '' }} >Djibouti</option>
                                        <option value="Dominica" {{ ( $supplier_alt_regstr->alt_country == "Dominica") ? 'selected' : '' }} >Dominica</option>
                                        <option value="Dominican Republic" {{ ( $supplier_alt_regstr->alt_country == "Dominican Republic") ? 'selected' : '' }} >Dominican Republic</option>
                                        <option value="East Timor" {{ ( $supplier_alt_regstr->alt_country == "East Timor") ? 'selected' : '' }} >East Timor</option>
                                        <option value="Ecuador" {{ ( $supplier_alt_regstr->alt_country == "Ecuador") ? 'selected' : '' }} >Ecuador</option>
                                        <option value="Egypt" {{ ( $supplier_alt_regstr->alt_country == "Egypt") ? 'selected' : '' }} >Egypt</option>
                                        <option value="Equatorial Guinea" {{ ( $supplier_alt_regstr->alt_country == "El Salvador") ? 'selected' : '' }} >El Salvador</option>
                                        <option value="Eritrea" {{ ( $supplier_alt_regstr->alt_country == "Eritrea") ? 'selected' : '' }} >Eritrea</option>
                                        <option value="Estonia" {{ ( $supplier_alt_regstr->alt_country == "Estonia") ? 'selected' : '' }} >Estonia</option>
                                        <option value="Ethiopia" {{ ( $supplier_alt_regstr->alt_country == "Ethiopia") ? 'selected' : '' }} >Ethiopia</option>
                                        <option value="Falkland Islands" {{ ( $supplier_alt_regstr->alt_country == "Falkland Islands") ? 'selected' : '' }} >Falkland Islands</option>
                                        <option value="Faroe Islands" {{ ( $supplier_alt_regstr->alt_country == "Faroe Islands") ? 'selected' : '' }} >Faroe Islands</option>
                                        <option value="Fiji" {{ ( $supplier_alt_regstr->alt_country == "Fiji") ? 'selected' : '' }} >Fiji</option>
                                        <option value="Finland" {{ ( $supplier_alt_regstr->alt_country == "Finland") ? 'selected' : '' }} >Finland</option>
                                        <option value="France" {{ ( $supplier_alt_regstr->alt_country == "France") ? 'selected' : '' }} >France</option>
                                        <option value="French Guiana" {{ ( $supplier_alt_regstr->alt_country == "French Guiana") ? 'selected' : '' }} >French Guiana</option>
                                        <option value="French Polynesia" {{ ( $supplier_alt_regstr->alt_country == "French Polynesia") ? 'selected' : '' }} >French Polynesia</option>
                                        <option value="French Southern Ter" {{ ( $supplier_alt_regstr->alt_country == "French Southern Ter") ? 'selected' : '' }} >French Southern Ter  </option>
                                        <option value="Gabon" {{ ( $supplier_alt_regstr->alt_country == "Gabon") ? 'selected' : '' }} >Gabon  </option>
                                        <option value="Gambia" {{ ( $supplier_alt_regstr->alt_country == "Gambia") ? 'selected' : '' }} >Gambia  </option>
                                        <option value="Germany" {{ ( $supplier_alt_regstr->alt_country == "Germany") ? 'selected' : '' }} >Germany  </option>
                                        <option value="Ghana" {{ ( $supplier_alt_regstr->alt_country == "Ghana") ? 'selected' : '' }} >Ghana  </option>
                                        <option value="Great Britain" {{ ( $supplier_alt_regstr->alt_country == "Great Britain") ? 'selected' : '' }} >Great Britain  </option>
                                        <option value="Greece" {{ ( $supplier_alt_regstr->alt_country == "Greece") ? 'selected' : '' }} >Greece  </option>
                                        <option value="Greenland" {{ ( $supplier_alt_regstr->alt_country == "Greenland") ? 'selected' : '' }} >Greenland  </option>
                                        <option value="Grenada" {{ ( $supplier_alt_regstr->alt_country == "Grenada") ? 'selected' : '' }} >Grenada  </option>
                                        <option value="Guadeloupe" {{ ( $supplier_alt_regstr->alt_country == "Guadeloupe") ? 'selected' : '' }} >Guadeloupe  </option>
                                        <option value="Guam" {{ ( $supplier_alt_regstr->alt_country == "Guam") ? 'selected' : '' }} >Guam  </option>
                                        <option value="Guatemala" {{ ( $supplier_alt_regstr->alt_country == "Guatemala") ? 'selected' : '' }} >Guatemala  </option>
                                        <option value="Guinea" {{ ( $supplier_alt_regstr->alt_country == "Guinea") ? 'selected' : '' }} >Guinea  </option>
                                        <option value="Guyana" {{ ( $supplier_alt_regstr->alt_country == "Guyana") ? 'selected' : '' }} >Guyana  </option>
                                        <option value="Haiti" {{ ( $supplier_alt_regstr->alt_country == "Haiti") ? 'selected' : '' }} >Haiti  </option>
                                        <option value="Hawaii" {{ ( $supplier_alt_regstr->alt_country == "Hawaii") ? 'selected' : '' }} >Hawaii  </option>
                                        <option value="Honduras" {{ ( $supplier_alt_regstr->alt_country == "Honduras") ? 'selected' : '' }} >Honduras  </option>
                                        <option value="Hong Kong" {{ ( $supplier_alt_regstr->alt_country == "Hong Kong") ? 'selected' : '' }} >Hong Kong  </option>
                                        <option value="Hungary" {{ ( $supplier_alt_regstr->alt_country == "Hungary") ? 'selected' : '' }} >Hungary  </option>
                                        <option value="Iceland" {{ ( $supplier_alt_regstr->alt_country == "Iceland") ? 'selected' : '' }} >Iceland  </option>
                                        <option value="Indonesia" {{ ( $supplier_alt_regstr->alt_country == "Indonesia") ? 'selected' : '' }} >Indonesia  </option>
                                        <option value="India" {{ ( $supplier_alt_regstr->alt_country == "India") ? 'selected' : '' }} >India  </option>
                                        <option value="Iran" {{ ( $supplier_alt_regstr->alt_country == "Iran") ? 'selected' : '' }} >Iran  </option>
                                        <option value="Iraq" {{ ( $supplier_alt_regstr->alt_country == "Iraq") ? 'selected' : '' }} >Iraq  </option>
                                        <option value="Ireland" {{ ( $supplier_alt_regstr->alt_country == "Ireland") ? 'selected' : '' }} >Ireland  </option>
                                        <option value="Isle of Man" {{ ( $supplier_alt_regstr->alt_country == "Isle of Man") ? 'selected' : '' }} >Isle of Man  </option>
                                        <option value="Israel" {{ ( $supplier_alt_regstr->alt_country == "Israel") ? 'selected' : '' }} >Israel</option>
                                        <option value="Italy" {{ ( $supplier_alt_regstr->alt_country == "Italy") ? 'selected' : '' }} >Italy</option>
                                        <option value="Jamaica" {{ ( $supplier_alt_regstr->alt_country == "Jamaica") ? 'selected' : '' }} >Jamaica</option>
                                        <option value="Japan" {{ ( $supplier_alt_regstr->alt_country == "Japan") ? 'selected' : '' }} >Japan</option>
                                        <option value="Jordan" {{ ( $supplier_alt_regstr->alt_country == "Jordan") ? 'selected' : '' }} >Jordan</option>
                                        <option value="Kazakhstan" {{ ( $supplier_alt_regstr->alt_country == "Kazakhstan") ? 'selected' : '' }} >Kazakhstan</option>
                                        <option value="Kenya" {{ ( $supplier_alt_regstr->alt_country == "Kenya") ? 'selected' : '' }} >Kenya</option>
                                        <option value="Kiribati" {{ ( $supplier_alt_regstr->alt_country == "Kiribati") ? 'selected' : '' }} >Kiribati</option>
                                        <option value="Korea North" {{ ( $supplier_alt_regstr->alt_country == "Korea North") ? 'selected' : '' }} >Korea North</option>
                                        <option value="Korea South" {{ ( $supplier_alt_regstr->alt_country == "Korea South") ? 'selected' : '' }} >Korea South</option>
                                        <option value="Kuwait" {{ ( $supplier_alt_regstr->alt_country == "Kuwait") ? 'selected' : '' }} >Kuwait</option>
                                        <option value="Kyrgyzstan" {{ ( $supplier_alt_regstr->alt_country == "Kyrgyzstan") ? 'selected' : '' }} >Kyrgyzstan</option>
                                        <option value="Laos" {{ ( $supplier_alt_regstr->alt_country == "Laos") ? 'selected' : '' }} >Laos</option>
                                        <option value="Latvia" {{ ( $supplier_alt_regstr->alt_country == "Latvia") ? 'selected' : '' }} >Latvia</option>
                                        <option value="Lebanon" {{ ( $supplier_alt_regstr->alt_country == "Lebanon") ? 'selected' : '' }} >Lebanon</option>
                                        <option value="Lesotho" {{ ( $supplier_alt_regstr->alt_country == "Lesotho") ? 'selected' : '' }} >Lesotho</option>
                                        <option value="Liberia" {{ ( $supplier_alt_regstr->alt_country == "Liberia") ? 'selected' : '' }} >Liberia</option>
                                        <option value="Libya" {{ ( $supplier_alt_regstr->alt_country == "Libya") ? 'selected' : '' }} >Libya</option>
                                        <option value="Liechtenstein" {{ ( $supplier_alt_regstr->alt_country == "Liechtenstein") ? 'selected' : '' }} >Liechtenstein</option>
                                        <option value="Lithuania" {{ ( $supplier_alt_regstr->alt_country == "Lithuania") ? 'selected' : '' }} >Lithuania</option>
                                        <option value="Luxembourg" {{ ( $supplier_alt_regstr->alt_country == "Luxembourg") ? 'selected' : '' }} >Luxembourg</option>
                                        <option value="Macau" {{ ( $supplier_alt_regstr->alt_country == "Macau") ? 'selected' : '' }} >Macau</option>
                                        <option value="Macedonia" {{ ( $supplier_alt_regstr->alt_country == "Macedonia") ? 'selected' : '' }} >Macedonia</option>
                                        <option value="Madagascar" {{ ( $supplier_alt_regstr->alt_country == "Madagascar") ? 'selected' : '' }} >Madagascar</option>
                                        <option value="Malaysia" {{ ( $supplier_alt_regstr->alt_country == "Malaysia") ? 'selected' : '' }} >Malaysia</option>
                                        <option value="Malawi" {{ ( $supplier_alt_regstr->alt_country == "Malawi") ? 'selected' : '' }} >Malawi</option>
                                        <option value="Maldives" {{ ( $supplier_alt_regstr->alt_country == "Maldives") ? 'selected' : '' }} >Maldives</option>
                                        <option value="Mali" {{ ( $supplier_alt_regstr->alt_country == "Mali") ? 'selected' : '' }} >Mali</option>
                                        <option value="Malta" {{ ( $supplier_alt_regstr->alt_country == "Malta") ? 'selected' : '' }} >Malta</option>
                                        <option value="Marshall Islands" {{ ( $supplier_alt_regstr->alt_country == "Marshall Islands") ? 'selected' : '' }} >Marshall Islands</option>
                                        <option value="Martinique" {{ ( $supplier_alt_regstr->alt_country == "Martinique") ? 'selected' : '' }} >Martinique</option>
                                        <option value="Mauritania" {{ ( $supplier_alt_regstr->alt_country == "Mauritania") ? 'selected' : '' }} >Mauritania</option>
                                        <option value="Mauritius" {{ ( $supplier_alt_regstr->alt_country == "Mauritius") ? 'selected' : '' }} >Mauritius</option>
                                        <option value="Mayotte" {{ ( $supplier_alt_regstr->alt_country == "Mayotte") ? 'selected' : '' }} >Mayotte</option>
                                        <option value="Mexico" {{ ( $supplier_alt_regstr->alt_country == "Mexico") ? 'selected' : '' }} >Mexico</option>
                                        <option value="Midway Islands" {{ ( $supplier_alt_regstr->alt_country == "Midway Islands") ? 'selected' : '' }} >Midway Islands</option>
                                        <option value="Moldova" {{ ( $supplier_alt_regstr->alt_country == "Moldova") ? 'selected' : '' }} >Moldova</option>
                                        <option value="Monaco" {{ ( $supplier_alt_regstr->alt_country == "Monaco") ? 'selected' : '' }} >Monaco</option>
                                        <option value="Mongolia" {{ ( $supplier_alt_regstr->alt_country == "Mongolia") ? 'selected' : '' }} >Mongolia</option>
                                        <option value="Montserrat" {{ ( $supplier_alt_regstr->alt_country == "Montserrat") ? 'selected' : '' }} >Montserrat</option>
                                        <option value="Morocco" {{ ( $supplier_alt_regstr->alt_country == "Morocco") ? 'selected' : '' }} >Morocco</option>
                                        <option value="Mozambique" {{ ( $supplier_alt_regstr->alt_country == "Mozambique") ? 'selected' : '' }} >Mozambique</option>
                                        <option value="Myanmar" {{ ( $supplier_alt_regstr->alt_country == "Myanmar") ? 'selected' : '' }} >Myanmar</option>
                                        <option value="Nambia" {{ ( $supplier_alt_regstr->alt_country == "Nambia") ? 'selected' : '' }} >Nambia</option>
                                        <option value="Nauru" {{ ( $supplier_alt_regstr->alt_country == "Nauru") ? 'selected' : '' }} >Nauru</option>
                                        <option value="Nepal" {{ ( $supplier_alt_regstr->alt_country == "Nepal") ? 'selected' : '' }} >Nepal</option>
                                        <option value="Netherland Antilles" {{ ( $supplier_alt_regstr->alt_country == "Netherland Antilles") ? 'selected' : '' }} >Netherland Antilles</option>
                                        <option value="Netherlands" {{ ( $supplier_alt_regstr->alt_country == "Netherlands") ? 'selected' : '' }} >Netherlands</option>
                                        <option value="Nevis" {{ ( $supplier_alt_regstr->alt_country == "Nevis") ? 'selected' : '' }} >Nevis</option>
                                        <option value="New Caledonia" {{ ( $supplier_alt_regstr->alt_country == "New Caledonia") ? 'selected' : '' }} >New Caledonia</option>
                                        <option value="New Zealand" {{ ( $supplier_alt_regstr->alt_country == "New Zealand") ? 'selected' : '' }} >New Zealand</option>
                                        <option value="Nicaragua" {{ ( $supplier_alt_regstr->alt_country == "Nicaragua") ? 'selected' : '' }} >Nicaragua</option>
                                        <option value="Niger" {{ ( $supplier_alt_regstr->alt_country == "Niger") ? 'selected' : '' }} >Niger</option>
                                        <option value="Nigeria" {{ ( $supplier_alt_regstr->alt_country == "Nigeria") ? 'selected' : '' }} >Nigeria</option>
                                        <option value="Niue" {{ ( $supplier_alt_regstr->alt_country == "Niue") ? 'selected' : '' }} >Niue</option>
                                        <option value="Norfolk Island" {{ ( $supplier_alt_regstr->alt_country == "Norfolk Island") ? 'selected' : '' }} >Norfolk Island</option>
                                        <option value="Norway" {{ ( $supplier_alt_regstr->alt_country == "Norway") ? 'selected' : '' }} >Norway</option>
                                        <option value="Oman" {{ ( $supplier_alt_regstr->alt_country == "Oman") ? 'selected' : '' }} >Oman</option>
                                        <option value="Pakistan" {{ ( $supplier_alt_regstr->alt_country == "Pakistan") ? 'selected' : '' }} >Pakistan</option>
                                        <option value="Palau Island" {{ ( $supplier_alt_regstr->alt_country == "Palau Island") ? 'selected' : '' }} >Palau Island</option>
                                        <option value="Palestine" {{ ( $supplier_alt_regstr->alt_country == "Palestine") ? 'selected' : '' }} >Palestine</option>
                                        <option value="Panama" {{ ( $supplier_alt_regstr->alt_country == "Panama") ? 'selected' : '' }} >Panama</option>
                                        <option value="Papua New Guinea" {{ ( $supplier_alt_regstr->alt_country == "Papua New Guinea") ? 'selected' : '' }} >Papua New Guinea</option>
                                        <option value="Paraguay" {{ ( $supplier_alt_regstr->alt_country == "Paraguay") ? 'selected' : '' }} >Paraguay</option>
                                        <option value="Peru" {{ ( $supplier_alt_regstr->alt_country == "Peru") ? 'selected' : '' }} >Peru</option>
                                        <option value="Phillipines" {{ ( $supplier_alt_regstr->alt_country == "Phillipines") ? 'selected' : '' }} >Phillipines</option>
                                        <option value="Pitcairn Island" {{ ( $supplier_alt_regstr->alt_country == "Pitcairn Island") ? 'selected' : '' }} >Pitcairn Island</option>
                                        <option value="Poland" {{ ( $supplier_alt_regstr->alt_country == "Poland") ? 'selected' : '' }} >Poland</option>
                                        <option value="Portugal" {{ ( $supplier_alt_regstr->alt_country == "Portugal") ? 'selected' : '' }} >Portugal</option>
                                        <option value="Puerto Rico" {{ ( $supplier_alt_regstr->alt_country == "Puerto Rico") ? 'selected' : '' }} >Puerto Rico</option>
                                        <option value="Qatar" {{ ( $supplier_alt_regstr->alt_country == "Qatar") ? 'selected' : '' }} >Qatar</option>
                                        <option value="Republic of Montenegro" {{ ( $supplier_alt_regstr->alt_country == "Republic of Montenegro") ? 'selected' : '' }} >Republic of Montenegro</option>
                                        <option value="Republic of Serbia" {{ ( $supplier_alt_regstr->alt_country == "Republic of Serbia") ? 'selected' : '' }} >Republic of Serbia</option>
                                        <option value="Reunion" {{ ( $supplier_alt_regstr->alt_country == "Reunion") ? 'selected' : '' }} >Reunion</option>
                                        <option value="Romania" {{ ( $supplier_alt_regstr->alt_country == "Romania") ? 'selected' : '' }} >Romania</option>
                                        <option value="Russia" {{ ( $supplier_alt_regstr->alt_country == "Russia") ? 'selected' : '' }} >Russia</option>
                                        <option value="Rwanda" {{ ( $supplier_alt_regstr->alt_country == "Rwanda") ? 'selected' : '' }} >Rwanda</option>
                                        <option value="St Barthelemy" {{ ( $supplier_alt_regstr->alt_country == "St Barthelemy") ? 'selected' : '' }} >St Barthelemy</option>
                                        <option value="St Eustatius" {{ ( $supplier_alt_regstr->alt_country == "St Eustatius") ? 'selected' : '' }} >St Eustatius</option>
                                        <option value="St Helena" {{ ( $supplier_alt_regstr->alt_country == "St Helena") ? 'selected' : '' }} >St Helena</option>
                                        <option value="St Kitts-Nevis" {{ ( $supplier_alt_regstr->alt_country == "St Kitts-Nevis") ? 'selected' : '' }} >St Kitts-Nevis</option>
                                        <option value="St Lucia" {{ ( $supplier_alt_regstr->alt_country == "St Lucia") ? 'selected' : '' }} >St Lucia</option>
                                        <option value="St Maarten" {{ ( $supplier_alt_regstr->alt_country == "St Maarten") ? 'selected' : '' }} >St Maarten</option>
                                        <option value="St Pierre & Miquelon" {{ ( $supplier_alt_regstr->alt_country == "St Pierre & Miquelon") ? 'selected' : '' }} >St Pierre & Miquelon</option>
                                        <option value="St Vincent & Grenadines" {{ ( $supplier_alt_regstr->alt_country == "St Vincent & Grenadines") ? 'selected' : '' }} >St Vincent & Grenadines</option>
                                        <option value="Saipan" {{ ( $supplier_alt_regstr->alt_country == "Saipan") ? 'selected' : '' }} >Saipan</option>
                                        <option value="Samoa" {{ ( $supplier_alt_regstr->alt_country == "Samoa") ? 'selected' : '' }} >Samoa</option>
                                        <option value="Samoa American" {{ ( $supplier_alt_regstr->alt_country == "Samoa American") ? 'selected' : '' }} >Samoa American</option>
                                        <option value="San Marino" {{ ( $supplier_alt_regstr->alt_country == "San Marino") ? 'selected' : '' }} >San Marino</option>
                                        <option value="San Marino" {{ ( $supplier_alt_regstr->alt_country == "San Marino") ? 'selected' : '' }} >San Marino</option>
                                        <option value="Sao Tome & Principe" {{ ( $supplier_alt_regstr->alt_country == "Sao Tome & Principe") ? 'selected' : '' }} >Sao Tome & Principe</option>
                                        <option value="Saudi Arabia" {{ ( $supplier_alt_regstr->alt_country == "Saudi Arabia") ? 'selected' : '' }} >Saudi Arabia</option>
                                        <option value="Senegal" {{ ( $supplier_alt_regstr->alt_country == "Senegal") ? 'selected' : '' }} >Senegal</option>
                                        <option value="Seychelles" {{ ( $supplier_alt_regstr->alt_country == "Seychelles") ? 'selected' : '' }} >Seychelles</option>
                                        <option value="Sierra Leone" {{ ( $supplier_alt_regstr->alt_country == "Sierra Leone") ? 'selected' : '' }} >Sierra Leone</option>
                                        <option value="Singapore" {{ ( $supplier_alt_regstr->alt_country == "Singapore") ? 'selected' : '' }} >Singapore</option>
                                        <option value="Slovakia" {{ ( $supplier_alt_regstr->alt_country == "Slovakia") ? 'selected' : '' }} >Slovakia</option>
                                        <option value="Slovenia" {{ ( $supplier_alt_regstr->alt_country == "Slovenia") ? 'selected' : '' }} >Slovenia</option>
                                        <option value="Solomon Islands" {{ ( $supplier_alt_regstr->alt_country == "Solomon Islands") ? 'selected' : '' }} >Solomon Islands</option>
                                        <option value="Somalia" {{ ( $supplier_alt_regstr->alt_country == "Somalia") ? 'selected' : '' }} >Somalia</option>
                                        <option value="South Africa" {{ ( $supplier_alt_regstr->alt_country == "South Africa") ? 'selected' : '' }} >South Africa</option>
                                        <option value="Spain" {{ ( $supplier_alt_regstr->alt_country == "Spain") ? 'selected' : '' }} >Spain</option>
                                        <option value="Sri Lanka" {{ ( $supplier_alt_regstr->alt_country == "Sri Lanka") ? 'selected' : '' }} >Sri Lanka</option>
                                        <option value="Sudan" {{ ( $supplier_alt_regstr->alt_country == "Sudan") ? 'selected' : '' }} >Sudan</option>
                                        <option value="Suriname" {{ ( $supplier_alt_regstr->alt_country == "Suriname") ? 'selected' : '' }} >Suriname</option>
                                        <option value="Swaziland" {{ ( $supplier_alt_regstr->alt_country == "Swaziland") ? 'selected' : '' }} >Swaziland</option>
                                        <option value="Sweden" {{ ( $supplier_alt_regstr->alt_country == "Sweden") ? 'selected' : '' }} >Sweden</option>
                                        <option value="Switzerland" {{ ( $supplier_alt_regstr->alt_country == "Switzerland") ? 'selected' : '' }} >Switzerland</option>
                                        <option value="Syria" {{ ( $supplier_alt_regstr->alt_country == "Syria") ? 'selected' : '' }} >Syria</option>
                                        <option value="Tahiti" {{ ( $supplier_alt_regstr->alt_country == "Tahiti") ? 'selected' : '' }} >Tahiti</option>
                                        <option value="Taiwan" {{ ( $supplier_alt_regstr->alt_country == "Taiwan") ? 'selected' : '' }} >Taiwan</option>
                                        <option value="Tajikistan" {{ ( $supplier_alt_regstr->alt_country == "Tajikistan") ? 'selected' : '' }} >Tajikistan</option>
                                        <option value="Tanzania" {{ ( $supplier_alt_regstr->alt_country == "Tanzania") ? 'selected' : '' }} >Tanzania</option>
                                        <option value="Thailand" {{ ( $supplier_alt_regstr->alt_country == "Thailand") ? 'selected' : '' }} >Thailand</option>
                                        <option value="Togo" {{ ( $supplier_alt_regstr->alt_country == "Togo") ? 'selected' : '' }} >Togo</option>
                                        <option value="Tokelau" {{ ( $supplier_alt_regstr->alt_country == "Tokelau") ? 'selected' : '' }} >Tokelau</option>
                                        <option value="Tonga" {{ ( $supplier_alt_regstr->alt_country == "Tonga") ? 'selected' : '' }} >Tonga</option>
                                        <option value="Trinidad & Tobago" {{ ( $supplier_alt_regstr->alt_country == "Trinidad & Tobago") ? 'selected' : '' }} >Trinidad & Tobago</option>
                                        <option value="Tunisia" {{ ( $supplier_alt_regstr->alt_country == "Tunisia") ? 'selected' : '' }} >Tunisia</option>
                                        <option value="Turkey" {{ ( $supplier_alt_regstr->alt_country == "Turkey") ? 'selected' : '' }} >Turkey</option>
                                        <option value="Turkmenistan" {{ ( $supplier_alt_regstr->alt_country == "Turkmenistan") ? 'selected' : '' }} >Turkmenistan</option>
                                        <option value="Turks & Caicos Is" {{ ( $supplier_alt_regstr->alt_country == "Turks & Caicos Is") ? 'selected' : '' }} >Turks & Caicos Is</option>
                                        <option value="Tuvalu" {{ ( $supplier_alt_regstr->alt_country == "Tuvalu") ? 'selected' : '' }} >Tuvalu</option>
                                        <option value="Uganda" {{ ( $supplier_alt_regstr->alt_country == "Uganda") ? 'selected' : '' }} >Uganda</option>
                                        <option value="United Kingdom" {{ ( $supplier_alt_regstr->alt_country == "United Kingdom") ? 'selected' : '' }} >United Kingdom</option>
                                        <option value="Ukraine" {{ ( $supplier_alt_regstr->alt_country == "Ukraine") ? 'selected' : '' }} >Ukraine</option>
                                        <option value="United Arab Erimates" {{ ( $supplier_alt_regstr->alt_country == "United Arab Erimates") ? 'selected' : '' }} >United Arab Erimates</option>
                                        <option value="United States of America" {{ ( $supplier_alt_regstr->alt_country == "United States of America") ? 'selected' : '' }} >United States of America</option>
                                        <option value="Uraguay" {{ ( $supplier_alt_regstr->alt_country == "Uraguay") ? 'selected' : '' }} >Uraguay</option>
                                        <option value="Uzbekistan" {{ ( $supplier_alt_regstr->alt_country == "Uzbekistan") ? 'selected' : '' }} >Uzbekistan</option>
                                        <option value="Vanuatu" {{ ( $supplier_alt_regstr->alt_country == "Vanuatu") ? 'selected' : '' }} >Vanuatu</option>
                                        <option value="Vatican City State" {{ ( $supplier_alt_regstr->alt_country == "Vatican City State") ? 'selected' : '' }} >Vatican City State</option>
                                        <option value="Venezuela" {{ ( $supplier_alt_regstr->alt_country == "Venezuela") ? 'selected' : '' }} >Venezuela</option>
                                        <option value="Vietnam" {{ ( $supplier_alt_regstr->alt_country == "Vietnam") ? 'selected' : '' }} >Vietnam</option>
                                        <option value="Virgin Islands (Brit)" {{ ( $supplier_alt_regstr->alt_country == "Virgin Islands (Brit)") ? 'selected' : '' }} >Virgin Islands (Brit)</option>
                                        <option value="Virgin Islands (USA)" {{ ( $supplier_alt_regstr->alt_country == "Virgin Islands (USA)") ? 'selected' : '' }} >Virgin Islands (USA)</option>
                                        <option value="Wake Island" {{ ( $supplier_alt_regstr->alt_country == "Wake Island") ? 'selected' : '' }} >Wake Island</option>
                                        <option value="Wallis & Futana Is" {{ ( $supplier_alt_regstr->alt_country == "Wallis & Futana Is") ? 'selected' : '' }} >Wallis & Futana Is</option>
                                        <option value="Yemen" {{ ( $supplier_alt_regstr->alt_country == "Yemen") ? 'selected' : '' }} >Yemen</option>
                                        <option value="Zaire" {{ ( $supplier_alt_regstr->alt_country == "Zaire") ? 'selected' : '' }} >Zaire</option>
                                        <option value="Zambia" {{ ( $supplier_alt_regstr->alt_country == "Zambia") ? 'selected' : '' }} >Zambia</option>
                                        <option value="Zimbabwe" {{ ( $supplier_alt_regstr->alt_country == "Zimbabwe") ? 'selected' : '' }} >Zimbabwe</option>
                                    </select>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>Point Of Contact</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-3">
                                    <label><b>Name</b></label>
                                    <input class="form-control" type="text" name="comp_poc_name" id="" value="{{$cntct->name ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Phone</b></label>
                                    <input class="form-control" type="text" name="comp_poc_phone" id="" value="{{$cntct->phone ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Mobile</b></label>
                                    <input class="form-control" type="text" name="comp_poc_mobile" id="" value="{{$cntct->mobile ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Email</b></label>
                                    <input class="form-control" type="text" name="comp_poc_email" id="" value="{{$cntct->email ?? ''}}"/>
                                </div>
                            </div>
                        </fieldset>
                        <fieldset>
                            <legend>(Alt) Point Of Contact</legend>
                            <div class="form-row">
                                <div class="form-group col-lg-3">
                                    <label><b>Name</b></label>
                                    <input class="form-control" type="text" name="comp_alt_poc_name" id="" value="{{$alt_contct->alt_name ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Phone</b></label>
                                    <input class="form-control" type="text" name="comp_alt_poc_phone" id="" value="{{$alt_contct->alt_phone ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Mobile</b></label>
                                    <input class="form-control" type="text" name="comp_alt_poc_mobile" id="" value="{{$alt_contct->alt_mobile ?? ''}}"/>
                                </div>
                                <div class="form-group col-lg-3">
                                    <label><b>Email</b></label>
                                    <input class="form-control" type="text" name="comp_alt_poc_email" id="" value="{{$alt_contct->alt_email ?? ''}}"/>
                                </div>
                            </div>
                        </fieldset>


                        <div class="row" style="text-align:center;">
                            <div class="col-lg-12 ml-auto">
                                <button class="btn-cutom">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                    Create Account Payable
                                </button>
                            </div>
                        </div>
                    </form>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>


@endsection

@section("custom_script")

<script>
    function onchkclick(){
            $('#acc_chk_asset_vals').val('');
            chkeles = $('#check_cust');
            if($(chkeles).prop('checked') == true){
                console.log("checked");
                $('#acc_chk_asset_vals').val(1);
            }else{
                console.log("not checked");
                $('#acc_chk_asset_vals').val(0);
            }


            // chkeles.each((index,value)=>{
            //     if($(value).prop('checked') == true){
            //         if($('#cates').val() === ''){
            //             $('#cates').val( $(value).val());
            //         }else{
            //             $('#cates').val( $('#cates').val() + ',' + $(value).val());
            //         }
                    
            //     }
            // });
            // console.log($('#cates').val());
        }
</script>
<script>
    function onchksssclick(){
            $('#acc_chk_asset_valss').val('');
            chkeles = $('#currency');
            if($(chkeles).prop('checked') == true){
                console.log("checked");
                $('#acc_chk_asset_valss').val(1);
            }else{
                console.log("not checked");
                $('#acc_chk_asset_valss').val(0);
            }


            // chkeles.each((index,value)=>{
            //     if($(value).prop('checked') == true){
            //         if($('#cates').val() === ''){
            //             $('#cates').val( $(value).val());
            //         }else{
            //             $('#cates').val( $('#cates').val() + ',' + $(value).val());
            //         }
                    
            //     }
            // });
            // console.log($('#cates').val());
        }
</script>

<script type="text/javascript">
    function validate(event){
        if($('#comp_id').val() === '-1'){
            console.log("in Validate Failed");
            alert("Please Select Company");
            event.preventDefault();
            return false;
        }

        if($('#comp_pay_trms').val() === '-1'){
            alert("Please Select Payment Terms");
            event.preventDefault();
            return false;
        }

        if($('#comp_gst').val() === '-1'){
            alert("Please Select Correct GST");
            event.preventDefault();
            return false;
        }
        
        if($('#comp_curr').val() === '-1'){
            alert("Please Select Correct Currency");
            event.preventDefault();
            return false;
        }
        
        if (isEmpty($('#acc_supplier_name'))) {
            alert("Please Enter Supplier Name");
            event.preventDefault();
            return false;
        }
        // event.preventDefault();
        // return false;
    }

    function isEmpty( el ){
      return !$.trim(el.val())
    }
</script>

@endsection