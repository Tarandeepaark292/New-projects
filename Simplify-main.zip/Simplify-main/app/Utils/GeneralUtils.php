<?php

namespace App\Utils;

// use App\Defines\CartDefines;
// use App\Defines\MiscDefines;
use DB as DBraw;
use Illuminate\Support\Facades\DB;
?>

<?php

class GeneralUtils
{

    /**
     * 
     */
    public static function getCompanyDetails($comp_id){
        $company = DB::table('Company')->where('comp_id',$comp_id)->first();
        $company = json_decode(json_encode($company), true);
        return $company;
    }
    /**
     * 
     */
    public static function get_Fs_main_Cates(){
        $sel_query = "SELECT * FROM FS_main_cate;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $res_array = array();
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $res_array[] = array('main_cate_name'=>$res['cate_name'] , 'main_cate_id'=>$res['cate_id']);
            }
        }
        return $res_array;
    }

    /**
     * 
     */
    public static function get_Fs_sub_Cates(){
        $sel_query = "SELECT * FROM FS_sub_cate;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $res_array = array();
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $res_array[] = array('sub_cate_name'=>$res['sub_cate_name'] , 'sub_cate_id'=>$res['sub_cate_id']);
            }
        }
        return $res_array;
    }

    /**
     * 
     */
    public static function get_gst_list(){
        $gst_collection = DB::table('gst_collection')->get();
        $gst_collection = json_decode(json_encode($gst_collection), true);
        return $gst_collection;
    }

    /**
     * 
     */
    public static function get_supplier_Cates(){
        $supp_cate_arr = DB::table('supplier_cate')->get();
        $supp_cate_arr = json_decode(json_encode($supp_cate_arr), true);
        return $supp_cate_arr;
    }
     /**
     * 
     */
    public static function get_cust_Cates(){
        $cust_cate_arr = DB::table('cust_cate')->get();
        $cust_cate_arr = json_decode(json_encode($cust_cate_arr), true);
        return $cust_cate_arr;
    }

    /**
     * 
     */
    public static function get_pay_Terms(){
        $cust_cate_arr = DB::table('Payment_terms')->get();
        $cust_cate_arr = json_decode(json_encode($cust_cate_arr), true);
        error_log(json_encode($cust_cate_arr));
        return $cust_cate_arr;
    }
    /**
     *
     */
    public static function get_category_Names(){
        $cust_cate_arr = DB::table('FA_main_cate')->get();
        $cust_cate_arr = json_decode(json_encode($cust_cate_arr), true);
        error_log(json_encode($cust_cate_arr));
        return $cust_cate_arr;
    }
    /**
     * 
     */
    
    public static function get_FA_Cates(){
        $sel_query = "SELECT * FROM FA_main_cate;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $res_array = array();
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $res_array[] = array('cate_name'=>$res['fa_cate_name'] , 'cate_id'=>$res['fa_cate_id']);
            }
        }
        return $res_array;
    }

        /**
     *
     */
    public static function get_subcategory_Names()
    {

        $sel_query = "SELECT * FROM fa_sub_cate;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $res_array = array();
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $res_array[] = array('subcate_name'=>$res['fa_sub_cate_name'] , 'cate_id'=>$res['fa_sub_cate_id']);
            }
        }
        return $res_array;
    }
     /**
     *
     */

    public static function get_gst_collection()
    {
        $sel_query = "SELECT * FROM  gst_collection";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $res_array = array();
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $res_array[] = array('g_value'=>$res['gst_val'] , 'g_id'=>$res['gst_id']);
            }
        }
        return $res_array;
    }
      /**
     *
     */
    public static function get_useful_lifes()
    {
        {
            $sel_query = "SELECT * FROM  FA_useful_life";
            $res_query = DBraw::select($sel_query);
            $res_query = json_decode(json_encode($res_query), true);
            $res_array = array();
            if (count($res_query)) {
                foreach ($res_query as $res) {
                    $res_array[] = array('u_life'=>$res['fa_u_life_name'] , 'u_id'=>$res['fa_u_life_id']);
                }
            }
            return $res_array;
        }
    }
    /**
     * 
     */
    public static function CreatePersons($personjson, $compid){
        //return idlistofperson 1,2,3
        $personarr = json_decode($personjson,true);
        $createdate = date("Y-m-d H:i:s");
        $user_arr = array();
        foreach($personarr as $person){
            DB::beginTransaction();
            DB::table('Comp_users')->insert([
                'c_user_name' => $person['name'],
                'c_user_email' => $person['email'],
                'c_user_pwd' => $person['passwd'],
                'c_user_create_date' => $createdate,
                'c_user_comp' => $compid,
                'c_user_sts' => 1
            ]);
            array_push($user_arr,DB::getPdo()->lastInsertId());
            DB::commit();
        }
        return implode(',',$user_arr);
    }

     /**
     * 
     */
    public static function CreatePerson($name, $email, $password, $compid){
        //return idlistofperson 1,2,3
        
        $createdate = date("Y-m-d H:i:s");
        DB::beginTransaction();
        DB::table('Comp_users')->insert([
            'c_user_name' => $name,
            'c_user_email' => $email,
            'c_user_pwd' => $password,
            'c_user_create_date' => $createdate,
            'c_user_comp' => $compid,
            'c_user_sts' => 1
        ]);
        $id = DB::getPdo()->lastInsertId();
        DB::commit();
        return $id;
    }

    /**
     *
     */
    public static function check_fix_asset_cate_name_already_exists($fa_cate_name)
    {
        $asset_name_obj=DB::table('FA_main_cate')->where('fa_cate_name',$fa_cate_name)->first();
        if(!$asset_name_obj){
            return false;

        }
        else
        {
            return true;
        }
    }
     /**
     *
     */

    public static function check_gst_exist($gst_val){
        $gst_exist_obj = DB::table('gst_collection')->where('gst_val',$gst_val)->first();
        if(!$gst_exist_obj){
            return false;
        }else{
            return true;
        }
    }
     /**
     *
     */
    public static function check_payment_terms_exist($pt_value){
        $payment_exist_obj = DB::table('Payment_terms')->where('pt_value',$pt_value)->first();
        if(!$payment_exist_obj){
            return false;
        }else{
            return true;
        }
    }
    /**
     * 
     */
    public static function getCompanyList(){
        $sel_query = "SELECT * FROM Company;";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        $res_array = array();
        if (count($res_query)) {
            foreach ($res_query as $res) {
                $res_array[] = array('comp_name'=>$res['comp_name'] , 'comp_id'=>$res['comp_id']);
            }
        }
        return $res_array;
    }

    /**
     * 
     */
    public static function getCompanyAssignedCOA($comp_id){
        $comp_coa_obj = DB::table('Company_COAs')->where('comp_id',$comp_id)->first();
        if($comp_coa_obj){
            return $comp_coa_obj->comp_coa;
        }
        return null;
    }

    /**
     * 
     */
    public static function check_Comp_COA_exist($comp_id){
        $comp_coa_obj = DB::table('Company_COAs')->where('comp_id',$comp_id)->first();
        if(!$comp_coa_obj){
            return false;
        }else{
            return true;
        }
    }

    /**
     * 
     */
    public static function check_COA_CODE_exist($coa_acc_code){
        $comp_coa_obj = DB::table('COA')->where('coa_acc_code',$coa_acc_code)->first();
        if(!$comp_coa_obj){
            return false;
        }else{
            return true;
        }
    }

    /**
     * 
     */
    public static function check_COA_CODE_WITH_ID_exist($coa_acc_code,$coa_id){
        $comp_coa_obj = DB::table('COA')->where(['coa_acc_code'=>$coa_acc_code, 'coa_id'=>$coa_id])->first();
        if(!$comp_coa_obj){
            return false;
        }else{
            return true;
        }
    }

    /**
     * 
     */
    public static function check_USER_WITH_COMP_ID_exist($c_user_name,$comp_id){
        $comp_User_obj = DB::table('Comp_users')->where(['c_user_name'=>$c_user_name, 'c_user_comp'=>$comp_id])->first();
        if(!$comp_User_obj){
            return false;
        }else{
            return true;
        }
    }

    /**
     * 
     */
    public static function convertCurr($from,$to){
        $res = (1/$to) * $from;
        return number_format($res,4);      
    }


    /**
     * 
     */
    public static function getDistinctCurr(){
        $curr = DB::table('Xcurr')->distinct('xcurr_from')->pluck('xcurr_from');
        $curr = json_decode(json_encode($curr), true);
        error_log(json_encode($curr));
        return $curr;
    }
    /**
     * Generate Currency table
     */
    public static function generateCurrencyTbl($month,$year){
        // $curr_arr = DB::table('Xcurrency')->get(['xcurr_sym','xcurr_value']);
        // $curr_arr = json_decode(json_encode($curr_arr), true);
        $categories = DB::table('Xcurr')->where(['xcurr_month'=>$month, 'xcurr_year'=>$year])->distinct('xcurr_from')->pluck('xcurr_from');
        $categories = json_decode(json_encode($categories), true);
        error_log(json_encode($categories));
        $curr_arr = DB::table('Xcurr')->where(['xcurr_month'=>$month, 'xcurr_year'=>$year])->get(['xcurr_from','xcurr_to','xcurr_val']); 
        $curr_arr = json_decode(json_encode($curr_arr), true);
        $totalCurr = count($categories);
        
        $from_arr = $curr_arr;
        $to_arr = $curr_arr;

        $res_arr = array();
        // foreach($from_arr as $from){
        //     foreach($to_arr as $to){
        //         $res_arr[] = array(
        //             "from"=>$from['xcurr_sym'],
        //             "to"=>$to['xcurr_sym'],
        //             "conv"=>GeneralUtils::convertCurr($from['xcurr_value'],$to['xcurr_value'])
        //             );
        //     }
        // }
        foreach($from_arr as $from){
            $res_arr[] = array(
                "from"=>$from['xcurr_from'],
                    "to"=>$from['xcurr_to'],
                    "conv"=>$from['xcurr_val']
                    );
        }
        $topHtmlrow = "<td><span style='display:block;text-align:right'><b>To</b></span><hr style='transform: rotateZ(24deg);border: 1px solid black;'></hr><span style='display:block'><b>From</b></span></td>";
        foreach ($categories as $to){
            $topHtmlrow = $topHtmlrow . "<td>" . $to . "</to>";
        }
        $topHtmlrow = "<tr>" . $topHtmlrow . "</tr>";
        $temp_count = 0;
        $rows = "";
        foreach($res_arr as $row){
            if(($temp_count % $totalCurr) == 0){
                $rows = $rows . '<tr><td>' . $row['from'] .'</td>';
            }

            $rows = $rows . '<td>' . $row['conv'] . '</td>';

            if(($temp_count % $totalCurr) == ($totalCurr - 1)){
                $rows = $rows . '</tr>';
            }
            
            $temp_count++;
        }

        $table = '<table style="width:100%;" class="table table-sm table-striped table-bordered table-hover">' . $topHtmlrow . $rows . '</table>';


        //dd($res_arr);
        return $table;

    }
    /**
     * Edit Screen Company
     */
    public static function check_company_name($cmp_name){
        $company_name = DB::table('Company')->where('comp_name',$cmp_name)->first();
        if(!$company_name){
            return false;
        }else{
            return true;
        }
    }

    /**
     * 
     */
    public static function check_company_name_ID($cmp_name,$id){
        $company_name = DB::table('Company')->where(['comp_name'=>$cmp_name, 'comp_id'=>$id])->first();
        if(!$company_name){
            return false;
        }else{
            return true;
        }
    }
     public static function check_register_number_exist($r_num){
        $rgt_num = DB::table('Company')->where('comp_reg_number',$r_num)->first();
        if(!$rgt_num){
            return false;
        }else{
            return true;
        }
    }

    /**
     * 
     */
    public static function check_register_number_exist_ID($r_num,$id){
        $rgt_num = DB::table('Company')->where(['comp_reg_number'=>$r_num, 'comp_id'=>$id])->first();
        if(!$rgt_num){
            return false;
        }else{
            return true;
        }
    }
     public static function check_vat_exist($vat){
        $vat_num = DB::table('Company')->where('comp_gst_number',$vat)->first();
        if(!$vat_num){
            return false;
        }else{
            return true;
        }
    }

    /**
     * 
     */
    public static function check_vat_exist_ID($vat,$id){
        $vat_num = DB::table('Company')->where(['comp_gst_number'=>$vat, 'comp_id'=>$id])->first();
        if(!$vat_num){
            return false;
        }else{
            return true;
        }
    }
    /**
     * Create Screen Company
     */
    public static function checkcompanyname($name)
    {
        $sel_query = "SELECT * FROM Company where comp_name = '" . $name . "';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return true;
        } else {
            return false;
        }
    }
    public static function checkcompanyregistration($rgtr)
    {
        $sel_query = "SELECT * FROM Company where comp_reg_number = '" . $rgtr . "';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return true;
        } else {
            return false;
        }
    }
    public static function checkcompanygst($gst)
    {
        $sel_query = "SELECT * FROM Company where comp_gst_number = '" . $gst . "';";
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);
        if (count($res_query)) {
            return true;
        } else {
            return false;
        }
    }
}