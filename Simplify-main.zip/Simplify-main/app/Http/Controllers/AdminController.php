<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Utils\GeneralUtils;
use App\Defines\DataEntryDefines;
use Illuminate\Support\Facades\DB;
use DB as DBraw;

class AdminController extends Controller
{
    //
    /**
     * 
     */
    public function show_dashboard(Request $request)
    {
        //dd($request);
        return view('adminViews.adm_dashboard');
    }

    /**
     * 
     */
    public function show_comp_users(Request $request)
    {
        $sel_query = "SELECT * from Comp_users inner join Company on Comp_users.c_user_comp = Company.comp_id;";
        error_log(json_encode($sel_query));
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['c_user_create_date']);
                $tempdate = date("M d Y", $time);
                // if(isset($res['coa_deactivate_time'])){
                //     $time = strtotime($res['coa_deactivate_time']);
                //     $deactdate = date("M d Y", $time);
                // }else{
                //     $deactdate = 'N/A';
                // }
                $compuList[] = array(
                    'comp_id' => $res['comp_id'],
                    'comp_name' => $res['comp_name'],
                    'c_user_name' => $res['c_user_name'],
                    'c_user_email' => $res['c_user_email'],
                    'c_user_sts' => ($res['c_user_sts'] == 1) ? 'Active' : 'InActive',
                    'c_user_pwd' => $res['c_user_pwd'],
                    'c_user_create_date' => $tempdate


                );
            }
        }
        return view('adminViews.adm_comp_user_list', compact(['compuList']));
    }

    /**
     * 
     */
    public function show_gsts()
    {
        $sel_query = "SELECT * from gst_collection";
        error_log(json_encode($sel_query));
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['gst_create_date']);
                $tempdate = date("M d Y", $time);
                // if(isset($res['coa_deactivate_time'])){
                //     $time = strtotime($res['coa_deactivate_time']);
                //     $deactdate = date("M d Y", $time);
                // }else{
                //     $deactdate = 'N/A';
                // }
                $gstList[] = array(
                    'gst_id' => $res['gst_id'],
                    'gst_val' => $res['gst_val'],
                    'gst_create_date' => $tempdate,
                );
            }
        }
        return view('adminViews.adm_gst_list', compact(['gstList']));
    }
    /**
     * 
     */
    public function show_chart_of_acc(Request $request)
    {
        $main_cates = GeneralUtils::get_Fs_main_Cates();
        $sub_cates = GeneralUtils::get_Fs_sub_Cates();

        return view('adminViews.adm_chartofacc', compact(['main_cates', 'sub_cates']));
    }

    /**
     * 
     */
    public function show_chart_of_acc_detail(Request $request, $coa_id)
    {
        $main_cates = GeneralUtils::get_Fs_main_Cates();
        $sub_cates = GeneralUtils::get_Fs_sub_Cates();
        $coa = DB::table('COA')->where('coa_id', $coa_id)->first();
        if (!$coa) {
            abort(404);
        } else {
            $coa = json_decode(json_encode($coa), true);
        }
        return view('adminViews.adm_load_chartofacc', compact(['main_cates', 'sub_cates', 'coa']));
    }

    /**
     * 
     */
    public function show_supp_cate(Request $request)
    {
        $supp_cate = GeneralUtils::get_supplier_Cates();
        return view('adminViews.adm_supplier_cate', compact(['supp_cate']));
    }

    /**
     * 
     */
    public function show_cust_cate(Request $request)
    {
        $cust_cate = GeneralUtils::get_cust_Cates();
        return view('adminViews.adm_cust_cate', compact(['cust_cate']));
    }

    /**
     * 
     */
    public function generate_supp_cate(Request $request)
    {
        request()->validate([
            'supplier_cate_value' => 'required|unique:supplier_cate,sup_cate_name'
        ]);
        $supplier_cate_value = $request->input('supplier_cate_value');
        DB::beginTransaction();
        DB::table('supplier_cate')->insert([
            'sup_cate_name' => $supplier_cate_value,
        ]);
        DB::commit();
        return \redirect('/admin/dashboard');
    }

    /**
     * 
     */
    public function generate_cust_cate(Request $request)
    {
        request()->validate([
            'cust_cate_value' => 'required|unique:cust_cate,cust_cate_name'
        ]);
        $cust_cate_value = $request->input('cust_cate_value');
        DB::beginTransaction();
        DB::table('cust_cate')->insert([
            'cust_cate_name' => $cust_cate_value,
        ]);
        DB::commit();
        return \redirect('/admin/dashboard');
    }

    /**
     * 
     */
    public function generate_coa(Request $request)
    {
        request()->validate([
            'acc_code' => 'required|unique:COA,coa_acc_code'
        ]);
        $createdate = date("Y-m-d H:i:s");
        $coa_uuid = uniqid("simp-coa-", true);
        $acc_code = $request->input('acc_code');
        $acc_name = $request->input('acc_name');
        $acc_desc = $request->input('acc_desc');
        $acc_nature = $request->input('acc_nature');
        $acc_beh = $request->input('acc_beh');
        $acc_fin_stmt = $request->input('acc_fin_stmt');
        $main_cate = $request->input('main_cate');
        $sub_cate = $request->input('sub_cate');
        $fixasset = $request->input('acc_chk_asset_val');
        // $acc_nature = $request->input('acc_nature');

        try {
            DB::beginTransaction();
            DB::table('COA')->insert([
                'coa_unique_code' => $coa_uuid,
                'coa_acc_code' => $acc_code,
                'coa_acc_name' => $acc_name,
                'coa_acc_desc' => $acc_desc,
                'coa_base_acc_nat' => $acc_nature,
                'coa_fix_asset' => $fixasset,
                'coa_data_entry_beh' => $acc_beh,
                'coa_fin_stat' => $acc_fin_stmt,
                'coa_fin_stat_main_cate' => $main_cate,
                'coa_fin_stat_sub_cate' => $sub_cate,
                'coa_act_sts' => 1,
                'coa_create_time' => $createdate,

            ]);

            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }

    /**
     * 
     */
    public function update_coa(Request $request)
    {
        //$createdate = date("Y-m-d H:i:s");
        // $coa_uuid = uniqid("simp-coa-", true);
        if (!GeneralUtils::check_COA_CODE_WITH_ID_exist($request->input('acc_code'), $request->input('coa_id'))) {
            if (GeneralUtils::check_COA_CODE_exist($request->input('acc_code'))) {
                return \Redirect::back()->withErrors(['error_reason' => 'COA Code Exist']);
            }
        }

        $acc_code = $request->input('acc_code');
        $acc_name = $request->input('acc_name');
        $acc_desc = $request->input('acc_desc');
        $acc_nature = $request->input('acc_nature');
        $acc_beh = $request->input('acc_beh');
        $acc_fin_stmt = $request->input('acc_fin_stmt');
        $main_cate = $request->input('main_cate');
        $sub_cate = $request->input('sub_cate');
        $fixasset = $request->input('acc_chk_asset_val');
        // $acc_nature = $request->input('acc_nature');
        $coa_id = $request->input('coa_id');
        try {
            DB::beginTransaction();
            DB::table('COA')->where('coa_id', $coa_id)->update([
                // 'coa_unique_code' => $coa_uuid,
                'coa_acc_code' => $acc_code,
                'coa_acc_name' => $acc_name,
                'coa_acc_desc' => $acc_desc,
                'coa_base_acc_nat' => $acc_nature,
                'coa_fix_asset' => $fixasset,
                'coa_data_entry_beh' => $acc_beh,
                'coa_fin_stat' => $acc_fin_stmt,
                'coa_fin_stat_main_cate' => $main_cate,
                'coa_fin_stat_sub_cate' => $sub_cate,
                // 'coa_act_sts' => 1,
                //'coa_create_time' => $createdate,

            ]);

            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/COA-list');
    }

    /**
     * 
     */
    public function show_create_company(Request $request)
    {
        return view('adminViews.adm_create_company');
    }

    /**
     * 
     */
    public function show_company_detail(Request $request, $comp_id)
    {

        $comp = DB::table('Company')->where('comp_id', $comp_id)->first();
        if (!$comp) {
            abort(404);
        } else {
            $comp = json_decode(json_encode($comp), true);
        }

        $comp['comp_legal_addr'] = json_decode($comp['comp_legal_addr'], true);
        $comp['comp_alt_addr'] = json_decode($comp['comp_alt_addr'], true);
        $comp['comp_contact_person'] = json_decode($comp['comp_contact_person'], true);
        $comp['comp_alt_contact_person'] = json_decode($comp['comp_alt_contact_person'], true);

        // dd($comp);
        return view('adminViews.adm_load_company', compact(['comp']));
    }

    /**
     * 
     */
    public function show_create_company_user(Request $request)
    {
        $companylist = GeneralUtils::getCompanyList();
        return view('adminViews.adm_create_company_user', compact(['companylist']));
    }

    /**
     * 
     */
    public function generate_comp_user(Request $request)
    {
        $createdate = date("Y-m-d H:i:s");
        $comp_id = $request->input('comp_id');
        $pname = $request->input('pname');
        $pemail = $request->input('pemail');
        $ppwd = $request->input('ppwd');

        $res = GeneralUtils::CreatePerson($pname, $pemail, $ppwd, $comp_id);
        $comp_obj = DB::table('Company')->where('comp_id', $comp_id)->first();

        $userlist = $comp_obj->comp_users;
        if (isset($userlist)) {
            $user_arr = explode(',', $userlist);
            array_push($user_arr, $res);
            $userlist = implode(',', $user_arr);
        } else {
            $userlist = $res;
        }
        DB::beginTransaction();
        DB::table('Company')->where('comp_id', $comp_id)->update([
            'comp_users' => $userlist
        ]);


        DB::commit();

        return \redirect('/admin/dashboard');
    }

    /**
     * 
     */
    public function show_gst_screen(Request $request)
    {
        $gst_terms = GeneralUtils::get_gst_collection();

        return view('adminViews.adm_gst', compact('gst_terms'));
    }

    /**
     * 
     */
    public function show_payterms_screen(Request $request)
    {
        $pay_terms = GeneralUtils::get_pay_Terms();
        // dd($pay_terms);
        return view('adminViews.adm_payment_terms', compact(['pay_terms']));
    }

    /**
     * 
     */
    public function show_xchange_screen(Request $request)
    {
        return view('adminViews.adm_xcurr');
    }

    /**
     * 
     */
    public function show_FA_main_cate_screen(Request $request)
    {
        $cate_names = GeneralUtils::get_category_Names();

        return view('adminViews.adm_fa_maincate', compact(['cate_names']));
    }

    /**
     * 
     */
    public function generate_xchange(Request $request)
    {
        $createdate = date("Y-m-d H:i:s");
        $cur_name_value = $request->input('cur_name_value');
        $cur_sym_value = $request->input('cur_sym_value');
        $cur_xchage_value = $request->input('cur_xchage_value');
        try {
            DB::beginTransaction();
            DB::table('Xcurrency')->insert([
                'xcurr_name' => $cur_name_value,
                'xcurr_sym' => $cur_sym_value,
                'xcurr_value' => $cur_xchage_value,
                'xcurr_create_date' => $createdate
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }

    /**
     * 
     */
    public function generate_Currency(Request $request)
    {
        $file = $request->file('file');
        $month = $request->input('cur_month_value');
        $year = $request->input('cur_yr_value');
        // File Details 


        //Check currency exist..begin
        $curr_arr = DB::table('Xcurr')->where(['xcurr_month' => $month, 'xcurr_year' => $year])->get(['xcurr_from', 'xcurr_to', 'xcurr_val']);
        if ($curr_arr) {
            //$deleted has num of rows deleted
            $deleted = DB::table('Xcurr')->where(['xcurr_month' => $month, 'xcurr_year' => $year])->delete();
            //dd($deleted);

        }
        //Check currency exist..end






        $filename = $file->getClientOriginalName();
        $extension = $file->getClientOriginalExtension();
        $tempPath = $file->getRealPath();
        $fileSize = $file->getSize();
        $mimeType = $file->getMimeType();

        $location = 'uploads';

        // Upload file
        $file->move('public/' . $location, $filename);

        // Import CSV to Database
        $filepath = public_path($location . "/" . $filename);

        // Reading file
        $file = fopen($filepath, "r");
        // dd($file);
        $importData_arr = array();

        $i = 0;
        $j = 0;
        $k = 0;

        $firstrow = null;
        $rows = array();
        while (($filedata = fgetcsv($file, $delimiter = ',')) !== FALSE) {
            $num = count($filedata);
            error_log(json_encode($filedata));
            //  dd($num);

            // Skip first row (Remove below comment if you want to skip the first row)
            if ($i == 0) {
                $firstrow = $filedata;
            } else {
                $rows[] = $filedata;
            }
            //  for($i = 1;$i < 5 ;$i++){
            //      for($j = 1;$j<5;$j++){

            //             //$importData_arr[$i][$j] = $filedata [$i];

            //      }
            //  }
            $i++;
            //  for ($c=0; $c < $num; $c++) {
            //     $importData_arr[$i][] = $filedata [$c];
            //  }
            //  $i++;
        }
        fclose($file);
        $numrows = $i;
        $numcols = count($firstrow);
        $resarr = array();
        //   dd($rows);
        for ($i = 0; $i < $numrows - 1; $i++) {
            for ($j = 1; $j < $numcols; $j++) {

                $resarr[] = array('T' => $firstrow[$j], 'F' => $rows[$i][0], 'val' => $rows[$i][$j]);
                //$importData_arr[$i][$j] = $filedata [$i];
                try {
                    DB::beginTransaction();
                    DB::table('Xcurr')->insert([
                        'xcurr_from' =>  $rows[$i][0],
                        'xcurr_to' => $firstrow[$j],
                        'xcurr_val' => $rows[$i][$j],
                        'xcurr_month' => $month,
                        'xcurr_year' => $year
                    ]);
                    DB::commit();
                } catch (\Exception $ex) {
                    dd($ex);
                }
            }
        }
        // dd($rows);
        // dd($resarr);

        // dd($importData_arr);

        return \redirect('/admin/dashboard');
    }
    /**
     * 
     */
    public function generate_FA_main_cate(Request $request)
    {
        $createdate = date("Y-m-d H:i:s");
        $fa_cate_name = $request->input('fac_cate_value');
        if (GeneralUtils::check_fix_asset_cate_name_already_exists($request->input('fac_cate_value'))) {
            return \Redirect::back()->withErrors(['error_reason' => 'Asset Category Name Already Exist']);
        }

        try {
            DB::beginTransaction();
            DB::table('FA_main_cate')->insert([
                'fa_cate_name' => $fa_cate_name,
                'fa_create_date' => $createdate
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }
    /**
     * 
     */
    public function show_FA_sub_cate_screen(Request $request)
    {
        $FA_list = GeneralUtils::get_FA_Cates();
        return view('adminViews.adm_fa_subcate', compact(['FA_list']));
    }
    /**
     * 
     */
    public function generate_FA_sub_cate(Request $request)
    {
        $createdate = date("Y-m-d H:i:s");
        $fa_sub_cate_name = $request->input('fac_sub_cate_value');
        $fa_cate_id = $request->input('fa_cate_id');
        $fa_unique_code = $request->input('fac_sub_asset_code');;
        try {
            DB::beginTransaction();
            DB::table('FA_sub_cate')->insert([
                'fa_sub_cate_name' => $fa_sub_cate_name,
                'fa_cat_id' => $fa_cate_id,
                'fa_unique_code' => $fa_unique_code,
                'fa_sub_cate_create_date' => $createdate
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }
    /**
     * 
     */
    public function show_FA_useful_life_screen(Request $request)
    {
        $useful_list = GeneralUtils::get_useful_lifes();

        return view('adminViews.adm_fa_useful_life', compact('useful_list'));
    }
    /**
     * 
     */
    public function generate_FA_useful_life(Request $request)
    {
        $createdate = date("Y-m-d H:i:s");
        $fa_cate_name = $request->input('useful_life_value');
        try {
            DB::beginTransaction();
            DB::table('FA_useful_life')->insert([
                'fa_u_life_name' => $fa_cate_name,
                'fa_u_life_create_date' => $createdate
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }
    /**
     * 
     */
    public function generate_gst(Request $request)
    {
        $createdate = date("Y-m-d H:i:s");
        $gst_value = $request->input('gst_value');
        if(!str_contains($gst_value,"%")){
            $gst_value = $gst_value . "%";
        }
        if (GeneralUtils::check_gst_exist($gst_value)) {
            return \Redirect::back()->withErrors(['error_reason' => 'GST Already Exist']);
        }
        try {
            DB::beginTransaction();
            DB::table('gst_collection')->insert([
                'gst_val' => $gst_value,
                'gst_create_date' => $createdate
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/gst-list');
    }
    /** 
     * 
     */
    public function generate_pay_terms(Request $request)
    {
        $createdate = date("Y-m-d H:i:s");
        $pt_value = $request->input('pt_value');
        if (GeneralUtils::check_payment_terms_exist($request->input('pt_value'))) {
            return \Redirect::back()->withErrors(['error_reason' => 'Payment Already Exist']);
        }
        try {
            DB::beginTransaction();
            DB::table('Payment_terms')->insert([
                'pt_value' => $pt_value,
                'pt_create_date' => $createdate
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }
    /**
     * 
     */
    public function generate_company(Request $request)
    {
        $createdate = date("Y-m-d H:i:s");
        //$coa_uuid = uniqid("simp-coa-", true);
        $comp_name = $request->input('comp_name');
        $comp_reg_number = $request->input('comp_reg_number');
        $comp_gst_number = $request->input('comp_gst_number');
        $comp_incorp_date = $request->input('comp_incorp_date');
        $comp_entity_type = $request->input('comp_entity_type');
        $comp_phone_1 = $request->input('comp_phone_1');
        $comp_phone_2 = $request->input('comp_phone_2');
        $comp_mobile_1 = $request->input('comp_mobile_1');
        $comp_mobile_2 = $request->input('comp_mobile_2');
        $comp_inv_prefix = $request->input('comp_inv_prefix');
        $comp_inv_number = $request->input('comp_inv_number');
        $comp_email = $request->input('comp_email');
        $comp_fax = $request->input('comp_fax');
        $comp_inv_year = $request->input('comp_inv_year');

        $user_data = $request->input('user_data');
        // $acc_nature = $request->input('acc_nature');
        $legalAddr = array('line_1' => $request->input('leg_addr_line_1'), 'line_2' => $request->input('leg_addr_line_2'), 'state' => $request->input('leg_addr_state'), 'city' => $request->input('leg_addr_city'), 'postal' => $request->input('leg_addr_postal'), 'country' => $request->input('leg_addr_country'));
        $altAddr = array('line_1' => $request->input('alt_addr_line_1'), 'line_2' => $request->input('alt_addr_line_2'), 'state' => $request->input('alt_addr_state'), 'city' => $request->input('alt_addr_city'), 'postal' => $request->input('alt_addr_postal'), 'country' => $request->input('leg_addr_country'));
        $poc = array('name' => $request->input('comp_poc_name'), 'phone' => $request->input('comp_poc_phone'), 'mobile' => $request->input('comp_poc_mobile'), 'email' => $request->input('comp_poc_email'));
        $altpoc = array('name' => $request->input('comp_alt_poc_name'), 'phone' => $request->input('comp_alt_poc_phone'), 'mobile' => $request->input('comp_alt_poc_mobile'), 'email' => $request->input('comp_alt_poc_email'));

        if (GeneralUtils::checkcompanyname($comp_name)) {
            $res['error'] = "Creating a Problem";
            return \Redirect::back()->withErrors(['error_reason' => 'Company Name already exist']);
        }
        if (GeneralUtils::checkcompanyregistration($comp_reg_number)) {
            $res['error'] = "Creating a Problem";
            return \Redirect::back()->withErrors(['error_reason' => 'Registration Number already exist']);
        }
        if (GeneralUtils::checkcompanygst($comp_gst_number)) {
            $res['error'] = "Creating a Problem";
            return \Redirect::back()->withErrors(['error_reason' => 'Vat/Gst already exist']);
        }
        try {
            DB::beginTransaction();
            DB::table('Company')->insert([
                'comp_name' => $comp_name,
                'comp_reg_number' => $comp_reg_number,
                'comp_gst_number' => $comp_gst_number,
                'comp_incorp_date' => $comp_incorp_date,
                'comp_entity_type' => $comp_entity_type,
                'comp_phone_1' => $comp_phone_1,
                'comp_phone_2' => $comp_phone_2,
                'comp_mobile_1' => $comp_mobile_1,
                'comp_mobile_2' => $comp_mobile_2,
                'comp_inv_prefix' => $comp_inv_prefix,
                'comp_inv_number' => $comp_inv_number,
                'comp_sts' => 1,
                'comp_create_date' => $createdate,
                'comp_legal_addr' => json_encode($legalAddr),
                'comp_alt_addr' => json_encode($altAddr),
                'comp_contact_person' => json_encode($poc),
                'comp_alt_contact_person' => json_encode($altpoc),
                'comp_users' => '',
                'comp_email' => $comp_email,
                'comp_fax' => $comp_fax,
                'comp_inv_year' => $comp_inv_year,
            ]);
            $comp_id = DB::getPdo()->lastInsertId();
            //crate users
            //$userlist = GeneralUtils::CreatePersons($user_data,$comp_id);
            // error_log('------>>>'.$userlist);

            // DB::table('Company')->where('comp_id', $comp_id)->update([
            //     'comp_contact_person' => $userlist
            // ]);


            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }


        return \redirect('/admin/company-list');
    }

    /**
     * 
     */
    public function show_XchangeCurr_list(Request $request)
    {
        // $currList = DB::table('Xcurrency')->get();
        // $currList = json_decode(json_encode($currList), true);
        // // dd($currList);
        // $reshtml = GeneralUtils::generateCurrencyTbl();
        // return view('adminViews.adm_xcurr_list',compact(['currList','reshtml']));
        $months = DB::table('Xcurr')->distinct('xcurr_month')->pluck('xcurr_month');
        $months = json_decode(json_encode($months), true);
        $years = DB::table('Xcurr')->distinct('xcurr_year')->pluck('xcurr_year');
        $years = json_decode(json_encode($years), true);
        return view('adminViews.adm_xcurr_list', compact(['years', 'months']));
    }


    /**
     * 
     */
    public function update_company(Request $request)
    {
        $comp_id = $request->input('comp_id');
        //$coa_uuid = uniqid("simp-coa-", true);
        $comp_name = $request->input('comp_name');
        $comp_reg_number = $request->input('comp_reg_number');
        $comp_gst_number = $request->input('comp_gst_number');
        $comp_incorp_date = $request->input('comp_incorp_date');
        $comp_entity_type = $request->input('comp_entity_type');
        $comp_phone_1 = $request->input('comp_phone_1');
        $comp_phone_2 = $request->input('comp_phone_2');
        $comp_mobile_1 = $request->input('comp_mobile_1');
        $comp_mobile_2 = $request->input('comp_mobile_2');
        $comp_inv_prefix = $request->input('comp_inv_prefix');
        $comp_inv_number = $request->input('comp_inv_number');
        $comp_email = $request->input('comp_email');
        $comp_fax = $request->input('comp_fax');
        $comp_inv_year = $request->input('comp_inv_year');

        // $user_data = $request->input('user_data');
        // $acc_nature = $request->input('acc_nature');
        $legalAddr = array('line_1' => $request->input('leg_addr_line_1'), 'line_2' => $request->input('leg_addr_line_2'), 'state' => $request->input('leg_addr_state'), 'city' => $request->input('leg_addr_city'), 'postal' => $request->input('leg_addr_postal'), 'country' => $request->input('leg_addr_country'));
        $altAddr = array('line_1' => $request->input('alt_addr_line_1'), 'line_2' => $request->input('alt_addr_line_2'), 'state' => $request->input('alt_addr_state'), 'city' => $request->input('alt_addr_city'), 'postal' => $request->input('alt_addr_postal'), 'country' => $request->input('leg_addr_country'));
        $poc = array('name' => $request->input('comp_poc_name'), 'phone' => $request->input('comp_poc_phone'), 'mobile' => $request->input('comp_poc_mobile'), 'email' => $request->input('comp_poc_email'));
        $altpoc = array('name' => $request->input('comp_alt_poc_name'), 'phone' => $request->input('comp_alt_poc_phone'), 'mobile' => $request->input('comp_alt_poc_mobile'), 'email' => $request->input('comp_alt_poc_email'));

        if (!GeneralUtils::check_company_name_ID($request->input('comp_name'), $request->input('comp_id'))) {
            if (GeneralUtils::check_company_name($request->input('comp_name'))) {
                return \Redirect::back()->withErrors(['error_reason' => 'Entity Name Exist']);
            }
        }
        if (!GeneralUtils::check_register_number_exist_ID($request->input('comp_reg_number'), $request->input('comp_id'))) {
            if (GeneralUtils::check_register_number_exist($request->input('comp_reg_number'))) {
                return \Redirect::back()->withErrors(['error_reason' => 'Business Registration Number Exist']);
            }
        }
        if (!GeneralUtils::check_vat_exist_ID($request->input('comp_gst_number'), $request->input('comp_id'))) {
            if (GeneralUtils::check_vat_exist($request->input('comp_gst_number'))) {
                return \Redirect::back()->withErrors(['error_reason' => 'Gst/Vat does not Exist']);
            }
        }
        try {
            DB::beginTransaction();
            DB::table('Company')->where('comp_id', $comp_id)->update([
                'comp_name' => $comp_name,
                'comp_reg_number' => $comp_reg_number,
                'comp_gst_number' => $comp_gst_number,
                'comp_incorp_date' => $comp_incorp_date,
                'comp_entity_type' => $comp_entity_type,
                'comp_phone_1' => $comp_phone_1,
                'comp_phone_2' => $comp_phone_2,
                'comp_mobile_1' => $comp_mobile_1,
                'comp_mobile_2' => $comp_mobile_2,
                'comp_inv_prefix' => $comp_inv_prefix,
                'comp_inv_number' => $comp_inv_number,
                // 'comp_sts' => 1,
                //'comp_create_date' => $createdate,
                'comp_legal_addr' => json_encode($legalAddr),
                'comp_alt_addr' => json_encode($altAddr),
                'comp_contact_person' => json_encode($poc),
                'comp_alt_contact_person' => json_encode($altpoc),
                //'comp_users' =>'',
                'comp_email' => $comp_email,
                'comp_fax' => $comp_fax,
                'comp_inv_year' => $comp_inv_year,
            ]);

            //crate users
            //$userlist = GeneralUtils::CreatePersons($user_data,$comp_id);
            // error_log('------>>>'.$userlist);

            // DB::table('Company')->where('comp_id', $comp_id)->update([
            //     'comp_contact_person' => $userlist
            // ]);


            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }


        return \redirect('/admin/company-list');
    }

    /**
     * 
     */
    public function show_assign_COA(Request $request)
    {
        $sel_query = "SELECT * from COA inner join FS_main_cate on COA.coa_fin_stat_main_cate = FS_main_cate.cate_id inner join FS_sub_cate on COA.coa_fin_stat_sub_cate = FS_sub_cate.sub_cate_id";
        error_log(json_encode($sel_query));
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['coa_create_time']);
                $tempdate = date("M d Y", $time);
                if (isset($res['coa_deactivate_time'])) {
                    $time = strtotime($res['coa_deactivate_time']);
                    $deactdate = date("M d Y", $time);
                } else {
                    $deactdate = 'N/A';
                }
                $coaList[] = array(
                    'coa_id' => $res['coa_id'],
                    'coa_unique_code' => $res['coa_unique_code'],
                    'coa_acc_code' => $res['coa_acc_code'],
                    'coa_acc_name' => $res['coa_acc_name'],
                    'coa_acc_desc' => $res['coa_acc_desc'],
                    'coa_base_acc_nat' => $res['coa_base_acc_nat'],
                    'coa_fix_asset' => ($res['coa_fix_asset'] == 1) ? 'YES' : 'NO',
                    'coa_data_entry_beh' => $res['coa_data_entry_beh'],
                    'coa_fin_stat' => $res['coa_fin_stat'],
                    'coa_fin_stat_main_cate' => $res['cate_name'],
                    'coa_fin_stat_sub_cate' => $res['sub_cate_name'],
                    'coa_act_sts' => ($res['coa_act_sts'] == 1) ? 'Active' : 'InActive',
                    'coa_create_time' => $tempdate,
                    'coa_deactivate_time' => $deactdate

                );
            }
        }
        $companylist = GeneralUtils::getCompanyList();
        return view('adminViews.adm_assign_COA', compact(['coaList', 'companylist']));
    }

    /**
     * 
     */
    public function show_account_setup(Request $request)
    {
        $companylist = GeneralUtils::getCompanyList();
        $gsts  = DB::table('gst_collection')->get();
        $gsts = json_decode(json_encode($gsts), true);
        return view('adminViews.adm_comp_acc_setup', compact(['companylist','gsts']));
    }

    /**
     * 
     */
    public function adm_account_setup_create(Request $request)
    {
        // dd($request);
        $comp_id = $request->input('comp_id');

        $comp_bank_name = $request->input('comp_bank_name');
        $comp_bank_code = $request->input('comp_bank_code');
        $comp_bank_branch_name = $request->input('comp_bank_branch_name');
        $comp_bank_branch_code = $request->input('comp_bank_branch_code');
        $comp_bank_swift_code = $request->input('comp_bank_swift_code');
        $comp_bank_intermed = $request->input('comp_bank_intermed');
        $comp_bank_acc_type = $request->input('comp_bank_acc_type');
        $comp_bank_acc_number = $request->input('comp_bank_acc_number');
        $check_cust = $request->input('acc_chk_asset_vals');
        // dd($check_cust);

        //Supplier Bank Information//
        $start_period = $request->input('start_period');
        $end_period = $request->input('end_period');
        $act_fin_yr = $request->input('act_fin_yr');
        $comp_curr = $request->input('comp_curr');

        $comp_dateformat = $request->input('comp_dateformat');
        $finan = $request->input('category1');
        $finann = implode(",", $finan);
        // $finann = json_encode($finan);
        $gsts = $request->input('category');
        $company_selctor = $request->input('company_selctor');
        $gstss = implode(",", $gsts);

        try {
            $bank_info2 = array('bnk_name'=>$request->input('comp_bank2_name'),'bnk_code'=>$request->input('comp_bank2_code'),'brnch_name'=>$request->input('comp_bank2_branch_name'),'brnch_code'=>$request->input('comp_bank2_branch_code'),'swiftcode'=>$request->input('comp_bank2_swift_code'),'intermdiate'=>$request->input('comp_bank2_intermed'),'acctype'=>$request->input('comp_bank2_acc_type'),'accnumber'=>$request->input('comp_bank2_acc_number'));

            // dd($bank_info2);
            $bank_info3 = array('b_name'=>$request->input('comp_bank3_name'),'b_code'=>$request->input('comp_bank3_code'),'branch_name'=>$request->input('comp_bank3_branch_name'),'branch_code'=>$request->input('comp_bank3_branch_code'),'swift_Code'=>$request->input('comp_bank3_swift_code'),'inter'=>$request->input('comp_bank3_intermed'),'ac_type'=>$request->input('comp_bank3_acc_type'),'ac_number'=>$request->input('comp_bank3_acc_number'));
            // dd($bank_info3);
            // DB::beginTransaction();
            // if(GeneralUtils::check_Comp_COA_exist($comp_id)){
            //     DB::table('Company_COAs')->where('comp_id',$comp_id)->update([
            //         'comp_coa'=> $coa_vals
            //     ]);
            // }else{
            // $time = strtotime($request['comp_dateformat']);
            // $tempdate = date("M d Y", $time);
            DB::table('account_setup')->insert([

                'ac_company' => $comp_id,
                'ac_bank_name' => $comp_bank_name,
                'ac_bank_code' => $comp_bank_code,

                'ac_branch_name' => $comp_bank_branch_name,
                'ac_branch_code' => $comp_bank_branch_code,
                'ac_swift_code' => $comp_bank_swift_code,
                'ac_inter_bank' => $comp_bank_intermed,
                'ac_acc_type' => $comp_bank_acc_type,
                'ac_acc_number' => $comp_bank_acc_number,
                'ac_multi_support' => $check_cust,
                'ac_strt_period' => $start_period,
                'ac_end_period' => $end_period,
                'ac_financial' => $act_fin_yr,
                'ac_com_currency' => $comp_curr,
                'ac_select_format' => $comp_dateformat,
                'ac_financial_month' => $finann,
                'ac_gst' => $gstss,
                'bank_name_2' => json_encode($bank_info2),
                'bank_name_3' => json_encode($bank_info3),
                'ac_bank_type'=>$company_selctor,
            ]);
            // }
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('admin/accounting-setup');
    }
    /**
     * 
     */
    public function adm_account_setup_list(Request $request)
    {
        $acc_list = DB::table('account_setup')->get();
        $acc_setup_list = json_decode(json_encode($acc_list), true);
        return view('adminViews.adm_acc_com_setup_list', compact(['acc_setup_list']));
    }
    /**
     * 
     */

    public function adm_account_setup_detail(Request $request, $id)
    {
        $acc_detail = DB::table('account_setup')->where('ac_id', $id)->get();
        $companylist = GeneralUtils::getCompanyList();
        $payment_terms = DB::table('Payment_terms')->get();
        $payment_terms = json_decode(json_encode($payment_terms), true);

        return view('adminViews.adm_acc_com_setup_detail', compact(['acc_detail', 'companylist', 'payment_terms']));
    }
    /**
     * 
     */
    public function adm_account_setup_update(Request $request, $id)
    {
        // dd($request);
        $comp_id = $request->input('comp_id');

        $comp_bank_name = $request->input('comp_bank_name');
        $comp_bank_code = $request->input('comp_bank_code');
        $comp_bank_branch_name = $request->input('comp_bank_branch_name');
        $comp_bank_branch_code = $request->input('comp_bank_branch_code');
        $comp_bank_swift_code = $request->input('comp_bank_swift_code');
        $comp_bank_intermed = $request->input('comp_bank_intermed');
        $comp_bank_acc_type = $request->input('comp_bank_acc_type');
        $comp_bank_acc_number = $request->input('comp_bank_acc_number');
        $check_cust = $request->input('acc_chk_asset_vals');
        // dd($check_cust);

        //Supplier Bank Information//
        $start_period = $request->input('start_period');
        $end_period = $request->input('end_period');
        $act_fin_yr = $request->input('act_fin_yr');
        $comp_curr = $request->input('comp_curr');

        $comp_dateformat = $request->input('comp_dateformat');
        $finan = $request->input('category1');
        $finann = implode(",", $finan);

        // $finann = json_encode($finan);
        $gsts = $request->input('category');
        $gstss = implode(",", $gsts);

        try {
            // DB::beginTransaction();
            // if(GeneralUtils::check_Comp_COA_exist($comp_id)){
            //     DB::table('Company_COAs')->where('comp_id',$comp_id)->update([
            //         'comp_coa'=> $coa_vals
            //     ]);
            // }else{
            //    $time = strtotime($request['comp_dateformat']);
            //    $tempdate = date("M d Y", $time);
            DB::table('account_setup')->where('ac_id', $id)->update([

                'ac_company' => $comp_id,
                'ac_bank_name' => $comp_bank_name,
                'ac_bank_code' => $comp_bank_code,

                'ac_branch_name' => $comp_bank_branch_name,
                'ac_branch_code' => $comp_bank_branch_code,
                'ac_swift_code' => $comp_bank_swift_code,
                'ac_inter_bank' => $comp_bank_intermed,
                'ac_acc_type' => $comp_bank_acc_type,
                'ac_acc_number' => $comp_bank_acc_number,
                'ac_multi_support' => $check_cust,
                'ac_strt_period' => $start_period,
                'ac_end_period' => $end_period,
                'ac_financial' => $act_fin_yr,
                'ac_com_currency' => $comp_curr,
                'ac_select_format' => $comp_dateformat,
                'ac_financial_month' => $finann,
                'ac_gst' => $gstss,
            ]);
            // }
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('admin/accounting-setup');
    }
    /**
     * 
     */
    public function show_account_pay_setup(Request $request)
    {
        $companylist = GeneralUtils::getCompanyList();
        $payment_terms = DB::table('Payment_terms')->get();
        $payment_terms = json_decode(json_encode($payment_terms), true);
        $currency = GeneralUtils::getDistinctCurr();
        $supplier_cates = GeneralUtils::get_supplier_Cates();
        $gsts = GeneralUtils::get_gst_list();
        return view('adminViews.adm_comp_acc_payable', compact(['companylist', 'payment_terms', 'currency', 'supplier_cates', 'gsts']));
    }

    /**
     * 
     */
    public function show_account_rece_setup(Request $request)
    {
        $companylist = GeneralUtils::getCompanyList();
        $payment_terms = DB::table('Payment_terms')->get();
        $payment_terms = json_decode(json_encode($payment_terms), true);
        $currency = GeneralUtils::getDistinctCurr();
        $cust_cates = GeneralUtils::get_cust_Cates();
        $gsts = GeneralUtils::get_gst_list();
        return view('adminViews.adm_comp_acc_receivable', compact(['companylist', 'payment_terms', 'currency', 'cust_cates', 'gsts']));
    }
    /**
     * 
     */
    public function show_companylist(Request $request)
    {
        $sel_query = "SELECT * from Company;";
        error_log(json_encode($sel_query));
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['comp_create_date']);
                $tempdate = date("M d Y", $time);
                // if(isset($res['coa_deactivate_time'])){
                //     $time = strtotime($res['coa_deactivate_time']);
                //     $deactdate = date("M d Y", $time);
                // }else{
                //     $deactdate = 'N/A';
                // }
                $compList[] = array(
                    'comp_id' => $res['comp_id'],
                    'comp_name' => $res['comp_name'],
                    'comp_reg_number' => $res['comp_reg_number'],
                    'comp_gst_number' => $res['comp_gst_number'],
                    'comp_incorp_date' => $res['comp_incorp_date'],
                    'comp_entity_type' => $res['comp_entity_type'],
                    'comp_sts' => ($res['comp_sts'] == 1) ? 'Active' : 'InActive',

                );
            }
        }
        return view('adminViews.adm_company_list', compact(['compList']));
    }

    /**
     * 
     */
    public function show_chart_of_acc_list(Request $request)
    {
        $sel_query = "SELECT * from COA inner join FS_main_cate on COA.coa_fin_stat_main_cate = FS_main_cate.cate_id inner join FS_sub_cate on COA.coa_fin_stat_sub_cate = FS_sub_cate.sub_cate_id";
        error_log(json_encode($sel_query));
        $res_query = DBraw::select($sel_query);
        $res_query = json_decode(json_encode($res_query), true);

        if (count($res_query)) {
            foreach ($res_query as $res) {
                $time = strtotime($res['coa_create_time']);
                $tempdate = date("M d Y", $time);
                if (isset($res['coa_deactivate_time'])) {
                    $time = strtotime($res['coa_deactivate_time']);
                    $deactdate = date("M d Y", $time);
                } else {
                    $deactdate = 'N/A';
                }
                $coaList[] = array(
                    'coa_id' => $res['coa_id'],
                    'coa_unique_code' => $res['coa_unique_code'],
                    'coa_acc_code' => $res['coa_acc_code'],
                    'coa_acc_name' => $res['coa_acc_name'],
                    'coa_acc_desc' => $res['coa_acc_desc'],
                    'coa_base_acc_nat' => $res['coa_base_acc_nat'],
                    'coa_fix_asset' => ($res['coa_fix_asset'] == 1) ? 'YES' : 'NO',
                    'coa_data_entry_beh' => $res['coa_data_entry_beh'],
                    'coa_fin_stat' => $res['coa_fin_stat'],
                    'coa_fin_stat_main_cate' => $res['cate_name'],
                    'coa_fin_stat_sub_cate' => $res['sub_cate_name'],
                    'coa_act_sts' => ($res['coa_act_sts'] == 1) ? 'Active' : 'InActive',
                    'coa_create_time' => $tempdate,
                    'coa_deactivate_time' => $deactdate

                );
            }
        }
        return view('adminViews.adm_chartofacc_list', compact(['coaList']));
    }

    /**
     * 
     */
    public function assign_comp_COA(Request $request)
    {
        $comp_id = $request->input('comp_id');
        $coa_vals = $request->input('coa_vals');
        try {
            DB::beginTransaction();
            if (GeneralUtils::check_Comp_COA_exist($comp_id)) {
                DB::table('Company_COAs')->where('comp_id', $comp_id)->update([
                    'comp_coa' => $coa_vals
                ]);
            } else {
                DB::table('Company_COAs')->insert([
                    'comp_id' => $comp_id,
                    'comp_coa' => $coa_vals
                ]);
            }
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }

    /**
     * 
     */
    public function deactivateCOA(Request $request, $id)
    {
        try {
            $createdate = date("Y-m-d H:i:s");
            DB::beginTransaction();
            DB::table('COA')->where('coa_id', $id)->update([
                'coa_act_sts' => 0,
                'coa_deactivate_time' => $createdate
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/COA-list');
    }

    /**
     * 
     */
    public function activateCOA(Request $request, $id)
    {
        try {
            // $createdate = date("Y-m-d H:i:s");
            DB::beginTransaction();
            DB::table('COA')->where('coa_id', $id)->update([
                'coa_act_sts' => 1,
                'coa_deactivate_time' => null
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/COA-list');
    }

    /**
     * 
     */
    public function deactivateCompany(Request $request, $id)
    {
        try {
            $createdate = date("Y-m-d H:i:s");
            DB::beginTransaction();
            DB::table('Company')->where('comp_id', $id)->update([
                'comp_sts' => 0
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/company-list');
    }

    /**
     * 
     */
    public function activateCompany(Request $request, $id)
    {
        try {
            // $createdate = date("Y-m-d H:i:s");
            DB::beginTransaction();
            DB::table('Company')->where('comp_id', $id)->update([
                'comp_sts' => 1
            ]);
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/company-list');
    }

    /**
     * 
     */
    public function adm_account_payable_create(Request $request)
    {
        $comp_id = $request->input('comp_id');

        $acc_supplier_name = $request->input('acc_supplier_name');
        $comp_gst = $request->input('comp_gst');
        $comp_curr = $request->input('comp_curr');
        $acc_pay_sup_name = $request->input('acc_pay_sup_name');
        $comp_cate = $request->input('comp_cate');
        $comp_pay_trms = $request->input('comp_pay_trms');
        $check_cust = $request->input('acc_chk_asset_vals');
        $notes = $request->input('notes');
        // dd($check_cust);

        //Supplier Bank Information//
        $comp_bank_name = $request->input('comp_bank_name');
        $comp_bank_code = $request->input('comp_bank_code');
        $comp_bank_branch_name = $request->input('comp_bank_branch_name');
        $comp_bank_branch_code = $request->input('comp_bank_branch_code');
        $comp_bank_swift_code = $request->input('comp_bank_swift_code');
        $comp_bank_intermed = $request->input('comp_bank_intermed');
        $comp_bank_acc_type = $request->input('comp_bank_acc_type');
        $comp_bank_acc_number = $request->input('comp_bank_acc_number');
        $currency = $request->input('acc_chk_asset_valss');

        //Supplier Bank Information//
        $supplier_bank_info = array(
            "b_name" => $comp_bank_name, "b_code" => $comp_bank_code, "branch_name" => $comp_bank_branch_name, "branch_code" => $comp_bank_branch_code,
            "swift_code" => $comp_bank_swift_code, "intermediary_bank" => $comp_bank_intermed, "acc_type" => $comp_bank_acc_type, "acc_number" => $comp_bank_acc_number,
            "multi_support" => $currency
        );
        $supplier_bank_info = json_encode($supplier_bank_info);

        //Supplier Contact Information//
        $comp_phone_1 = $request->input('comp_phone_1');
        $comp_phone_2 = $request->input('comp_phone_2');
        $comp_mobile_1 = $request->input('comp_mobile_1');
        $comp_mobile_2 = $request->input('comp_mobile_2');
        $comp_fax = $request->input('comp_fax');
        $comp_email = $request->input('comp_email');

        $supplier_contct_info = array(
            "phone_1" => $comp_phone_1, "phone_2" => $comp_phone_2, "mob_1" => $comp_mobile_1, "mob_2" => $comp_mobile_2,
            "fax" => $comp_fax, "email" => $comp_email
        );
        $supplier_contct_info = json_encode($supplier_contct_info);

        //Supplier Registered Address//
        $leg_addr_line_1 = $request->input('leg_addr_line_1');
        $leg_addr_line_2 = $request->input('leg_addr_line_2');
        $leg_addr_state = $request->input('leg_addr_state');
        $leg_addr_city = $request->input('leg_addr_city');
        $leg_addr_postal = $request->input('leg_addr_postal');
        $leg_addr_country = $request->input('leg_addr_country');

        $supplier_registr_addr = array(
            "addr_line1" => $leg_addr_line_1, "addr_line2" => $leg_addr_line_2, "state" => $leg_addr_state, "city" => $leg_addr_city,
            "postal" => $leg_addr_postal, "country" => $leg_addr_country
        );
        $supplier_registr_addr = json_encode($supplier_registr_addr);

        //Supplier Alternate Business Address//
        $alt_addr_line_1 = $request->input('alt_addr_line_1');
        $alt_addr_line_2 = $request->input('alt_addr_line_2');
        $alt_addr_state = $request->input('alt_addr_state');
        $alt_addr_city = $request->input('alt_addr_city');
        $alt_addr_postal = $request->input('alt_addr_postal');
        $alt_addr_country = $request->input('alt_addr_country');

        $supplier_alt_business_addr = array(
            "alt_addr_line1" => $alt_addr_line_1, "alt_addr_line2" => $alt_addr_line_2, "alt_state" => $alt_addr_state, "alt_city" => $alt_addr_city,
            "alt_postal" => $alt_addr_postal, "alt_country" => $alt_addr_country
        );
        $supplier_alt_business_addr = json_encode($supplier_alt_business_addr);

        //Point Of Contact//
        $comp_poc_name = $request->input('comp_poc_name');
        $comp_poc_phone = $request->input('comp_poc_phone');
        $comp_poc_mobile = $request->input('comp_poc_mobile');
        $comp_poc_email = $request->input('comp_poc_email');

        $contact_point = array("name" => $comp_poc_name, "phone" => $comp_poc_phone, "mobile" => $comp_poc_mobile, "email" => $comp_poc_email);
        $contact_point = json_encode($contact_point);

        //Alternate Point Of Contact//
        $comp_alt_poc_name = $request->input('comp_alt_poc_name');
        $comp_alt_poc_phone = $request->input('comp_alt_poc_phone');
        $comp_alt_poc_mobile = $request->input('comp_alt_poc_mobile');
        $comp_alt_poc_email = $request->input('comp_alt_poc_email');

        $alt_contact_point = array("alt_name" => $comp_alt_poc_name, "alt_phone" => $comp_alt_poc_phone, "alt_mobile" => $comp_alt_poc_mobile, "alt_email" => $comp_alt_poc_email);
        $alt_contact_point = json_encode($alt_contact_point);
        try {
            // DB::beginTransaction();
            // if(GeneralUtils::check_Comp_COA_exist($comp_id)){
            //     DB::table('Company_COAs')->where('comp_id',$comp_id)->update([
            //         'comp_coa'=> $coa_vals
            //     ]);
            // }else{
            DB::table('account_payable')->insert([
                'ap_company' => $comp_id,
                'ap_supplier_name' => $acc_supplier_name,
                'ap_currency' => $comp_curr,
                'ap_gst' => $comp_gst,
                'ap_membership_id' => $acc_pay_sup_name,
                'ap_supplier_categories' => $comp_cate,
                'ap_payment_terms' => $comp_pay_trms,
                'ap_corresponding_customer' => $check_cust,
                'ap_notes' => $notes,
                'ap_supplier_bank_info' => $supplier_bank_info,
                'ap_supplier_contact_info' => $supplier_contct_info,
                'ap_supplier_registered_address' => $supplier_registr_addr,
                'ap_supplier_alt_b_address' => $supplier_alt_business_addr,
                'ap_contact_point' => $contact_point,
                'ap_alt_contact_point' => $alt_contact_point,
            ]);
            // }
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }
    /**
     * 
     */

    public function adm_account_recieve_create(Request $request)
    {
        $comp_id = $request->input('comp_id');

        $acc_customer_name = $request->input('acc_customer_name');
        $comp_gst = $request->input('comp_gst');
        $comp_curr = $request->input('comp_curr');
        $acc_pay_sup_name = $request->input('acc_pay_sup_name');
        $comp_cate = $request->input('comp_cate');
        $comp_pay_trms = $request->input('comp_pay_trms');
        $check_cust = $request->input('acc_chk_asset_vals');
        $notes = $request->input('notes');
        // dd($check_cust);

        //Supplier Bank Information//
        $comp_bank_name = $request->input('comp_bank_name');
        $comp_bank_code = $request->input('comp_bank_code');
        $comp_bank_branch_name = $request->input('comp_bank_branch_name');
        $comp_bank_branch_code = $request->input('comp_bank_branch_code');
        $comp_bank_swift_code = $request->input('comp_bank_swift_code');
        $comp_bank_intermed = $request->input('comp_bank_intermed');
        $comp_bank_acc_type = $request->input('comp_bank_acc_type');
        $comp_bank_acc_number = $request->input('comp_bank_acc_number');
        $currency = $request->input('acc_chk_asset_valss');

        //Supplier Bank Information//
        $supplier_bank_info = array(
            "b_name" => $comp_bank_name, "b_code" => $comp_bank_code, "branch_name" => $comp_bank_branch_name, "branch_code" => $comp_bank_branch_code,
            "swift_code" => $comp_bank_swift_code, "intermediary_bank" => $comp_bank_intermed, "acc_type" => $comp_bank_acc_type, "acc_number" => $comp_bank_acc_number,
            "multi_support" => $currency
        );
        $supplier_bank_info = json_encode($supplier_bank_info);

        //Supplier Contact Information//
        $comp_phone_1 = $request->input('comp_phone_1');
        $comp_phone_2 = $request->input('comp_phone_2');
        $comp_mobile_1 = $request->input('comp_mobile_1');
        $comp_mobile_2 = $request->input('comp_mobile_2');
        $comp_fax = $request->input('comp_fax');
        $comp_email = $request->input('comp_email');

        $supplier_contct_info = array(
            "phone_1" => $comp_phone_1, "phone_2" => $comp_phone_2, "mob_1" => $comp_mobile_1, "mob_2" => $comp_mobile_2,
            "fax" => $comp_fax, "email" => $comp_email
        );
        $supplier_contct_info = json_encode($supplier_contct_info);

        //Supplier Registered Address//
        $leg_addr_line_1 = $request->input('leg_addr_line_1');
        $leg_addr_line_2 = $request->input('leg_addr_line_2');
        $leg_addr_state = $request->input('leg_addr_state');
        $leg_addr_city = $request->input('leg_addr_city');
        $leg_addr_postal = $request->input('leg_addr_postal');
        $leg_addr_country = $request->input('leg_addr_country');

        $supplier_registr_addr = array(
            "addr_line1" => $leg_addr_line_1, "addr_line2" => $leg_addr_line_2, "state" => $leg_addr_state, "city" => $leg_addr_city,
            "postal" => $leg_addr_postal, "country" => $leg_addr_country
        );
        $supplier_registr_addr = json_encode($supplier_registr_addr);

        //Supplier Alternate Business Address//
        $alt_addr_line_1 = $request->input('alt_addr_line_1');
        $alt_addr_line_2 = $request->input('alt_addr_line_2');
        $alt_addr_state = $request->input('alt_addr_state');
        $alt_addr_city = $request->input('alt_addr_city');
        $alt_addr_postal = $request->input('alt_addr_postal');
        $alt_addr_country = $request->input('alt_addr_country');

        $supplier_alt_business_addr = array(
            "alt_addr_line1" => $alt_addr_line_1, "alt_addr_line2" => $alt_addr_line_2, "alt_state" => $alt_addr_state, "alt_city" => $alt_addr_city,
            "alt_postal" => $alt_addr_postal, "alt_country" => $alt_addr_country
        );
        $supplier_alt_business_addr = json_encode($supplier_alt_business_addr);

        //Point Of Contact//
        $comp_poc_name = $request->input('comp_poc_name');
        $comp_poc_phone = $request->input('comp_poc_phone');
        $comp_poc_mobile = $request->input('comp_poc_mobile');
        $comp_poc_email = $request->input('comp_poc_email');

        $contact_point = array("name" => $comp_poc_name, "phone" => $comp_poc_phone, "mobile" => $comp_poc_mobile, "email" => $comp_poc_email);
        $contact_point = json_encode($contact_point);

        //Alternate Point Of Contact//
        $comp_alt_poc_name = $request->input('comp_alt_poc_name');
        $comp_alt_poc_phone = $request->input('comp_alt_poc_phone');
        $comp_alt_poc_mobile = $request->input('comp_alt_poc_mobile');
        $comp_alt_poc_email = $request->input('comp_alt_poc_email');

        $alt_contact_point = array("alt_name" => $comp_alt_poc_name, "alt_phone" => $comp_alt_poc_phone, "alt_mobile" => $comp_alt_poc_mobile, "alt_email" => $comp_alt_poc_email);
        $alt_contact_point = json_encode($alt_contact_point);
        try {
            // DB::beginTransaction();
            // if(GeneralUtils::check_Comp_COA_exist($comp_id)){
            //     DB::table('Company_COAs')->where('comp_id',$comp_id)->update([
            //         'comp_coa'=> $coa_vals
            //     ]);
            // }else{
            DB::table('account_recieve')->insert([
                'acc_company' => $comp_id,
                'acc_customer_name' => $acc_customer_name,
                'acc_currency' => $comp_curr,
                'acc_gst' => $comp_gst,
                'acc_membership_id' => $acc_pay_sup_name,
                'acc_customer_categories' => $comp_cate,
                'acc_payment_terms' => $comp_pay_trms,
                'acc_corresponding_supplier' => $check_cust,
                'acc_notes' => $notes,
                'acc_customer_bank_info' => $supplier_bank_info,
                'acc_customer_contact_info' => $supplier_contct_info,
                'acc_customer_registered_address' => $supplier_registr_addr,
                'acc_customer_alt_b_address' => $supplier_alt_business_addr,
                'acc_contact_point' => $contact_point,
                'acc_alt_contact_point' => $alt_contact_point,
            ]);
            // }
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }


    /**
     * 
     */
    public function adm_account_recieve_detail(Request $request, $id)
    {
        $acc_detail = DB::table('account_recieve')->where('acc_id', $id)->get();
        $data = json_decode($acc_detail[0]->acc_customer_bank_info);
        $contact = json_decode($acc_detail[0]->acc_customer_contact_info);
        $supplier_regstr = json_decode($acc_detail[0]->acc_customer_registered_address);
        // dd($supplier_regstr);
        $supplier_alt_regstr = json_decode($acc_detail[0]->acc_customer_alt_b_address);
        // dd($supplier_alt_regstr);
        $cntct = json_decode($acc_detail[0]->acc_contact_point);
        $alt_contct = json_decode($acc_detail[0]->acc_alt_contact_point);
        // dd($data);
        $companylist = GeneralUtils::getCompanyList();
        $payment_terms = DB::table('Payment_terms')->get();
        $payment_terms = json_decode(json_encode($payment_terms), true);
        $currency = GeneralUtils::getDistinctCurr();
        $gsts = GeneralUtils::get_gst_list();
        $cust_cates = GeneralUtils::get_cust_Cates();
        return view('adminViews.adm_acc_recieve_detail', compact(['currency','cust_cates','gsts','acc_detail', 'companylist', 'payment_terms', 'data', 'contact', 'supplier_regstr', 'supplier_alt_regstr', 'cntct', 'alt_contct']));
    }
    /**
     * 
     */
    public function adm_account_recieve(Request $request)
    {
        $acc_list = DB::table('account_recieve')
        ->join('Company', 'account_recieve.acc_company', '=', 'Company.comp_id')
        ->join('gst_collection', 'account_recieve.acc_gst', '=', 'gst_collection.gst_id')
        ->join('Payment_terms', 'account_recieve.acc_payment_terms', '=', 'Payment_terms.pt_id')
        ->get();
        $acc_list = json_decode(json_encode($acc_list), true);
        
        return view('adminViews.adm_acc_recieve_list', compact(['acc_list']));
    }

    /**
     * 
     */
    public function adm_account_recieve_update(Request $request, $id)
    {
        // dd($request);
        $comp_id = $request->input('comp_id');

        $acc_customer_name = $request->input('acc_customer_name');
        $comp_gst = $request->input('comp_gst');
        $comp_curr = $request->input('comp_curr');
        $acc_pay_sup_name = $request->input('acc_pay_sup_name');
        $comp_cate = $request->input('comp_cate');
        $comp_pay_trms = $request->input('comp_pay_trms');
        $check_cust = $request->input('acc_chk_asset_vals');
        $notes = $request->input('notes');
        // dd($check_cust);

        //Supplier Bank Information//
        $comp_bank_name = $request->input('comp_bank_name');
        $comp_bank_code = $request->input('comp_bank_code');
        $comp_bank_branch_name = $request->input('comp_bank_branch_name');
        $comp_bank_branch_code = $request->input('comp_bank_branch_code');
        $comp_bank_swift_code = $request->input('comp_bank_swift_code');
        $comp_bank_intermed = $request->input('comp_bank_intermed');
        $comp_bank_acc_type = $request->input('comp_bank_acc_type');
        $comp_bank_acc_number = $request->input('comp_bank_acc_number');
        $currency = $request->input('acc_chk_asset_valss');

        //Supplier Bank Information//
        $supplier_bank_info = array(
            "b_name" => $comp_bank_name, "b_code" => $comp_bank_code, "branch_name" => $comp_bank_branch_name, "branch_code" => $comp_bank_branch_code,
            "swift_code" => $comp_bank_swift_code, "intermediary_bank" => $comp_bank_intermed, "acc_type" => $comp_bank_acc_type, "acc_number" => $comp_bank_acc_number,
            "multi_support" => $currency
        );
        $supplier_bank_info = json_encode($supplier_bank_info);

        //Supplier Contact Information//
        $comp_phone_1 = $request->input('comp_phone_1');
        $comp_phone_2 = $request->input('comp_phone_2');
        $comp_mobile_1 = $request->input('comp_mobile_1');
        $comp_mobile_2 = $request->input('comp_mobile_2');
        $comp_fax = $request->input('comp_fax');
        $comp_email = $request->input('comp_email');

        $supplier_contct_info = array(
            "phone_1" => $comp_phone_1, "phone_2" => $comp_phone_2, "mob_1" => $comp_mobile_1, "mob_2" => $comp_mobile_2,
            "fax" => $comp_fax, "email" => $comp_email
        );
        $supplier_contct_info = json_encode($supplier_contct_info);

        //Supplier Registered Address//
        $leg_addr_line_1 = $request->input('leg_addr_line_1');
        $leg_addr_line_2 = $request->input('leg_addr_line_2');
        $leg_addr_state = $request->input('leg_addr_state');
        $leg_addr_city = $request->input('leg_addr_city');
        $leg_addr_postal = $request->input('leg_addr_postal');
        $leg_addr_country = $request->input('leg_addr_country');

        $supplier_registr_addr = array(
            "addr_line1" => $leg_addr_line_1, "addr_line2" => $leg_addr_line_2, "state" => $leg_addr_state, "city" => $leg_addr_city,
            "postal" => $leg_addr_postal, "country" => $leg_addr_country
        );
        $supplier_registr_addr = json_encode($supplier_registr_addr);

        //Supplier Alternate Business Address//
        $alt_addr_line_1 = $request->input('alt_addr_line_1');
        $alt_addr_line_2 = $request->input('alt_addr_line_2');
        $alt_addr_state = $request->input('alt_addr_state');
        $alt_addr_city = $request->input('alt_addr_city');
        $alt_addr_postal = $request->input('alt_addr_postal');
        $alt_addr_country = $request->input('alt_addr_country');

        $supplier_alt_business_addr = array(
            "alt_addr_line1" => $alt_addr_line_1, "alt_addr_line2" => $alt_addr_line_2, "alt_state" => $alt_addr_state, "alt_city" => $alt_addr_city,
            "alt_postal" => $alt_addr_postal, "alt_country" => $alt_addr_country
        );
        $supplier_alt_business_addr = json_encode($supplier_alt_business_addr);

        //Point Of Contact//
        $comp_poc_name = $request->input('comp_poc_name');
        $comp_poc_phone = $request->input('comp_poc_phone');
        $comp_poc_mobile = $request->input('comp_poc_mobile');
        $comp_poc_email = $request->input('comp_poc_email');

        $contact_point = array("name" => $comp_poc_name, "phone" => $comp_poc_phone, "mobile" => $comp_poc_mobile, "email" => $comp_poc_email);
        $contact_point = json_encode($contact_point);

        //Alternate Point Of Contact//
        $comp_alt_poc_name = $request->input('comp_alt_poc_name');
        $comp_alt_poc_phone = $request->input('comp_alt_poc_phone');
        $comp_alt_poc_mobile = $request->input('comp_alt_poc_mobile');
        $comp_alt_poc_email = $request->input('comp_alt_poc_email');

        $alt_contact_point = array("alt_name" => $comp_alt_poc_name, "alt_phone" => $comp_alt_poc_phone, "alt_mobile" => $comp_alt_poc_mobile, "alt_email" => $comp_alt_poc_email);
        $alt_contact_point = json_encode($alt_contact_point);
        try {
            // DB::beginTransaction();
            // if(GeneralUtils::check_Comp_COA_exist($comp_id)){
            //     DB::table('Company_COAs')->where('comp_id',$comp_id)->update([
            //         'comp_coa'=> $coa_vals
            //     ]);
            // }else{
            DB::table('account_recieve')->where('acc_id', $id)->update([
                'acc_company' => $comp_id,
                'acc_customer_name' => $acc_customer_name,
                'acc_currency' => $comp_curr,
                'acc_gst' => $comp_gst,
                'acc_membership_id' => $acc_pay_sup_name,
                'acc_customer_categories' => $comp_cate,
                'acc_payment_terms' => $comp_pay_trms,
                'acc_corresponding_supplier' => $check_cust,
                'acc_notes' => $notes,
                'acc_customer_bank_info' => $supplier_bank_info,
                'acc_customer_contact_info' => $supplier_contct_info,
                'acc_customer_registered_address' => $supplier_registr_addr,
                'acc_customer_alt_b_address' => $supplier_alt_business_addr,
                'acc_contact_point' => $contact_point,
                'acc_alt_contact_point' => $alt_contact_point,
            ]);

            // }
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }



    /**
     * 
     */
    public function adm_account_payable(Request $request)
    {
        $acc_list = DB::table('account_payable')
        ->join('Company', 'account_payable.ap_company', '=', 'Company.comp_id')
        ->join('gst_collection', 'account_payable.ap_gst', '=', 'gst_collection.gst_id')
        ->join('Payment_terms', 'account_payable.ap_payment_terms', '=', 'Payment_terms.pt_id')
        ->get();
        // dd($acc_list);
        $acc_list = json_decode(json_encode($acc_list), true);
        // $acc_list = json_decode(json_encode($acc_list), true);
        return view('adminViews.adm_acc_payable_list', compact(['acc_list']));
    }

    public function adm_account_payable_detail(Request $request, $id)
    {
        $acc_detail = DB::table('account_payable')->where('ap_id', $id)->get();
        $data = json_decode($acc_detail[0]->ap_supplier_bank_info);
        $contact = json_decode($acc_detail[0]->ap_supplier_contact_info);
        $supplier_regstr = json_decode($acc_detail[0]->ap_supplier_registered_address);
        // dd($supplier_regstr);
        $supplier_alt_regstr = json_decode($acc_detail[0]->ap_supplier_alt_b_address);
        // dd($supplier_alt_regstr);
        $cntct = json_decode($acc_detail[0]->ap_contact_point);
        $alt_contct = json_decode($acc_detail[0]->ap_alt_contact_point);
        // dd($data);
        $companylist = GeneralUtils::getCompanyList();
        $payment_terms = DB::table('Payment_terms')->get();
        $payment_terms = json_decode(json_encode($payment_terms), true);
        $currency = GeneralUtils::getDistinctCurr();
        return view('adminViews.adm_acc_payable_detail', compact(['acc_detail', 'companylist', 'payment_terms', 'data', 'contact', 'supplier_regstr', 'supplier_alt_regstr', 'cntct', 'alt_contct', 'currency']));
    }
    /**
     * 
     */
    public function adm_account_payable_update(Request $request, $id)
    {
        // dd($request);
        $comp_id = $request->input('comp_id');

        $acc_supplier_name = $request->input('acc_supplier_name');
        $comp_gst = $request->input('comp_gst');
        $comp_curr = $request->input('comp_curr');
        $acc_pay_sup_name = $request->input('acc_pay_sup_name');
        $comp_cate = $request->input('comp_cate');
        $comp_pay_trms = $request->input('comp_pay_trms');
        $check_cust = $request->input('acc_chk_asset_vals');
        $notes = $request->input('notes');
        // dd($check_cust);

        //Supplier Bank Information//
        $comp_bank_name = $request->input('comp_bank_name');
        $comp_bank_code = $request->input('comp_bank_code');
        $comp_bank_branch_name = $request->input('comp_bank_branch_name');
        $comp_bank_branch_code = $request->input('comp_bank_branch_code');
        $comp_bank_swift_code = $request->input('comp_bank_swift_code');
        $comp_bank_intermed = $request->input('comp_bank_intermed');
        $comp_bank_acc_type = $request->input('comp_bank_acc_type');
        $comp_bank_acc_number = $request->input('comp_bank_acc_number');
        $currency = $request->input('acc_chk_asset_valss');

        //Supplier Bank Information//
        $supplier_bank_info = array(
            "b_name" => $comp_bank_name, "b_code" => $comp_bank_code, "branch_name" => $comp_bank_branch_name, "branch_code" => $comp_bank_branch_code,
            "swift_code" => $comp_bank_swift_code, "intermediary_bank" => $comp_bank_intermed, "acc_type" => $comp_bank_acc_type, "acc_number" => $comp_bank_acc_number,
            "multi_support" => $currency
        );
        $supplier_bank_info = json_encode($supplier_bank_info);

        //Supplier Contact Information//
        $comp_phone_1 = $request->input('comp_phone_1');
        $comp_phone_2 = $request->input('comp_phone_2');
        $comp_mobile_1 = $request->input('comp_mobile_1');
        $comp_mobile_2 = $request->input('comp_mobile_2');
        $comp_fax = $request->input('comp_fax');
        $comp_email = $request->input('comp_email');

        $supplier_contct_info = array(
            "phone_1" => $comp_phone_1, "phone_2" => $comp_phone_2, "mob_1" => $comp_mobile_1, "mob_2" => $comp_mobile_2,
            "fax" => $comp_fax, "email" => $comp_email
        );
        $supplier_contct_info = json_encode($supplier_contct_info);

        //Supplier Registered Address//
        $leg_addr_line_1 = $request->input('leg_addr_line_1');
        $leg_addr_line_2 = $request->input('leg_addr_line_2');
        $leg_addr_state = $request->input('leg_addr_state');
        $leg_addr_city = $request->input('leg_addr_city');
        $leg_addr_postal = $request->input('leg_addr_postal');
        $leg_addr_country = $request->input('leg_addr_country');

        $supplier_registr_addr = array(
            "addr_line1" => $leg_addr_line_1, "addr_line2" => $leg_addr_line_2, "state" => $leg_addr_state, "city" => $leg_addr_city,
            "postal" => $leg_addr_postal, "country" => $leg_addr_country
        );
        $supplier_registr_addr = json_encode($supplier_registr_addr);

        //Supplier Alternate Business Address//
        $alt_addr_line_1 = $request->input('alt_addr_line_1');
        $alt_addr_line_2 = $request->input('alt_addr_line_2');
        $alt_addr_state = $request->input('alt_addr_state');
        $alt_addr_city = $request->input('alt_addr_city');
        $alt_addr_postal = $request->input('alt_addr_postal');
        $alt_addr_country = $request->input('alt_addr_country');

        $supplier_alt_business_addr = array(
            "alt_addr_line1" => $alt_addr_line_1, "alt_addr_line2" => $alt_addr_line_2, "alt_state" => $alt_addr_state, "alt_city" => $alt_addr_city,
            "alt_postal" => $alt_addr_postal, "alt_country" => $alt_addr_country
        );
        $supplier_alt_business_addr = json_encode($supplier_alt_business_addr);

        //Point Of Contact//
        $comp_poc_name = $request->input('comp_poc_name');
        $comp_poc_phone = $request->input('comp_poc_phone');
        $comp_poc_mobile = $request->input('comp_poc_mobile');
        $comp_poc_email = $request->input('comp_poc_email');

        $contact_point = array("name" => $comp_poc_name, "phone" => $comp_poc_phone, "mobile" => $comp_poc_mobile, "email" => $comp_poc_email);
        $contact_point = json_encode($contact_point);

        //Alternate Point Of Contact//
        $comp_alt_poc_name = $request->input('comp_alt_poc_name');
        $comp_alt_poc_phone = $request->input('comp_alt_poc_phone');
        $comp_alt_poc_mobile = $request->input('comp_alt_poc_mobile');
        $comp_alt_poc_email = $request->input('comp_alt_poc_email');

        $alt_contact_point = array("alt_name" => $comp_alt_poc_name, "alt_phone" => $comp_alt_poc_phone, "alt_mobile" => $comp_alt_poc_mobile, "alt_email" => $comp_alt_poc_email);
        $alt_contact_point = json_encode($alt_contact_point);
        try {
            // DB::beginTransaction();
            // if(GeneralUtils::check_Comp_COA_exist($comp_id)){
            //     DB::table('Company_COAs')->where('comp_id',$comp_id)->update([
            //         'comp_coa'=> $coa_vals
            //     ]);
            // }else{
            DB::table('account_payable')->where('ap_id', $id)->update([
                'ap_company' => $comp_id,
                'ap_supplier_name' => $acc_supplier_name,
                'ap_currency' => $comp_curr,
                'ap_gst' => $comp_gst,
                'ap_membership_id' => $acc_pay_sup_name,
                'ap_supplier_categories' => $comp_cate,
                'ap_payment_terms' => $comp_pay_trms,
                'ap_corresponding_customer' => $check_cust,
                'ap_notes' => $notes,
                'ap_supplier_bank_info' => $supplier_bank_info,
                'ap_supplier_contact_info' => $supplier_contct_info,
                'ap_supplier_registered_address' => $supplier_registr_addr,
                'ap_supplier_alt_b_address' => $supplier_alt_business_addr,
                'ap_contact_point' => $contact_point,
                'ap_alt_contact_point' => $alt_contact_point,
            ]);
            // }
            DB::commit();
        } catch (\Exception $ex) {
            dd($ex);
        }
        return \redirect('/admin/dashboard');
    }

    /**
     * 
     */
    public function show_general_dataentry(Request $request)
    {
        $companylist = GeneralUtils::getCompanyList();
        return view('adminViews.adm_generaljournal_data_entry', compact(['companylist']));
    }

    /**
     * 
     */
    public function show_customer_dataentry(Request $request)
    {
        $companylist = GeneralUtils::getCompanyList();
        return view('adminViews.adm_customer_data_entry', compact(['companylist']));
    }

    /**
     * 
     */
    public function show_supplier_dataentry(Request $request)
    {
        $companylist = GeneralUtils::getCompanyList();
        return view('adminViews.adm_supplier_data_entry', compact(['companylist']));
    }

    /**
     * 
     */
    public function show_supplier_dataentry_form(Request $request, $comp_id, $form_id)
    {
        $compDetails = GeneralUtils::getCompanyDetails($comp_id);
        if($form_id == "1"){
            return view('adminViews.dataEntry.adm_de_supplier_inv');
        }else if($form_id == "2"){
            return view('adminViews.dataEntry.adm_de_supplier_payment');
        }else if($form_id == "3"){
            return view('adminViews.dataEntry.adm_de_customer_inv');
        }else if($form_id == "4"){
            return view('adminViews.dataEntry.adm_de_customer_reciept');
        }else if($form_id == "5"){
            return view('adminViews.dataEntry.adm_de_general');
        }
        // return view('adminViews.dataEntry.adm_de_supplier_inv');
    }

    /**
     * 
     */
    public function adm_dataentry_form_select(Request $request)
    {
        $comp_id = $request->input('comp_id');
        $supplier_de_type = $request->input('supplier_de_type');
        return \redirect("/admin/data-entry/company/$comp_id/supplier-form/$supplier_de_type");
        // $dataentery_form = GeneralUtils::getCompanyDetails($request->input('company_id'));
    }
    /************************************************************************************************************/
    /*********************************************** AJAX FUNCTIONS *********************************************/
    /************************************************************************************************************/


    /**
     * 
     */
    public function getXCurr_tbl(Request $request)
    {
        $input = $request->all();
        try {
            $month = $input['month'];
            $year = $input['year'];
            $reshtml = GeneralUtils::generateCurrencyTbl($month, $year);
            $res['res'] = 'SUCCESS';
            $res['data'] = $reshtml;
            return response()->json($res);
        } catch (\Exception $ex) {
            error_log($ex->getMessage());
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }
    /**
     * 
     */
    public function getComp_COAs(Request $request)
    {
        $input = $request->all();
        try {
            $comp_id = $input['comp_id'];
            $coas = GeneralUtils::getCompanyAssignedCOA($comp_id);
            if (isset($coas)) {
                $arr = explode(',', $coas);
                $res['res'] = 'SUCCESS';
                $res['data'] = $arr;
                $res['datatxt'] = $coas;
                error_log($coas);
                return response()->json($res);
            } else {
                $res['res'] = 'FAIL';
                $res['error'] = "No COA is Assigned";
                return response()->json($res);
            }
            $res['res'] = 'FAIL';
            $res['error'] = "Problem in fetching Data";
            return response()->json($res);
        } catch (\Exception $ex) {
            error_log($ex->getMessage());
            $res['res'] = 'FAIL';
            $res['error'] = $ex->getMessage();

            return response()->json($res);
        }
    }

    /**
     *
     */
    public function get_subCat_Name(Request $request)
    {
        $input = $request->all();
        $fa_cate_id = $input['fa_cate_id'];
        $sub_cat_obj = DB::table('FA_sub_cate')->where('fa_cat_id', $fa_cate_id)->get();
        if(isset($sub_cat_obj)){
            $res['res'] = 'SUCCESS';
            $res['data'] = $sub_cat_obj;
            return response()->json($res);
        }
        $res['res'] = 'FAIL';
        $res['error'] = "Problem in fetching Data";
        return response()->json($res);
    }
}
