<?php
namespace App\Defines;

class DataEntryDefines
{
    public const DE_SUP_INV = 1;
    public const DE_SUP_PAY = 2;

    public const DE_CUS_INV = 3;
    public const DE_CUS_RECE = 4;



}

?>