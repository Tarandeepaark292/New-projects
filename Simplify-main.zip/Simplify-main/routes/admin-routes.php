<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Admin Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register Admin web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('admin')->group( function(){
    Route::get('/dashboard',"AdminController@show_dashboard");
    Route::get('/create-COA',"AdminController@show_chart_of_acc");
    Route::get('/COA-list',"AdminController@show_chart_of_acc_list");
    Route::get('/xcurr-list',"AdminController@show_XchangeCurr_list");
    Route::get('/company-list',"AdminController@show_companylist");
    Route::get('/create-company',"AdminController@show_create_company");
    Route::get('/create-company-user',"AdminController@show_create_company_user");
    Route::get('/comp-user-list',"AdminController@show_comp_users");
    Route::get('/assign-COA',"AdminController@show_assign_COA");
    Route::get('/company-accounting-setup',"AdminController@show_account_setup");
    Route::get('/company-acc-payable-setup',"AdminController@show_account_pay_setup");
    Route::get('/company-acc-rece-setup',"AdminController@show_account_rece_setup");
    Route::get('/create-gst',"AdminController@show_gst_screen");
    Route::get('/gst-list',"AdminController@show_gsts");
    Route::get('/create-fa-main-cate',"AdminController@show_FA_main_cate_screen");
    Route::get('/create-fa-sub-cate',"AdminController@show_FA_sub_cate_screen");
    Route::get('/create-fa-useful-life',"AdminController@show_FA_useful_life_screen");
    Route::get('/create-pay-terms',"AdminController@show_payterms_screen");
    Route::get('/create-xchage-curr',"AdminController@show_xchange_screen");
    Route::get('/create-supplier-cate',"AdminController@show_supp_cate");
    Route::get('/create-customer-cate',"AdminController@show_cust_cate");
    Route::get('/COA-detail/{coa_id}',"AdminController@show_chart_of_acc_detail");
    Route::get('/company-detail/{comp_id}',"AdminController@show_company_detail");
    Route::get('/data-entry/supplier',"AdminController@show_supplier_dataentry");
    Route::get('/data-entry/customer',"AdminController@show_customer_dataentry");
    Route::get('/data-entry/general-journal',"AdminController@show_general_dataentry");
    Route::get('/data-entry/company/{comp_id}/supplier-form/{form_id}',"AdminController@show_supplier_dataentry_form");
    Route::post('/dataentry/form/select',"AdminController@adm_dataentry_form_select");
    
    // Route::post('/generate-xchange-currency',"AdminController@generate_xchange");
    Route::post('/generate-xchange-currency',"AdminController@generate_Currency");
    Route::post('/generate-gst',"AdminController@generate_gst");
    Route::post('/generate-pay-terms',"AdminController@generate_pay_terms");
    Route::post('/generate-fa-cate',"AdminController@generate_FA_main_cate");
    Route::post('/generate-fa-sub-cate',"AdminController@generate_FA_sub_cate");
    Route::post('/generate-fa-useful-life',"AdminController@generate_FA_useful_life");
    Route::post('/generate-coa',"AdminController@generate_coa");
    Route::post('/update-coa',"AdminController@update_coa");
    Route::post('/update-company',"AdminController@update_company");
    Route::post('/generate_company', "AdminController@generate_company");
    Route::post('/generate-comp-user', "AdminController@generate_comp_user");
    Route::post('/assign-comp-COA', "AdminController@assign_comp_COA");
    Route::post('/generate-supplier-cate',"AdminController@generate_supp_cate");
    Route::post('/generate-customer-cate',"AdminController@generate_cust_cate");
    Route::get('/COA-activate/{coa_id}',"AdminController@activateCOA");
    Route::get('/COA-deactivate/{coa_id}',"AdminController@deactivateCOA");
    Route::get('/company-activate/{comp_id}',"AdminController@activateCompany");
    Route::get('/company-deactivate/{comp_id}',"AdminController@deactivateCompany");

    //Account Payable//
    // Route::get('/account-payable',"AdminController@adm_account_payable");
    Route::post('/account-payable-create',"AdminController@adm_account_payable_create");
    Route::get('/account-payable-list',"AdminController@adm_account_payable");
    Route::get('/acc_payable/{id}',"AdminController@adm_account_payable_detail");
    Route::post('/acc_payable_update/{id}',"AdminController@adm_account_payable_update");
    
    //Account Receivable//
    Route::post('/account-recieve-create',"AdminController@adm_account_recieve_create");
    Route::get('/account-recieve-list',"AdminController@adm_account_recieve");
    Route::get('/acc_recieve/{id}',"AdminController@adm_account_recieve_detail");
    Route::post('/acc_recieve_update/{id}',"AdminController@adm_account_recieve_update");
    //AJAX
    Route::post('/get-COAs',"AdminController@getComp_COAs")->name('ajaxgetCOAs.post');
    Route::post('/get-sub-cat',"AdminController@get_subCat_Name")->name('ajaxgetSubCat.get');
    Route::post('/get-XcurrencyList',"AdminController@getXCurr_tbl")->name('ajaxgetXcurrlist.post');
    
    //Account Setup//
    Route::post('/account-setup',"AdminController@adm_account_setup_create");
    Route::get('/accounting-setup',"AdminController@adm_account_setup_list");
    
    Route::get('/acc_setup/{id}',"AdminController@adm_account_setup_detail");
    Route::post('/acc-setup-update/{id}',"AdminController@adm_account_setup_update");

    // Route::post('/dataentry/form/select',"AdminController@adm_dataentry_form_select");
});

?>